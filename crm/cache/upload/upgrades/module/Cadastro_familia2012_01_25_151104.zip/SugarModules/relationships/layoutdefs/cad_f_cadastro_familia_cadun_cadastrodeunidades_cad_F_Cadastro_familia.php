<?php
// created: 2012-01-25 14:49:45
$layout_defs["cad_F_Cadastro_familia"]["subpanel_setup"]["cad_f_cadasstrodeunidades"] = array (
  'order' => 100,
  'module' => 'CADUN_CadastrodeUnidades',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_F_CADASTRO_FAMILIA_CADUN_CADASTRODEUNIDADES_FROM_CADUN_CADASTRODEUNIDADES_TITLE',
  'get_subpanel_data' => 'cad_f_cadasstrodeunidades',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-01-25 15:01:46
$layout_defs["cad_F_Cadastro_familia"]["subpanel_setup"]["cad_f_cadasstrodeunidades"] = array (
  'order' => 100,
  'module' => 'CADUN_CadastrodeUnidades',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_F_CADASTRO_FAMILIA_CADUN_CADASTRODEUNIDADES_FROM_CADUN_CADASTRODEUNIDADES_TITLE',
  'get_subpanel_data' => 'cad_f_cadasstrodeunidades',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-01-25 15:04:38
$layout_defs["cad_F_Cadastro_familia"]["subpanel_setup"]["cad_f_cadasstrodeunidades"] = array (
  'order' => 100,
  'module' => 'CADUN_CadastrodeUnidades',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_F_CADASTRO_FAMILIA_CADUN_CADASTRODEUNIDADES_FROM_CADUN_CADASTRODEUNIDADES_TITLE',
  'get_subpanel_data' => 'cad_f_cadasstrodeunidades',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
