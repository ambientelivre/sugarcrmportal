<?php
// created: 2012-04-03 09:42:18
$dictionary["A__Retorno_de_investimento"]["fields"]["a__retorno_mento_accounts"] = array (
  'name' => 'a__retorno_mento_accounts',
  'type' => 'link',
  'relationship' => 'a__retorno_de_investimento_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_A__RETORNO_DE_INVESTIMENTO_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
