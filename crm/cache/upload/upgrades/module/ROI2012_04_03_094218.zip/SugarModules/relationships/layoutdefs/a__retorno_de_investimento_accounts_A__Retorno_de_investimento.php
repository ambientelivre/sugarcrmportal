<?php
// created: 2012-04-03 09:35:20
$layout_defs["A__Retorno_de_investimento"]["subpanel_setup"]["a__retorno_mento_accounts"] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_A__RETORNO_DE_INVESTIMENTO_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'get_subpanel_data' => 'a__retorno_mento_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-03 09:40:47
$layout_defs["A__Retorno_de_investimento"]["subpanel_setup"]["a__retorno_mento_accounts"] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_A__RETORNO_DE_INVESTIMENTO_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'get_subpanel_data' => 'a__retorno_mento_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-03 09:42:18
$layout_defs["A__Retorno_de_investimento"]["subpanel_setup"]["a__retorno_mento_accounts"] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_A__RETORNO_DE_INVESTIMENTO_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'get_subpanel_data' => 'a__retorno_mento_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
