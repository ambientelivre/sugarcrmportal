<?php
$module_name = 'CADUN_Unidades';
$listViewDefs [$module_name] = 
array (
  'CODIGO_UNI' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CODIGO_UNI',
    'width' => '10%',
    'default' => true,
  ),
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
);
?>
