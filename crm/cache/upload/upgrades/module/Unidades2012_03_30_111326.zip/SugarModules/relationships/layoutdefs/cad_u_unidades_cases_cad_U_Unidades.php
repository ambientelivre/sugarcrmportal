<?php
// created: 2012-03-30 11:13:26
$layout_defs["cad_U_Unidades"]["subpanel_setup"]["cad_u_unidades_cases"] = array (
  'order' => 100,
  'module' => 'Cases',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_U_UNIDADES_CASES_FROM_CASES_TITLE',
  'get_subpanel_data' => 'cad_u_unidades_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
