<?php
// created: 2012-03-30 11:13:26
$dictionary["cad_U_Unidades"]["fields"]["cad_u_unidades_cases"] = array (
  'name' => 'cad_u_unidades_cases',
  'type' => 'link',
  'relationship' => 'cad_u_unidades_cases',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CAD_U_UNIDADES_CASES_FROM_CASES_TITLE',
);
