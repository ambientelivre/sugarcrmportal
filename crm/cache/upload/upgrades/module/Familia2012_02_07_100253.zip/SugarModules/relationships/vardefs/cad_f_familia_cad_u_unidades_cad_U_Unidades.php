<?php
// created: 2012-02-07 10:02:53
$dictionary["cad_U_Unidades"]["fields"]["cad_f_familcad_u_unidades"] = array (
  'name' => 'cad_f_familcad_u_unidades',
  'type' => 'link',
  'relationship' => 'cad_f_familia_cad_u_unidades',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CAD_F_FAMILIA_CAD_U_UNIDADES_FROM_CAD_F_FAMILIA_TITLE',
);
