<?php
// created: 2012-01-26 12:37:46
$layout_defs["cad_U_Unidades"]["subpanel_setup"]["cad_f_familcad_u_unidades"] = array (
  'order' => 100,
  'module' => 'Cad_F_Familia',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_F_FAMILIA_CAD_U_UNIDADES_FROM_CAD_F_FAMILIA_TITLE',
  'get_subpanel_data' => 'cad_f_familcad_u_unidades',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-01 15:46:40
$layout_defs["cad_U_Unidades"]["subpanel_setup"]["cad_f_familcad_u_unidades"] = array (
  'order' => 100,
  'module' => 'Cad_F_Familia',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_F_FAMILIA_CAD_U_UNIDADES_FROM_CAD_F_FAMILIA_TITLE',
  'get_subpanel_data' => 'cad_f_familcad_u_unidades',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-07 10:02:53
$layout_defs["cad_U_Unidades"]["subpanel_setup"]["cad_f_familcad_u_unidades"] = array (
  'order' => 100,
  'module' => 'Cad_F_Familia',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_F_FAMILIA_CAD_U_UNIDADES_FROM_CAD_F_FAMILIA_TITLE',
  'get_subpanel_data' => 'cad_f_familcad_u_unidades',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
