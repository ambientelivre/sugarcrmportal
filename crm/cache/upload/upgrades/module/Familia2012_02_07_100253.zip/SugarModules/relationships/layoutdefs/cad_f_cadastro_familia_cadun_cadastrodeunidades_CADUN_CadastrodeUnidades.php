<?php
// created: 2012-01-25 15:15:32
$layout_defs["CADUN_CadastrodeUnidades"]["subpanel_setup"]["cad_f_cadasstrodeunidades"] = array (
  'order' => 100,
  'module' => 'cad_F_Cadastro_familia',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_F_CADASTRO_FAMILIA_CADUN_CADASTRODEUNIDADES_FROM_CAD_F_CADASTRO_FAMILIA_TITLE',
  'get_subpanel_data' => 'cad_f_cadasstrodeunidades',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
