<?php
// created: 2012-01-25 15:15:32
$dictionary["CADUN_CadastrodeUnidades"]["fields"]["cad_f_cadasstrodeunidades"] = array (
  'name' => 'cad_f_cadasstrodeunidades',
  'type' => 'link',
  'relationship' => 'cad_f_cadastro_familia_cadun_cadastrodeunidades',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CAD_F_CADASTRO_FAMILIA_CADUN_CADASTRODEUNIDADES_FROM_CAD_F_CADASTRO_FAMILIA_TITLE',
);
