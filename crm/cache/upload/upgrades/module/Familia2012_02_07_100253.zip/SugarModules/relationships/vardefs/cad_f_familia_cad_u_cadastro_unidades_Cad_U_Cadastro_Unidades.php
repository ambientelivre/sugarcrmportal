<?php
// created: 2012-01-26 12:37:11
$dictionary["Cad_U_Cadastro_Unidades"]["fields"]["cad_f_familastro_unidades"] = array (
  'name' => 'cad_f_familastro_unidades',
  'type' => 'link',
  'relationship' => 'cad_f_familia_cad_u_cadastro_unidades',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CAD_F_FAMILIA_CAD_U_CADASTRO_UNIDADES_FROM_CAD_F_FAMILIA_TITLE',
);
