<?php
// created: 2012-04-03 09:42:25
$dictionary["Meeting"]["fields"]["at__atendimento_ao_cliente_activities_meetings"] = array (
  'name' => 'at__atendimento_ao_cliente_activities_meetings',
  'type' => 'link',
  'relationship' => 'at__atendimento_ao_cliente_activities_meetings',
  'source' => 'non-db',
);
