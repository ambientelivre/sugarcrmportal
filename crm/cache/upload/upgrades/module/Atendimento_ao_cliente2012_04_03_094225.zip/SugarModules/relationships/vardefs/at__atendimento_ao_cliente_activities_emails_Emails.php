<?php
// created: 2012-04-03 09:42:25
$dictionary["Email"]["fields"]["at__atendimento_ao_cliente_activities_emails"] = array (
  'name' => 'at__atendimento_ao_cliente_activities_emails',
  'type' => 'link',
  'relationship' => 'at__atendimento_ao_cliente_activities_emails',
  'source' => 'non-db',
);
