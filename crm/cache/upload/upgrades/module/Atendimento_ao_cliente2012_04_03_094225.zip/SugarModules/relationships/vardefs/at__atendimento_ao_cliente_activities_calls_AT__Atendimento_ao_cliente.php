<?php
// created: 2012-04-03 09:42:25
$dictionary["AT__Atendimento_ao_cliente"]["fields"]["at__atendimento_ao_cliente_activities_calls"] = array (
  'name' => 'at__atendimento_ao_cliente_activities_calls',
  'type' => 'link',
  'relationship' => 'at__atendimento_ao_cliente_activities_calls',
  'source' => 'non-db',
);
