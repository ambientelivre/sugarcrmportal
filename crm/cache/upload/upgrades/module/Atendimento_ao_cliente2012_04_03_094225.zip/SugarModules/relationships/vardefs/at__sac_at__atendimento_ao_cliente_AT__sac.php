<?php
// created: 2012-04-03 09:42:25
$dictionary["AT__sac"]["fields"]["at__sac_at_nto_ao_cliente"] = array (
  'name' => 'at__sac_at_nto_ao_cliente',
  'type' => 'link',
  'relationship' => 'at__sac_at__atendimento_ao_cliente',
  'source' => 'non-db',
  'vname' => 'LBL_AT__SAC_AT__ATENDIMENTO_AO_CLIENTE_FROM_AT__ATENDIMENTO_AO_CLIENTE_TITLE',
);
