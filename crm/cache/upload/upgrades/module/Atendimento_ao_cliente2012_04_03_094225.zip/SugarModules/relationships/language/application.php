<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$app_list_strings['parent_type_display']['AT__Atendimento_ao_cliente'] = 'AT__Atendimento_ao_cliente';
$app_list_strings['record_type_display']['AT__Atendimento_ao_cliente'] = 'AT__Atendimento_ao_cliente';
$app_list_strings['record_type_display_notes']['AT__Atendimento_ao_cliente'] = 'AT__Atendimento_ao_cliente';
