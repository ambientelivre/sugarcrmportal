<?php
// created: 2012-04-03 09:40:23
$layout_defs["AT__sac"]["subpanel_setup"]["at__sac_at_nto_ao_cliente"] = array (
  'order' => 100,
  'module' => 'AT__Atendimento_ao_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_AT__SAC_AT__ATENDIMENTO_AO_CLIENTE_FROM_AT__ATENDIMENTO_AO_CLIENTE_TITLE',
  'get_subpanel_data' => 'at__sac_at_nto_ao_cliente',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-03 09:42:25
$layout_defs["AT__sac"]["subpanel_setup"]["at__sac_at_nto_ao_cliente"] = array (
  'order' => 100,
  'module' => 'AT__Atendimento_ao_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_AT__SAC_AT__ATENDIMENTO_AO_CLIENTE_FROM_AT__ATENDIMENTO_AO_CLIENTE_TITLE',
  'get_subpanel_data' => 'at__sac_at_nto_ao_cliente',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
