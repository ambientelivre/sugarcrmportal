<?php
$module_name = 't3cpa_pedido_veterinario_regional';
$listViewDefs [$module_name] = 
array (
  'PED_NM_RAZAO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PED_NM_RAZAO',
    'width' => '10%',
    'default' => true,
  ),
  'PED_TELEFONE_CONTATO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PED_TELEFONE_CONTATO',
    'width' => '10%',
    'default' => true,
  ),
  'PED_CPF_CNPJ' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PED_CPF_CNPJ',
    'width' => '10%',
    'default' => true,
  ),
  'PED_INSCRICAO_ESTADUAL' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PED_INSCRICAO_ESTADUAL',
    'width' => '10%',
    'default' => true,
  ),
  'PED_QUANTIDADE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PED_QUANTIDADE',
    'width' => '10%',
    'default' => true,
  ),
  'PED_LOTE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PED_LOTE',
    'width' => '10%',
    'default' => true,
  ),
  'PED_VALOR_UNITARIO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PED_VALOR_UNITARIO',
    'width' => '10%',
    'default' => true,
  ),
  'PED_VALOR_TOTAL' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PED_VALOR_TOTAL',
    'width' => '10%',
    'default' => true,
  ),
);
?>
