<?php
$module_name = 't3cpa_secretarias';
$listViewDefs [$module_name] = 
array (
  'SEC_RAZAO_SOCIAL' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SEC_RAZAO_SOCIAL',
    'width' => '10%',
    'default' => true,
  ),
  'SEC_NM_FANTASIA' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SEC_NM_FANTASIA',
    'width' => '10%',
    'default' => true,
  ),
  'SEC_CNPJ' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SEC_CNPJ',
    'width' => '10%',
    'default' => true,
  ),
  'SEC_CNAE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SEC_CNAE',
    'width' => '10%',
    'default' => true,
  ),
  'SEC_TELEFONE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SEC_TELEFONE',
    'width' => '10%',
    'default' => true,
  ),
  'SEC_LOGRADOURO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SEC_LOGRADOURO',
    'width' => '10%',
    'default' => true,
  ),
  'SEC_CIDADE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SEC_CIDADE',
    'width' => '10%',
    'default' => true,
  ),
  'SEC_ESTADO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SEC_ESTADO',
    'width' => '10%',
    'default' => true,
  ),
);
?>
