<?php
$module_name = 't3cpa_estoque_gereal';
$listViewDefs [$module_name] = 
array (
  'COD_PROD' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_COD_PROD',
    'width' => '10%',
    'default' => true,
  ),
  'EG_LOTE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EG_LOTE',
    'width' => '10%',
    'default' => true,
  ),
);
?>
