<?php
// created: 2012-02-16 11:16:46
$dictionary["Cad_F_Familia"]["fields"]["cad_s_soluc_cad_f_familia"] = array (
  'name' => 'cad_s_soluc_cad_f_familia',
  'type' => 'link',
  'relationship' => 'cad_s_solucoes_cad_f_familia',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CAD_S_SOLUCOES_CAD_F_FAMILIA_FROM_CAD_S_SOLUCOES_TITLE',
);
