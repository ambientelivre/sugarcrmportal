<?php
// created: 2012-01-26 12:42:38
$layout_defs["CAD_S_Solucoes"]["subpanel_setup"]["cad_s_soluccad_u_unidades"] = array (
  'order' => 100,
  'module' => 'cad_U_Unidades',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_S_SOLUCOES_CAD_U_UNIDADES_FROM_CAD_U_UNIDADES_TITLE',
  'get_subpanel_data' => 'cad_s_soluccad_u_unidades',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-01-26 12:52:35
$layout_defs["CAD_S_Solucoes"]["subpanel_setup"]["cad_s_soluccad_u_unidades"] = array (
  'order' => 100,
  'module' => 'cad_U_Unidades',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_S_SOLUCOES_CAD_U_UNIDADES_FROM_CAD_U_UNIDADES_TITLE',
  'get_subpanel_data' => 'cad_s_soluccad_u_unidades',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-01-26 12:54:01
$layout_defs["CAD_S_Solucoes"]["subpanel_setup"]["cad_s_soluccad_u_unidades"] = array (
  'order' => 100,
  'module' => 'cad_U_Unidades',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_S_SOLUCOES_CAD_U_UNIDADES_FROM_CAD_U_UNIDADES_TITLE',
  'get_subpanel_data' => 'cad_s_soluccad_u_unidades',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-01-26 12:54:37
$layout_defs["CAD_S_Solucoes"]["subpanel_setup"]["cad_s_soluccad_u_unidades"] = array (
  'order' => 100,
  'module' => 'cad_U_Unidades',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_S_SOLUCOES_CAD_U_UNIDADES_FROM_CAD_U_UNIDADES_TITLE',
  'get_subpanel_data' => 'cad_s_soluccad_u_unidades',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
