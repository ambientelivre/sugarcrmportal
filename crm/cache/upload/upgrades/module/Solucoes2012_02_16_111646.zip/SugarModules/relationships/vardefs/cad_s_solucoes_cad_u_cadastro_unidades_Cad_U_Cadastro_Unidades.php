<?php
// created: 2012-01-25 15:19:29
$dictionary["Cad_U_Cadastro_Unidades"]["fields"]["cad_s_solucastro_unidades"] = array (
  'name' => 'cad_s_solucastro_unidades',
  'type' => 'link',
  'relationship' => 'cad_s_solucoes_cad_u_cadastro_unidades',
  'source' => 'non-db',
  'vname' => 'LBL_CAD_S_SOLUCOES_CAD_U_CADASTRO_UNIDADES_FROM_CAD_S_SOLUCOES_TITLE',
);
