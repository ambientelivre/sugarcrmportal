<?php
// created: 2012-01-26 12:42:38
$layout_defs["Cad_F_Familia"]["subpanel_setup"]["cad_s_soluc_cad_f_familia"] = array (
  'order' => 100,
  'module' => 'CAD_S_Solucoes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_S_SOLUCOES_CAD_F_FAMILIA_FROM_CAD_S_SOLUCOES_TITLE',
  'get_subpanel_data' => 'cad_s_soluc_cad_f_familia',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-01-26 12:49:26
$layout_defs["Cad_F_Familia"]["subpanel_setup"]["cad_s_soluc_cad_f_familia"] = array (
  'order' => 100,
  'module' => 'CAD_S_Solucoes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_S_SOLUCOES_CAD_F_FAMILIA_FROM_CAD_S_SOLUCOES_TITLE',
  'get_subpanel_data' => 'cad_s_soluc_cad_f_familia',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-01-26 12:52:35
$layout_defs["Cad_F_Familia"]["subpanel_setup"]["cad_s_soluc_cad_f_familia"] = array (
  'order' => 100,
  'module' => 'CAD_S_Solucoes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_S_SOLUCOES_CAD_F_FAMILIA_FROM_CAD_S_SOLUCOES_TITLE',
  'get_subpanel_data' => 'cad_s_soluc_cad_f_familia',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-01-26 12:54:01
$layout_defs["Cad_F_Familia"]["subpanel_setup"]["cad_s_soluc_cad_f_familia"] = array (
  'order' => 100,
  'module' => 'CAD_S_Solucoes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_S_SOLUCOES_CAD_F_FAMILIA_FROM_CAD_S_SOLUCOES_TITLE',
  'get_subpanel_data' => 'cad_s_soluc_cad_f_familia',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-01-26 12:54:37
$layout_defs["Cad_F_Familia"]["subpanel_setup"]["cad_s_soluc_cad_f_familia"] = array (
  'order' => 100,
  'module' => 'CAD_S_Solucoes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_S_SOLUCOES_CAD_F_FAMILIA_FROM_CAD_S_SOLUCOES_TITLE',
  'get_subpanel_data' => 'cad_s_soluc_cad_f_familia',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-01-26 12:55:24
$layout_defs["Cad_F_Familia"]["subpanel_setup"]["cad_s_soluc_cad_f_familia"] = array (
  'order' => 100,
  'module' => 'CAD_S_Solucoes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_S_SOLUCOES_CAD_F_FAMILIA_FROM_CAD_S_SOLUCOES_TITLE',
  'get_subpanel_data' => 'cad_s_soluc_cad_f_familia',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-01 15:46:49
$layout_defs["Cad_F_Familia"]["subpanel_setup"]["cad_s_soluc_cad_f_familia"] = array (
  'order' => 100,
  'module' => 'CAD_S_Solucoes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_S_SOLUCOES_CAD_F_FAMILIA_FROM_CAD_S_SOLUCOES_TITLE',
  'get_subpanel_data' => 'cad_s_soluc_cad_f_familia',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-03 15:45:39
$layout_defs["Cad_F_Familia"]["subpanel_setup"]["cad_s_soluc_cad_f_familia"] = array (
  'order' => 100,
  'module' => 'CAD_S_Solucoes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_S_SOLUCOES_CAD_F_FAMILIA_FROM_CAD_S_SOLUCOES_TITLE',
  'get_subpanel_data' => 'cad_s_soluc_cad_f_familia',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-16 11:16:46
$layout_defs["Cad_F_Familia"]["subpanel_setup"]["cad_s_soluc_cad_f_familia"] = array (
  'order' => 100,
  'module' => 'CAD_S_Solucoes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_S_SOLUCOES_CAD_F_FAMILIA_FROM_CAD_S_SOLUCOES_TITLE',
  'get_subpanel_data' => 'cad_s_soluc_cad_f_familia',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
