<?php
// created: 2012-01-25 15:19:29
$dictionary["cad_F_Cadastro_familia"]["fields"]["cad_s_solucdastro_familia"] = array (
  'name' => 'cad_s_solucdastro_familia',
  'type' => 'link',
  'relationship' => 'cad_s_solucoes_cad_f_cadastro_familia',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CAD_S_SOLUCOES_CAD_F_CADASTRO_FAMILIA_FROM_CAD_S_SOLUCOES_TITLE',
);
