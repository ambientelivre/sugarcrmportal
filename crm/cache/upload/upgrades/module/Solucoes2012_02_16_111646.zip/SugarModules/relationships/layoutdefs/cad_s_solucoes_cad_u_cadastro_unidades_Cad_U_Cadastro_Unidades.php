<?php
// created: 2012-01-25 15:16:41
$layout_defs["Cad_U_Cadastro_Unidades"]["subpanel_setup"]["cad_s_solucastro_unidades"] = array (
  'order' => 100,
  'module' => 'Cad_S_Solucoes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_S_SOLUCOES_CAD_U_CADASTRO_UNIDADES_FROM_CAD_S_SOLUCOES_TITLE',
  'get_subpanel_data' => 'cad_s_solucastro_unidades',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-01-25 15:19:29
$layout_defs["Cad_U_Cadastro_Unidades"]["subpanel_setup"]["cad_s_solucastro_unidades"] = array (
  'order' => 100,
  'module' => 'Cad_S_Solucoes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_S_SOLUCOES_CAD_U_CADASTRO_UNIDADES_FROM_CAD_S_SOLUCOES_TITLE',
  'get_subpanel_data' => 'cad_s_solucastro_unidades',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
