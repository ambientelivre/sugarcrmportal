<?php
// created: 2012-01-25 15:16:41
$layout_defs["cad_F_Cadastro_familia"]["subpanel_setup"]["cad_s_solucdastro_familia"] = array (
  'order' => 100,
  'module' => 'Cad_S_Solucoes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_S_SOLUCOES_CAD_F_CADASTRO_FAMILIA_FROM_CAD_S_SOLUCOES_TITLE',
  'get_subpanel_data' => 'cad_s_solucdastro_familia',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-01-25 15:19:29
$layout_defs["cad_F_Cadastro_familia"]["subpanel_setup"]["cad_s_solucdastro_familia"] = array (
  'order' => 100,
  'module' => 'Cad_S_Solucoes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CAD_S_SOLUCOES_CAD_F_CADASTRO_FAMILIA_FROM_CAD_S_SOLUCOES_TITLE',
  'get_subpanel_data' => 'cad_s_solucdastro_familia',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
