<?php
// created: 2014-12-23 09:50:35
$dictionary["ant_regionais"]["fields"]["ant_regionais_contacts"] = array (
  'name' => 'ant_regionais_contacts',
  'type' => 'link',
  'relationship' => 'ant_regionais_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_ANT_REGIONAIS_CONTACTS_FROM_CONTACTS_TITLE',
);
