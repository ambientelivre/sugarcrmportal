<?php
// created: 2014-11-27 11:26:43
$dictionary["ant_secretarias"]["fields"]["ant_regionant_secretarias"] = array (
  'name' => 'ant_regionant_secretarias',
  'type' => 'link',
  'relationship' => 'ant_regionais_ant_secretarias',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ANT_REGIONAIS_ANT_SECRETARIAS_FROM_ANT_REGIONAIS_TITLE',
);
