<?php
// created: 2014-11-27 09:01:49
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_secreta_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_SECRETARIAS_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_secreta_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 09:33:50
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_secreta_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_SECRETARIAS_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_secreta_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:40:37
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_secreta_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_SECRETARIAS_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_secreta_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:40:46
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_secreta_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_SECRETARIAS_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_secreta_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:40:52
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_secreta_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_SECRETARIAS_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_secreta_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:41:08
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_secreta_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_SECRETARIAS_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_secreta_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:41:20
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_secreta_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_SECRETARIAS_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_secreta_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
