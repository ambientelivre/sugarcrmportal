<?php
// created: 2014-12-23 09:50:36
$dictionary["ant_lista_pedidos"]["fields"]["ant_pedido__lista_pedidos"] = array (
  'name' => 'ant_pedido__lista_pedidos',
  'type' => 'link',
  'relationship' => 'ant_pedido_ant_lista_pedidos',
  'source' => 'non-db',
  'vname' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_PEDIDO_TITLE',
);
