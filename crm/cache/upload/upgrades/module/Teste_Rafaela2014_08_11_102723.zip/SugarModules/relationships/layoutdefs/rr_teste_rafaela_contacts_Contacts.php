<?php
// created: 2014-08-11 10:22:32
$layout_defs["Contacts"]["subpanel_setup"]["rr_teste_rafaela_contacts"] = array (
  'order' => 100,
  'module' => 'RR_Teste_Rafaela',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_RR_TESTE_RAFAELA_CONTACTS_FROM_RR_TESTE_RAFAELA_TITLE',
  'get_subpanel_data' => 'rr_teste_rafaela_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-11 10:27:23
$layout_defs["Contacts"]["subpanel_setup"]["rr_teste_rafaela_contacts"] = array (
  'order' => 100,
  'module' => 'RR_Teste_Rafaela',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_RR_TESTE_RAFAELA_CONTACTS_FROM_RR_TESTE_RAFAELA_TITLE',
  'get_subpanel_data' => 'rr_teste_rafaela_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
