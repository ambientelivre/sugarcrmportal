<?php
// created: 2014-08-11 10:27:23
$dictionary["Account"]["fields"]["rr_teste_rafaela_accounts"] = array (
  'name' => 'rr_teste_rafaela_accounts',
  'type' => 'link',
  'relationship' => 'rr_teste_rafaela_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_RR_TESTE_RAFAELA_ACCOUNTS_FROM_RR_TESTE_RAFAELA_TITLE',
);
