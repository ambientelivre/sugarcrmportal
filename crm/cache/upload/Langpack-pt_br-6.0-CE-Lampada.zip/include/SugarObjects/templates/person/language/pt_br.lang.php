<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_SALUTATION'                                   => 'Saudação',
'LBL_NAME'                                         => 'Nome',
'LBL_FIRST_NAME'                                   => 'Primeiro Nome',
'LBL_LAST_NAME'                                    => 'Sobrenome',
'LBL_TITLE'                                        => 'Título',
'LBL_DEPARTMENT'                                   => 'Departamento',
'LBL_DO_NOT_CALL'                                  => 'Não Ligar',
'LBL_HOME_PHONE'                                   => 'Telefone Residencial',
'LBL_MOBILE_PHONE'                                 => 'Celular',
'LBL_OFFICE_PHONE'                                 => 'Telefone Comercial',
'LBL_OTHER_PHONE'                                  => 'Outro Telefone',
'LBL_FAX_PHONE'                                    => 'Fax',
'LBL_EMAIL_ADDRESS'                                => 'Email',
'LBL_PRIMARY_ADDRESS'                              => 'Endereço Primário',
'LBL_PRIMARY_ADDRESS_STREET'                       => 'Rua Endereço Primário',
'LBL_PRIMARY_ADDRESS_STREET_2'                     => 'Rua 2 Endereço Primário',
'LBL_PRIMARY_ADDRESS_STREET_3'                     => 'Rua 3 Endereço Primário',
'LBL_PRIMARY_ADDRESS_CITY'                         => 'Cidade Primária',
'LBL_PRIMARY_ADDRESS_STATE'                        => 'Estado Primário',
'LBL_PRIMARY_ADDRESS_POSTALCODE'                   => 'CEP Primário',
'LBL_PRIMARY_ADDRESS_COUNTRY'                      => 'País Primário',
'LBL_ALT_ADDRESS_STREET'                           => 'Endereço Alternativo',
'LBL_ALT_ADDRESS_STREET_2'                         => 'Rua 2 Endereço Alternativo',
'LBL_ALT_ADDRESS_STREET_3'                         => 'Rua 3 Endereço Alternativo',
'LBL_ALT_ADDRESS_CITY'                             => 'Cidade Alternativa',
'LBL_ALT_ADDRESS_STATE'                            => 'Estado Alternativo',
'LBL_ALT_ADDRESS_POSTALCODE'                       => 'CEP Alternativo',
'LBL_ALT_ADDRESS_COUNTRY'                          => 'País Alternativo',
'LBL_COUNTRY'                                      => 'País',
'LBL_STREET'                                       => 'Outro Endereço',
'LBL_CITY'                                         => 'Cidade',
'LBL_STATE'                                        => 'Estado',
'LBL_POSTALCODE'                                   => 'CEP',
'LBL_POSTAL_CODE'                                  => 'CEP',
'LBL_CONTACT_INFORMATION'                          => 'Informação do Contato',
'LBL_ADDRESS_INFORMATION'                          => 'Endereço(os)',
'LBL_OTHER_EMAIL_ADDRESS'                          => 'Outro Email:',
'LBL_ASSIGNED_TO_NAME'                             => 'Atribuído a',
'LBL_ASSISTANT'                                    => 'Assistente',
'LBL_ASSISTANT_PHONE'                              => 'Telefone do Assistente',
'LBL_WORK_PHONE'                                   => 'Telefone Comercial',
'LNK_IMPORT_VCARD'                                 => 'Criar por vCard',
);?>
