<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'ACCOUNT_REMOVE_PROJECT_CONFIRM'                   => 'Você está certo que deseja remover esta conta deste projeto?',
'ERR_DELETE_RECORD'                                => 'Um número de registros deve ser especificado para deletar a conta',
'LBL_ACCOUNT_NAME'                                 => 'Nome:',
'LBL_ACCOUNT'                                      => 'Companhia:',
'LBL_ACTIVITIES_SUBPANEL_TITLE'                    => 'Atividades',
'LBL_ADDRESS_INFORMATION'                          => 'Informações da Conta',
'LBL_ANNUAL_REVENUE'                               => 'Receita Anual:',
'LBL_ANY_ADDRESS'                                  => 'Algum Endereço:',
'LBL_ANY_EMAIL'                                    => 'Algum Email:',
'LBL_ANY_PHONE'                                    => 'Algum Fone:',
'LBL_ASSIGNED_TO_NAME'                             => 'Atribuído a:',
'LBL_RATING'                                       => 'Avaliação',
'LBL_ASSIGNED_USER'                                => 'Atribuído a:',
'LBL_ASSIGNED_TO_ID'                               => 'Atribuído a:',
'LBL_BILLING_ADDRESS_CITY'                         => 'Cidade de Cobrança:',
'LBL_BILLING_ADDRESS_COUNTRY'                      => 'País de Cobrança:',
'LBL_BILLING_ADDRESS_POSTALCODE'                   => 'CEP de Cobrança:',
'LBL_BILLING_ADDRESS_STATE'                        => 'Estado de Cobrança:',
'LBL_BILLING_ADDRESS_STREET_2'                     => 'Rua de Cobrança 2',
'LBL_BILLING_ADDRESS_STREET_3'                     => 'Rua de Cobrança 3',
'LBL_BILLING_ADDRESS_STREET_4'                     => 'Rua de Cobrança 4',
'LBL_BILLING_ADDRESS_STREET'                       => 'Rua de Cobrança:',
'LBL_BILLING_ADDRESS'                              => 'Endereço de Cobrança:',
'LBL_ACCOUNT_INFORMATION'                          => 'Informação da Companhia',
'LBL_CITY'                                         => 'Cidade:',
'LBL_CONTACTS_SUBPANEL_TITLE'                      => 'Contatos',
'LBL_COUNTRY'                                      => 'País:',
'LBL_DATE_ENTERED'                                 => 'Data de criação:',
'LBL_DATE_MODIFIED'                                => 'Data de Modificação:',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Contas',
'LBL_DESCRIPTION_INFORMATION'                      => 'Informações de Descrição',
'LBL_DESCRIPTION'                                  => 'Descrição:',
'LBL_DUPLICATE'                                    => 'Possível Conta Duplicada',
'LBL_EMAIL'                                        => 'Email:',
'LBL_EMPLOYEES'                                    => 'Empregados:',
'LBL_FAX'                                          => 'Fax:',
'LBL_INDUSTRY'                                     => 'Negócio:',
'LBL_LIST_ACCOUNT_NAME'                            => 'Nome da Conta',
'LBL_LIST_CITY'                                    => 'Cidade',
'LBL_LIST_EMAIL_ADDRESS'                           => 'Endereço de Email',
'LBL_LIST_PHONE'                                   => 'Fone',
'LBL_LIST_STATE'                                   => 'Estado',
'LBL_LIST_WEBSITE'                                 => 'Website',
'LBL_MEMBER_OF'                                    => 'Membro de:',
'LBL_MEMBER_ORG_FORM_TITLE'                        => 'Organização Membro',
'LBL_MEMBER_ORG_SUBPANEL_TITLE'                    => 'Organização Membro',
'LBL_NAME'                                         => 'Nome:',
'LBL_OTHER_EMAIL_ADDRESS'                          => 'Outro Email:',
'LBL_OTHER_PHONE'                                  => 'Outro Fone:',
'LBL_OWNERSHIP'                                    => 'Propriedade:',
'LBL_PARENT_ACCOUNT_ID'                            => 'Id conta relacionada',
'LBL_PHONE_ALT'                                    => 'Fone Alternativo:',
'LBL_PHONE_FAX'                                    => 'Fax:',
'LBL_PHONE_OFFICE'                                 => 'Fone Comercial:',
'LBL_PHONE'                                        => 'Fone:',
'LBL_POSTAL_CODE'                                  => 'CEP:',
'LBL_PUSH_BILLING'                                 => 'Cobrança',
'LBL_PUSH_SHIPPING'                                => 'Entrega',
'LBL_SAVE_ACCOUNT'                                 => 'Salvar Conta',
'LBL_SHIPPING_ADDRESS_CITY'                        => 'Cidade de Entrega:',
'LBL_SHIPPING_ADDRESS_COUNTRY'                     => 'País de Entrega:',
'LBL_SHIPPING_ADDRESS_POSTALCODE'                  => 'CEP de Entrega:',
'LBL_SHIPPING_ADDRESS_STATE'                       => 'Estado de Entrega:',
'LBL_SHIPPING_ADDRESS_STREET_2'                    => 'Rua de Entrega 2',
'LBL_SHIPPING_ADDRESS_STREET_3'                    => 'Rua de Entrega 3',
'LBL_SHIPPING_ADDRESS_STREET_4'                    => 'Rua de Entrega 4',
'LBL_SHIPPING_ADDRESS_STREET'                      => 'Rua de Entrega:',
'LBL_SHIPPING_ADDRESS'                             => 'Endereço de Entrega:',
'LBL_STATE'                                        => 'Estado:',
'LBL_TEAMS_LINK'                                   => 'Equipes',
'LBL_TICKER_SYMBOL'                                => 'Código Bolsa',
'LBL_TYPE'                                         => 'Tipo:',
'LBL_USERS_ASSIGNED_LINK'                          => 'Atribuído para',
'LBL_USERS_CREATED_LINK'                           => 'Criado pelo usuário',
'LBL_USERS_MODIFIED_LINK'                          => 'Modificado pelo usuário',
'LBL_VIEW_FORM_TITLE'                              => 'Ver conta',
'LBL_WEBSITE'                                      => 'Website:',
'LNK_ACCOUNT_LIST'                                 => 'Contas',
'LNK_NEW_ACCOUNT'                                  => 'Nova Conta',
'MSG_DUPLICATE'                                    => 'Criando esta conta poderá criar uma conta duplicado. Você pode escolher uma conta na lista abaixo ou você pode clicar em Salvar para continuar a criar uma nova conta com os dados previamente descritos.',
'MSG_SHOW_DUPLICATES'                              => 'Criando esta conta poderá criar uma conta duplicado. Você pode clicar em Salvar para continuar a criar esta nova conta com os dados previamente descritos ou você pode clicar em Cancelar.',
'NTC_COPY_BILLING_ADDRESS'                         => 'Copiar endereço cobrança para endereço entrega',
'NTC_COPY_BILLING_ADDRESS2'                        => 'Copiar para Entrega',
'NTC_COPY_SHIPPING_ADDRESS'                        => 'Copiar endereço entrega para endereço cobrança',
'NTC_COPY_SHIPPING_ADDRESS2'                       => 'Copiar para Cobrança',
'NTC_DELETE_CONFIRMATION'                          => 'Deseja excluir esse registro?',
'NTC_REMOVE_ACCOUNT_CONFIRMATION'                  => 'Tem certeza que deseja excluir esse registro?',
'NTC_REMOVE_MEMBER_ORG_CONFIRMATION'               => 'Tem certeza que deseja remover este registro como uma organização membro?',
);?>
