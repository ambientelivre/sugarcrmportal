<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_NAME'                                         => 'Nome',
'LBL_NUMBER'                                       => 'Número:',
'LBL_STATUS'                                       => 'Status:',
'LBL_PRIORITY'                                     => 'Prioridade:',
'LBL_DESCRIPTION'                                  => 'Descrição:',
'LBL_RESOLUTION'                                   => 'Resolução',
'LBL_LAST_MODIFIED'                                => 'Última Modificção',
'LBL_ASSIGNED_TO_ID'                               => 'Atribuído a:',
'LBL_ASSIGNED_TO_NAME'                             => 'Atribuído a:',
'LBL_WORK_LOG'                                     => 'Descrição:',
'LBL_CREATED_BY'                                   => 'Criado Por:',
'LBL_DATE_CREATED'                                 => 'Criado em:',
'LBL_DATE_ENTERED'                                 => 'Criação:',
'LBL_DATE_MODIFIED'                                => 'Modificado em:',
'LBL_MODIFIED_BY'                                  => 'Modificado Por:',
'LBL_ASSIGNED_USER'                                => 'Atribuído a:',
'LBL_SYSTEM_ID'                                    => 'ID Sistema:',
'LBL_TEAM_NAME'                                    => 'Equipe:',
'LBL_TYPE'                                         => 'Tipo:',
'LBL_SUBJECT'                                      => 'Assunto:',
);?>
