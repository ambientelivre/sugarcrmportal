<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Venda',
'LBL_MODULE_TITLE'                                 => 'Venda: Principal',
'LBL_SEARCH_FORM_TITLE'                            => 'Busca Venda',
'LBL_VIEW_FORM_TITLE'                              => 'Ver Venda',
'LBL_LIST_FORM_TITLE'                              => 'Listar Vendas',
'LBL_SALE_NAME'                                    => 'Nome da Venda:',
'LBL_SALE'                                         => 'Venda:',
'LBL_NAME'                                         => 'Nome da Venda',
'LBL_LIST_SALE_NAME'                               => 'Nome',
'LBL_LIST_ACCOUNT_NAME'                            => 'Nome da Conta',
'LBL_LIST_AMOUNT'                                  => 'Valor',
'LBL_LIST_DATE_CLOSED'                             => 'Fechado',
'LBL_LIST_SALE_STAGE'                              => 'Estágio de Vendas',
'LBL_ACCOUNT_ID'                                   => 'ID Conta',
'LBL_CURRENCY_ID'                                  => 'ID Moeda',
'db_sales_stage'                                   => 'LBL_LIST_SALES_STAGE ',
'db_name'                                          => 'LBL_NAME ',
'db_amount'                                        => 'LBL_LIST_AMOUNT ',
'db_date_closed'                                   => 'LBL_LIST_DATE_CLOSED ',
'UPDATE'                                           => 'Venda - Atualizar Moeda',
'UPDATE_DOLLARAMOUNTS'                             => 'Atualizar Valor U.S. Dollar',
'UPDATE_VERIFY'                                    => 'Verificar Valores',
'UPDATE_VERIFY_TXT'                                => 'Verificar a quantidade de valores nas vendas são números decimais válidos somente com caracteres numéricos (0-9) e decimais (.)',
'UPDATE_FIX'                                       => 'Valores Fixos',
'UPDATE_FIX_TXT'                                   => 'Tentativas para corrigir qualquer valor inválido criando um decimal válido a partir da quantidade atual. Qualquer modificação na quantia é apoiada no campo do banco de dados amount_backup. Se você executar isso e verificar bugs, não execute-o sem a restauração do backup, pois pode substituir o backup com os novos dados inválidos.',
'UPDATE_DOLLARAMOUNTS_TXT'                         => 'Atualizar valores do U.S. Dollar para as vendas com base nas taxas da atual moeda definida',
'UPDATE_CREATE_CURRENCY'                           => 'Criando Nova Moeda:',
'UPDATE_VERIFY_FAIL'                               => 'Falha na Verificação de Regitros:',
'UPDATE_VERIFY_CURAMOUNT'                          => 'Valor Moeda:',
'UPDATE_VERIFY_FIX'                                => 'Verificando correção',
'UPDATE_INCLUDE_CLOSE'                             => 'Incluir Registrs Fechados',
'UPDATE_VERIFY_NEWAMOUNT'                          => 'Novo Valor:',
'UPDATE_VERIFY_NEWCURRENCY'                        => 'Nova Moeda:',
'UPDATE_DONE'                                      => 'Feito',
'UPDATE_BUG_COUNT'                                 => 'Bugs Encontrados e Tentados Resolver:',
'UPDATE_BUGFOUND_COUNT'                            => 'Bugs Encontrados:',
'UPDATE_COUNT'                                     => 'Atualizar Registros:',
'UPDATE_RESTORE_COUNT'                             => 'Restaurar Valores dos Registros:',
'UPDATE_RESTORE'                                   => 'Restaurar Registros:',
'UPDATE_RESTORE_TXT'                               => 'Restaurar quantidade de valores a partir de backups criados durante a correção.',
'UPDATE_FAIL'                                      => 'Não pode atualizar -',
'UPDATE_NULL_VALUE'                                => 'Valor é NULO determinando para 0 -',
'UPDATE_MERGE'                                     => 'Mesclar Moedas',
'UPDATE_MERGE_TXT'                                 => 'Mesclar moedas múltiplas em uma única moeda. Se possuir múltiplos registros de moedas para a mesma moeda, mesclá-las. Também será mesclado moedas para todos os outros módulos.',
'LBL_ACCOUNT_NAME'                                 => 'Nome da Conta:',
'LBL_AMOUNT'                                       => 'Valor:',
'LBL_AMOUNT_USDOLLAR'                              => 'Valor USD:',
'LBL_CURRENCY'                                     => 'Moeda:',
'LBL_DATE_CLOSED'                                  => 'Data de Previsão de Fechamento:',
'LBL_TYPE'                                         => 'Tipo:',
'LBL_CAMPAIGN'                                     => 'Campanha:',
'LBL_NEXT_STEP'                                    => 'Próxima Passo:',
'LBL_LEAD_SOURCE'                                  => 'Fonte do Potencial:',
'LBL_SALES_STAGE'                                  => 'Estágio de Vendas:',
'LBL_PROBABILITY'                                  => 'Probabilidade (%):',
'LBL_DESCRIPTION'                                  => 'Descrição:',
'LBL_DUPLICATE'                                    => 'Possível Duplicar Venda',
'MSG_DUPLICATE'                                    => 'O registro de venda que está prestes a criar poderá ser uma duplicação de um registro de venda que já existe. O registro contém nome similar ao listado abaixo: <br> Clique para continuar criando essa nova Venda, ou clique Cancelar para retornar para o módulo sem criar a venda.',
'LBL_NEW_FORM_TITLE'                               => 'Criar Venda',
'LNK_NEW_SALE'                                     => 'Nova Venda',
'LNK_SALE_LIST'                                    => 'Venda',
'ERR_DELETE_RECORD'                                => 'O número do registro deve ser especificado para deletar a venda.',
'LBL_TOP_SALES'                                    => 'Minhas Top Vendas Abertas',
'NTC_REMOVE_OPP_CONFIRMATION'                      => 'Tem certeza que deseja remover este contato da venda?',
'SALE_REMOVE_PROJECT_CONFIRM'                      => 'Tem certeza que deseja remover essa venda do projeto?',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Venda',
'LBL_ACTIVITIES_SUBPANEL_TITLE'                    => 'Atividades',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Histórico',
'LBL_RAW_AMOUNT'                                   => 'Valor Bruto',
'LBL_LEADS_SUBPANEL_TITLE'                         => 'Potenciais',
'LBL_CONTACTS_SUBPANEL_TITLE'                      => 'Contatos',
'LBL_PROJECTS_SUBPANEL_TITLE'                      => 'Projetos',
'LBL_ASSIGNED_TO_NAME'                             => 'Atribuído a:',
'LBL_LIST_ASSIGNED_TO_NAME'                        => 'Atribuído a:',
'LBL_MY_CLOSED_SALES'                              => 'Minhas Vendas Fechadas',
'LBL_TOTAL_SALES'                                  => 'Total de Vendas',
'LBL_CLOSED_WON_SALES'                             => 'Vendas Fechadas',
'LBL_ASSIGNED_TO_ID'                               => 'Atribuído a:',
'LBL_CREATED_ID'                                   => 'Criado por:',
'LBL_MODIFIED_ID'                                  => 'Modificado por:',
'LBL_MODIFIED_NAME'                                => 'Modificado por:',
'LBL_SALE_INFORMATION'                             => 'Informação da Venda',
);?>
