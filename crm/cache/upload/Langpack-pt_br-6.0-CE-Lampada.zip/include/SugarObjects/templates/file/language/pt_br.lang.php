<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Documentos',
'LBL_MODULE_TITLE'                                 => 'Documentos: Principal',
'LNK_NEW_DOCUMENT'                                 => 'Novo Documento',
'LNK_DOCUMENT_LIST'                                => 'Lista de Documentos',
'LBL_SEARCH_FORM_TITLE'                            => 'Busca Documento',
'LBL_DOCUMENT_ID'                                  => 'ID Documento',
'LBL_NAME'                                         => 'Nome do Documento',
'LBL_DESCRIPTION'                                  => 'Descrição',
'LBL_CATEGORY'                                     => 'Categoria',
'LBL_SUBCATEGORY'                                  => 'Sub categoria',
'LBL_STATUS'                                       => 'Status',
'LBL_IS_TEMPLATE'                                  => 'É um Modelo',
'LBL_TEMPLATE_TYPE'                                => 'Tipo do Documento',
'LBL_REVISION_NAME'                                => 'Número da Revisão',
'LBL_MIME'                                         => 'Tipo Mime',
'LBL_REVISION'                                     => 'Revisão',
'LBL_DOCUMENT'                                     => 'Documento relacionado',
'LBL_LATEST_REVISION'                              => 'Última Revisão',
'LBL_CHANGE_LOG'                                   => 'Mudar Log',
'LBL_ACTIVE_DATE'                                  => 'Data de Publicação',
'LBL_EXPIRATION_DATE'                              => 'Data de Expiração',
'LBL_FILE_EXTENSION'                               => 'Extensão do Arquivo',
'LBL_CAT_OR_SUBCAT_UNSPEC'                         => 'Não especificado',
'LBL_NEW_FORM_TITLE'                               => 'Novo Documento',
'LBL_DOC_NAME'                                     => 'Nome do Documento:',
'LBL_FILENAME'                                     => 'Nome do Arquivo:',
'LBL_DOC_VERSION'                                  => 'Revisão:',
'LBL_CATEGORY_VALUE'                               => 'Categoria:',
'LBL_SUBCATEGORY_VALUE'                            => 'Sub categoria:',
'LBL_DOC_STATUS'                                   => 'Status:',
'LBL_DET_TEMPLATE_TYPE'                            => 'Tipo do Documento:',
'LBL_DOC_DESCRIPTION'                              => 'Descrição:',
'LBL_DOC_ACTIVE_DATE'                              => 'Data de Publicação:',
'LBL_DOC_EXP_DATE'                                 => 'Data de Expiração:',
'LBL_LIST_FORM_TITLE'                              => 'Lista de Documentos',
'LBL_LIST_DOCUMENT'                                => 'Documento',
'LBL_LIST_CATEGORY'                                => 'Categoria',
'LBL_LIST_SUBCATEGORY'                             => 'Sub categoria',
'LBL_LIST_REVISION'                                => 'Revisão',
'LBL_LIST_LAST_REV_CREATOR'                        => 'Publicado por',
'LBL_LIST_LAST_REV_DATE'                           => 'Data de Revisão',
'LBL_LIST_VIEW_DOCUMENT'                           => 'Visualizar',
'LBL_LIST_DOWNLOAD'                                => 'Download',
'LBL_LIST_ACTIVE_DATE'                             => 'Data de Publicação',
'LBL_LIST_EXP_DATE'                                => 'Data de Expiração',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_SF_DOCUMENT'                                  => 'Nome do Documento:',
'LBL_SF_CATEGORY'                                  => 'Categoria:',
'LBL_SF_SUBCATEGORY'                               => 'Sub categoria:',
'LBL_SF_ACTIVE_DATE'                               => 'Data de Publicação:',
'LBL_SF_EXP_DATE'                                  => 'Data de Expiração:',
'DEF_CREATE_LOG'                                   => 'Documento Criado',
'ERR_DOC_NAME'                                     => 'Nome do Documento',
'ERR_DOC_ACTIVE_DATE'                              => 'Data de Publicação',
'ERR_DOC_EXP_DATE'                                 => 'Data de Expiração',
'ERR_FILENAME'                                     => 'Nome do Arquivo',
'LBL_TREE_TITLE'                                   => 'Documentos',
'LBL_LIST_DOCUMENT_NAME'                           => 'Nome do Documento',
);?>
