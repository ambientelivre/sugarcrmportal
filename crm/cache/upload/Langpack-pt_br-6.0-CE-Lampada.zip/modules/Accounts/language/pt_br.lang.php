<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'db_name'                                          => 'Nome da Conta',
'db_website'                                       => 'Website',
'db_billing_address_city'                          => 'Cidade',
'LBL_CHARTS'                                       => 'Gráficos',
'LBL_DEFAULT'                                      => 'Visualizações',
'LBL_MISC'                                         => 'Misc',
'LBL_UTILS'                                        => 'Uteis',
'ACCOUNT_REMOVE_PROJECT_CONFIRM'                   => 'Tem certeza que quer excluir esta conta deste projeto?',
'ERR_DELETE_RECORD'                                => 'Um número de registro deve ser especificado para excluir a conta.',
'LBL_ACCOUNT_INFORMATION'                          => 'Informação da Conta',
'LBL_ACCOUNT_NAME'                                 => 'Nome da Conta:',
'LBL_ACCOUNT'                                      => 'Conta:',
'LBL_ACTIVITIES_SUBPANEL_TITLE'                    => 'Atividades',
'LBL_ADDRESS_INFORMATION'                          => 'Informação de Endereço',
'LBL_ANNUAL_REVENUE'                               => 'Receita Anual:',
'LBL_ANY_ADDRESS'                                  => 'Endereço Qualquer:',
'LBL_ANY_EMAIL'                                    => 'Email Qualquer:',
'LBL_ANY_PHONE'                                    => 'Fone Qualquer:',
'LBL_ASSIGNED_TO_NAME'                             => 'Atribuído a:',
'LBL_ASSIGNED_TO_ID'                               => 'Atribuído a:',
'LBL_BILLING_ADDRESS_CITY'                         => 'Cidade Endereço de Cobrança:',
'LBL_BILLING_ADDRESS_COUNTRY'                      => 'País Endereço de Cobrança:',
'LBL_BILLING_ADDRESS_POSTALCODE'                   => 'CEP Endereço de Cobrança:',
'LBL_BILLING_ADDRESS_STATE'                        => 'Estado Endereço de Cobrança:',
'LBL_BILLING_ADDRESS_STREET_2'                     => 'Endereço de Cobrança 2',
'LBL_BILLING_ADDRESS_STREET_3'                     => 'Endereço de Cobrança 3',
'LBL_BILLING_ADDRESS_STREET_4'                     => 'Endereço de Cobrança 4',
'LBL_BILLING_ADDRESS_STREET'                       => 'Rua Endereço de Cobrança:',
'LBL_BILLING_ADDRESS'                              => 'Endereço Cobrança:',
'LBL_BUG_FORM_TITLE'                               => 'Contas',
'LBL_BUGS_SUBPANEL_TITLE'                          => 'Bugs',
'LBL_CALLS_SUBPANEL_TITLE'                         => 'Ligações',
'LBL_CAMPAIGN_ID'                                  => 'ID Campanha',
'LBL_CASES_SUBPANEL_TITLE'                         => 'Ocorrências',
'LBL_CITY'                                         => 'Cidade:',
'LBL_CONTACTS_SUBPANEL_TITLE'                      => 'Contatos',
'LBL_COUNTRY'                                      => 'País:',
'LBL_DATE_ENTERED'                                 => 'Data Inclusão:',
'LBL_DATE_MODIFIED'                                => 'Data Modificação:',
'LBL_MODIFIED_ID'                                  => 'Modificado Por',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Contas',
'LBL_DESCRIPTION_INFORMATION'                      => 'Informação de Descrição',
'LBL_DESCRIPTION'                                  => 'Descrição:',
'LBL_DUPLICATE'                                    => 'Possível Conta Duplicada',
'LBL_EMAIL'                                        => 'Email:',
'LBL_EMAIL_OPT_OUT'                                => 'Optou por sair dos emails',
'LBL_EMPLOYEES'                                    => 'Funcionários:',
'LBL_FAX'                                          => 'Fax:',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Histórico',
'LBL_HOMEPAGE_TITLE'                               => 'Minhas Contas',
'LBL_INDUSTRY'                                     => 'Negócio:',
'LBL_INVALID_EMAIL'                                => 'Email Inválido',
'LBL_INVITEE'                                      => 'Contatos',
'LBL_LEADS_SUBPANEL_TITLE'                         => 'Potenciais',
'LBL_LIST_ACCOUNT_NAME'                            => 'Nome da Conta',
'LBL_LIST_CITY'                                    => 'Cidade',
'LBL_LIST_CONTACT_NAME'                            => 'Nome do Contato',
'LBL_LIST_EMAIL_ADDRESS'                           => 'Endereço de Email',
'LBL_LIST_FORM_TITLE'                              => 'Lista de Contas',
'LBL_LIST_PHONE'                                   => 'Fone',
'LBL_LIST_STATE'                                   => 'Estado',
'LBL_LIST_WEBSITE'                                 => 'Website',
'LBL_MEETINGS_SUBPANEL_TITLE'                      => 'Reuniões',
'LBL_MEMBER_OF'                                    => 'Membro de:',
'LBL_MEMBER_ORG_FORM_TITLE'                        => 'Organizações Membro',
'LBL_MEMBER_ORG_SUBPANEL_TITLE'                    => 'Organizações Membro',
'LBL_MODULE_NAME'                                  => 'Contas',
'LBL_MODULE_TITLE'                                 => 'Contas: Principal',
'LBL_MODULE_ID'                                    => 'Contas',
'LBL_NAME'                                         => 'Nome:',
'LBL_NEW_FORM_TITLE'                               => 'Nova Conta',
'LBL_OPPORTUNITIES_SUBPANEL_TITLE'                 => 'Oportunidades',
'LBL_OTHER_EMAIL_ADDRESS'                          => 'Outro Email:',
'LBL_OTHER_PHONE'                                  => 'Outro Fone:',
'LBL_OWNERSHIP'                                    => 'Propriedade:',
'LBL_PARENT_ACCOUNT_ID'                            => 'ID Conta Principal',
'LBL_PHONE_ALT'                                    => 'Fone Alternativo:',
'LBL_PHONE_FAX'                                    => 'Fax:',
'LBL_PHONE_OFFICE'                                 => 'Fone Comercial:',
'LBL_PHONE'                                        => 'Fone:',
'LBL_POSTAL_CODE'                                  => 'CEP:',
'LBL_PRODUCTS_TITLE'                               => 'Produtos',
'LBL_PROJECTS_SUBPANEL_TITLE'                      => 'Projetos',
'LBL_PUSH_BILLING'                                 => 'Cobrança',
'LBL_PUSH_CONTACTS_BUTTON_LABEL'                   => 'Copiar para Contatos',
'LBL_PUSH_CONTACTS_BUTTON_TITLE'                   => 'Copiar...',
'LBL_PUSH_SHIPPING'                                => 'Entrega',
'LBL_RATING'                                       => 'Avaliação:',
'LBL_SAVE_ACCOUNT'                                 => 'Salvar Conta',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar Contas',
'LBL_SHIPPING_ADDRESS_CITY'                        => 'Cidade Endereço de Entrega:',
'LBL_SHIPPING_ADDRESS_COUNTRY'                     => 'País Endereço de Entrega:',
'LBL_SHIPPING_ADDRESS_POSTALCODE'                  => 'CEP Endereço de Entrega:',
'LBL_SHIPPING_ADDRESS_STATE'                       => 'Estado Endereço de Entrega:',
'LBL_SHIPPING_ADDRESS_STREET_2'                    => 'Endereço de Entrega 2',
'LBL_SHIPPING_ADDRESS_STREET_3'                    => 'Endereço de Entrega 3',
'LBL_SHIPPING_ADDRESS_STREET_4'                    => 'Endereço de Entrega 4',
'LBL_SHIPPING_ADDRESS_STREET'                      => 'Rua Endereço de Entrega:',
'LBL_SHIPPING_ADDRESS'                             => 'Endereço Entrega:',
'LBL_SIC_CODE'                                     => 'Código SIC:',
'LBL_STATE'                                        => 'Estado:',
'LBL_TASKS_SUBPANEL_TITLE'                         => 'Tarefas',
'LBL_TEAMS_LINK'                                   => 'Equipes',
'LBL_TICKER_SYMBOL'                                => 'Código Bolsa:',
'LBL_TYPE'                                         => 'Tipo:',
'LBL_USERS_ASSIGNED_LINK'                          => 'Usuários Atribuídos',
'LBL_USERS_CREATED_LINK'                           => 'Criado pelos Usuários',
'LBL_USERS_MODIFIED_LINK'                          => 'Usuários Modificados',
'LBL_VIEW_FORM_TITLE'                              => 'Visualização da Conta',
'LBL_WEBSITE'                                      => 'Website:',
'LBL_CREATED_ID'                                   => 'Criado por:',
'LBL_CAMPAIGNS'                                    => 'Campanhas',
'LNK_ACCOUNT_LIST'                                 => 'Contas',
'LNK_NEW_ACCOUNT'                                  => 'Nova Conta',
'MSG_DUPLICATE'                                    => 'O registo da conta que você está prestes a criar pode ser duplicado de uma outra conta já existe. Registro da conta contendo nomes semelhantes estão listados abaixo. <br> Clique em Salvar para continuar a criar essa nova conta, ou clique em Cancelar para retornar para o módulo sem criar a conta.',
'MSG_SHOW_DUPLICATES'                              => 'O registo da conta que você está prestes a criar pode ser duplicado de uma outra conta já existe. Registro da conta contendo nomes semelhantes estão listados abaixo. <br> Clique em Salvar para continuar a criar essa nova conta, ou clique em Cancelar para retornar para o módulo sem criar a conta.',
'NTC_COPY_BILLING_ADDRESS'                         => 'Copiar endereço cobrança para endereço entrega',
'NTC_COPY_BILLING_ADDRESS2'                        => 'Copiar para Entrega',
'NTC_COPY_SHIPPING_ADDRESS'                        => 'Copiar endereço entrega para endereço cobrança',
'NTC_COPY_SHIPPING_ADDRESS2'                       => 'Copiar para Cobrança',
'NTC_DELETE_CONFIRMATION'                          => 'Deseja excluir esse registro?',
'NTC_REMOVE_ACCOUNT_CONFIRMATION'                  => 'Tem certeza que deseja excluir esse registro?',
'NTC_REMOVE_MEMBER_ORG_CONFIRMATION'               => 'Tem certeza que deseja remover este registro como uma organização membro?',
'LBL_ASSIGNED_USER_NAME'                           => 'Atribuído para:',
'LBL_PROSPECT_LIST'                                => 'Lista Prospeto',
'LBL_ACCOUNTS_SUBPANEL_TITLE'                      => 'Contas',
'LBL_PROJECT_SUBPANEL_TITLE'                       => 'Projetos',
'LNK_IMPORT_ACCOUNTS'                              => 'Importar Contas',
);?>
