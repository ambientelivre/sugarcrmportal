<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'ERR_DELETE_RECORD'                                => 'Um número de registro deve ser especificado para excluir a Ocorrência.',
'LBL_ACCOUNT_ID'                                   => 'ID da Conta',
'LBL_ACCOUNT_NAME'                                 => 'Nome da Conta:',
'LBL_ACCOUNTS_SUBPANEL_TITLE'                      => 'Contas',
'LBL_ACTIVITIES_SUBPANEL_TITLE'                    => 'Atividades',
'LBL_ATTACH_NOTE'                                  => 'Anexar Anotação',
'LBL_BUGS_SUBPANEL_TITLE'                          => 'Bugs',
'LBL_CASE_NUMBER'                                  => 'Número da Ocorrência:',
'LBL_CASE_SUBJECT'                                 => 'Assunto da Ocorrência:',
'LBL_CASE'                                         => 'Ocorrência:',
'LBL_CONTACT_CASE_TITLE'                           => 'Contato-Ocorrência:',
'LBL_CONTACT_NAME'                                 => 'Nome do Contato:',
'LBL_CONTACT_ROLE'                                 => 'Perfil:',
'LBL_CONTACTS_SUBPANEL_TITLE'                      => 'Contatos',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Ocorrências',
'LBL_DESCRIPTION'                                  => 'Descrição:',
'LBL_FILENANE_ATTACHMENT'                          => 'Arquivo anexado',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Histórico',
'LBL_INVITEE'                                      => 'Contatos',
'LBL_MEMBER_OF'                                    => 'Conta',
'LBL_MODULE_NAME'                                  => 'Ocorrências',
'LBL_MODULE_TITLE'                                 => 'Ocorrências: Principal',
'LBL_NEW_FORM_TITLE'                               => 'Nova Ocorrências',
'LBL_NUMBER'                                       => 'Número:',
'LBL_PRIORITY'                                     => 'Prioridade:',
'LBL_PROJECTS_SUBPANEL_TITLE'                      => 'Projetos',
'LBL_RESOLUTION'                                   => 'Resolução:',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar Ocorrências',
'LBL_STATUS'                                       => 'Situação:',
'LBL_SUBJECT'                                      => 'Assunto:',
'LBL_SYSTEM_ID'                                    => 'ID do Sistema',
'LBL_LIST_ASSIGNED_TO_NAME'                        => 'Usuário atribuído',
'LBL_LIST_ACCOUNT_NAME'                            => 'Nome da Conta',
'LBL_LIST_ASSIGNED'                                => 'Designado para',
'LBL_LIST_CLOSE'                                   => 'Concluir',
'LBL_LIST_FORM_TITLE'                              => 'Lista de Ocorrências',
'LBL_LIST_LAST_MODIFIED'                           => 'Última Alteração',
'LBL_LIST_MY_CASES'                                => 'Minhas Ocorrências Abertas',
'LBL_LIST_NUMBER'                                  => 'Núm.',
'LBL_LIST_PRIORITY'                                => 'Prioridade',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_LIST_SUBJECT'                                 => 'Assunto',
'LNK_CASE_LIST'                                    => 'Ocorrências',
'LNK_NEW_CASE'                                     => 'Nova Ocorrência',
'NTC_REMOVE_FROM_BUG_CONFIRMATION'                 => 'Tem certeza que quer remover esta Ocorrência a partir deste bug?',
'NTC_REMOVE_INVITEE'                               => 'Tem certeza que quer remover este contato da Ocorrência?',
'LBL_LIST_DATE_CREATED'                            => 'Data de Criação',
'LBL_ASSIGNED_TO_NAME'                             => 'Atribuído a:',
'LBL_TYPE'                                         => 'Tipo:',
'LBL_WORK_LOG'                                     => 'Log de Trabalho',
'LBL_CREATED_USER'                                 => 'Criado por',
'LBL_MODIFIED_USER'                                => 'Modificado por',
'LBL_PROJECT_SUBPANEL_TITLE'                       => 'Projetos',
'LNK_IMPORT_CASES'                                 => 'Importar Ocorrências',
'LBL_CASE_INFORMATION'                             => 'Principal Ocorrência',

);?>
