<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'ERR_DELETE_RECORD'                                => 'Para excluir uma reunião um número de registro deve ser especificado.',
'LBL_ACCEPT_THIS'                                  => 'Aceitar?',
'LBL_ADD_BUTTON'                                   => 'Adicionar',
'LBL_ADD_INVITEE'                                  => 'Adicionar convidados',
'LBL_COLON'                                        => ':',
'LBL_CONTACT_NAME'                                 => 'Contato: ',
'LBL_CONTACTS_SUBPANEL_TITLE'                      => 'Contatos',
'LBL_CREATED_BY'                                   => 'Criado por',
'LBL_DATE_END'                                     => 'Data de término',
'LBL_DATE_TIME'                                    => 'Data e hora de início:',
'LBL_DATE'                                         => 'Data de início:',
'LBL_DEFAULT_STATUS'                               => 'Planejada',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Reuniões',
'LBL_DEL'                                          => 'Remover',
'LBL_DESCRIPTION_INFORMATION'                      => 'Informações da Descrição',
'LBL_DESCRIPTION'                                  => 'Descrição:',
'LBL_DURATION_HOURS'                               => 'Duração (horas):',
'LBL_DURATION_MINUTES'                             => 'Duração (minutos):',
'LBL_DURATION'                                     => 'Duração:',
'LBL_EMAIL'                                        => 'E-mail',
'LBL_FIRST_NAME'                                   => 'Nome',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Notas',
'LBL_HOURS_ABBREV'                                 => 'h',
'LBL_HOURS_MINS'                                   => '(horas/minutos)',
'LBL_INVITEE'                                      => 'Convidados',
'LBL_LAST_NAME'                                    => 'Sobrenome',
'LBL_ASSIGNED_TO_NAME'                             => 'Atribuído a:',
'LBL_LIST_ASSIGNED_TO_NAME'                        => 'Atribuído a:',
'LBL_LIST_CLOSE'                                   => 'Fechar',
'LBL_LIST_CONTACT'                                 => 'Contato',
'LBL_LIST_DATE_MODIFIED'                           => 'Data da modificação',
'LBL_LIST_DATE'                                    => 'Data de início',
'LBL_LIST_DUE_DATE'                                => 'Prazo',
'LBL_LIST_FORM_TITLE'                              => 'Listar reuniões',
'LBL_LIST_MY_MEETINGS'                             => 'Minhas Reuniões',
'LBL_LIST_RELATED_TO'                              => 'Referente a',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_LIST_SUBJECT'                                 => 'Assunto',
'LBL_LIST_TIME'                                    => 'Hora de início',
'LBL_LEADS_SUBPANEL_TITLE'                         => 'Potenciais',
'LBL_LOCATION'                                     => 'Local:',
'LBL_MEETING'                                      => 'Reunião:',
'LBL_MINSS_ABBREV'                                 => 'm',
'LBL_MODIFIED_BY'                                  => 'Modificado por',
'LBL_MODULE_NAME'                                  => 'Reuniões',
'LBL_MODULE_TITLE'                                 => 'Reuniões: Principal',
'LBL_NAME'                                         => 'Nome completo',
'LBL_NEW_FORM_TITLE'                               => 'Agendar reunião',
'LBL_OUTLOOK_ID'                                   => 'Outlook ID',
'LBL_PHONE'                                        => 'Telefone',
'LBL_REMINDER_TIME'                                => 'Hora do lembrete',
'LBL_REMINDER'                                     => 'Lembrete:',
'LBL_SCHEDULING_FORM_TITLE'                        => 'Agendamento',
'LBL_SEARCH_BUTTON'                                => 'Buscar',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar reuniões',
'LBL_SEND_BUTTON_KEY'                              => 'I',
'LBL_SEND_BUTTON_LABEL'                            => 'Enviar convites',
'LBL_SEND_BUTTON_TITLE'                            => 'Enviar convites [Alt+I]',
'LBL_STATUS'                                       => 'Status:',
'LBL_SUBJECT'                                      => 'Assunto: ',
'LBL_TIME'                                         => 'Hora de início:',
'LBL_USERS_SUBPANEL_TITLE'                         => 'Usuários',
'LBL_ACTIVITIES_REPORTS'                           => 'Relatório de Atividades',
'LNK_CALL_LIST'                                    => 'Ligações',
'LNK_EMAIL_LIST'                                   => 'E-mails',
'LNK_MEETING_LIST'                                 => 'Reuniões',
'LNK_NEW_APPOINTMENT'                              => 'Criar Compromisso',
'LNK_NEW_CALL'                                     => 'Agendar Ligação',
'LNK_NEW_EMAIL'                                    => 'Arquivar E-mail',
'LNK_NEW_MEETING'                                  => 'Agendar Reunião',
'LNK_NEW_NOTE'                                     => 'Criar Anotação ou Anexo',
'LNK_NEW_TASK'                                     => 'Criar Tarefa',
'LNK_NOTE_LIST'                                    => 'Anotações',
'LNK_TASK_LIST'                                    => 'Tarefas',
'LNK_VIEW_CALENDAR'                                => 'Hoje',
'NTC_REMOVE_INVITEE'                               => 'Tem certeza que deseja remover este convidado da Reunião?',
'LBL_CREATED_USER'                                 => 'Criado por',
'LBL_MODIFIED_USER'                                => 'Modificado por',
'NOTICE_DURATION_TIME'                             => 'Tempo de duração deve ser maior que 0',
'LBL_LIST_DIRECTION'                               => 'Direção',
'LNK_IMPORT_MEETINGS'                            => 'Importar Reuniões',
'LBL_MEETING_INFORMATION'                          => 'Principal Reuniões ',
'LNK_IMPORT_MEETINGS'							   =>'Importar Reuniões',

);?>
