<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Lista de Prospectos',
'LBL_MODULE_ID'                                    => 'Lista de Prospectos',
'LBL_MODULE_TITLE'                                 => 'Lista de Prospectos: Principal',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar Lista de Prospectos',
'LBL_LIST_FORM_TITLE'                              => 'Lista de Prospectos',
'LBL_PROSPECT_LIST_NAME'                           => 'Lista de Prospectos:',
'LBL_NAME'                                         => 'Nome',
'LBL_ENTRIES'                                      => 'Total de Entradas',
'LBL_LIST_PROSPECT_LIST_NAME'                      => 'Lista de Prospectos',
'LBL_LIST_ENTRIES'                                 => 'Prospectos na Lista',
'LBL_LIST_DESCRIPTION'                             => 'Descrição',
'LBL_LIST_TYPE_NO'                                 => 'Tipo',
'LBL_LIST_END_DATE'                                => 'Data Final',
'LBL_DATE_ENTERED'                                 => 'Data Entrada',
'LBL_DATE_MODIFIED'                                => 'Data de Modificação',
'LBL_MODIFIED'                                     => 'Modificado por: ',
'LBL_CREATED'                                      => 'Criado por: ',
'LBL_TEAM'                                         => 'Equipe',
'LBL_ASSIGNED_TO'                                  => 'Atribuído a',
'LBL_DESCRIPTION'                                  => 'Descrição',
'LNK_NEW_CAMPAIGN'                                 => 'Nova Campanha',
'LNK_CAMPAIGN_LIST'                                => 'Campanhas',
'LNK_NEW_PROSPECT_LIST'                            => 'Nova Lista de Prospectos',
'LNK_PROSPECT_LIST_LIST'                           => 'Lista de Prospectos',
'LBL_MODIFIED_BY'                                  => 'Modificado por',
'LBL_CREATED_BY'                                   => 'Criado por',
'LBL_DATE_CREATED'                                 => 'Data Criação',
'LBL_DATE_LAST_MODIFIED'                           => 'Data Modificação',
'LNK_NEW_PROSPECT'                                 => 'Novo Prospecto',
'LNK_PROSPECT_LIST'                                => 'Prospectos',
'LBL_PROSPECT_LISTS_SUBPANEL_TITLE'                => 'Listas de Prospectos',
'LBL_CONTACTS_SUBPANEL_TITLE'                      => 'Contatos',
'LBL_LEADS_SUBPANEL_TITLE'                         => 'Potenciais',
'LBL_PROSPECTS_SUBPANEL_TITLE'                     => 'Prospectos',
'LBL_ACCOUNTS_SUBPANEL_TITLE'                      => 'Contas',
'LBL_COPY_PREFIX'                                  => 'Cópia de',
'LBL_USERS_SUBPANEL_TITLE'                         => 'Usuários',
'LBL_TYPE'                                         => 'Tipo',
'LBL_LIST_TYPE'                                    => 'Tipo:',
'LBL_LIST_TYPE_LIST_NAME'                          => 'Tipo',
'LBL_NEW_FORM_TITLE'                               => 'Nova Lista de Prospectos',
'LBL_MARKETING_MESSAGE'                            => 'Mensagem de Marketing por Email',
'LBL_DOMAIN_NAME'                                  => 'Nome do Domínio',
'LBL_DOMAIN'                                       => 'Não enviar para este Domínio',
'LBL_LIST_PROSPECTLIST_NAME'                       => 'Nome',
);?>
