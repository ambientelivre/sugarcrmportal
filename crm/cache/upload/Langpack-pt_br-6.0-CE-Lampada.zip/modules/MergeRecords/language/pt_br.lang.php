<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Mesclar Registros',
'LBL_MODULE_TITLE'                                 => 'Mesclar Registros: Principal',
'LBL_SEARCH_FORM_TITLE'                            => 'Mesclar Busca',
'LBL_LIST_FORM_TITLE'                              => 'Mesclar Lista',
'LBL_LBL_MERGE_RECORDS_STEP_1'                     => 'Passo 1: Procure a busca para mesclar com',
'LBL_AVAIL_FIELDS'                                 => 'Campos disponíveis',
'LBL_FILTER_COND'                                  => 'Condição do Filtro',
'LBL_SELECTED_FIELDS'                              => 'Campos selecionados',
'LBL_MERGE_RECORDS_WITH'                           => 'Mesclar registros com',
'LBL_MERGE_VALUE_OVER'                             => 'Mesclar valor sobre',
'LBL_NEXT_STEP_TITLE'                              => 'Mover para próximo passo [ Ctrl+N]',
'LBL_NEXT_STEP_BUTTON_KEY'                         => 'N',
'LBL_NEXT_STEP_BUTTON_LABEL'                       => 'Próximo Passo >',
'LBL_PERFORM_MERGE_BUTTON_TITLE'                   => 'Mesclar Performance [Ctrl+P]',
'LBL_PERFORM_MERGE_BUTTON_KEY'                     => 'P',
'LBL_PERFORM_MERGE_BUTTON_LABEL'                   => 'Mesclar Performance',
'LBL_SAVE_MERGED_RECORD_BUTTON_TITLE'              => 'Salvar Mesclar [Ctrl+S] ',
'LBL_SAVE_MERGED_RECORD_BUTTON_KEY'                => 'S',
'LBL_SAVE_MERGED_RECORD_BUTTON_LABEL'              => 'Salvar Mesclar',
'LBL_STEP2_FORM_TITLE'                             => 'Registros encontrados para mesclar com:',
'LBL_SELECT_ERROR'                                 => 'Você deve fazer a seleção antes que você possa continuar',
'LBL_SELECT_PRIMARY'                               => 'Selecione o registro primário para mesclar.',
'LBL_CHANGE_PARENT'                                => 'Definir como primário',
'LBL_REMOVE_FROM_MERGE'                            => 'Remover',
'LBL_DIFF_COL_VALUES'                              => 'Colunas no qual os valores na linha primária difere dos valores das colunas mescladas:',
'LBL_SAME_COL_VALUES'                              => 'Colunas no qual os valores são similares através de todas as linhas:',
'ERR_EXCEEDS_MAX'                                  => 'Você é somente autorizado a mesclar no máximo de 5 registros. Registros excedentes ao limite foram ignorados.',
'LBL_DELETE_MESSAGE'                               => 'Esta ação apagará o seguinte registro(s):',
'LBL_PROCEED'                                      => 'Proceder?',
'LBL_STEP1_DIRECTIONS'                             => 'Encontre possíveis registros duplicados. Se encontrar possíveis duplicados, você pode selecionar os registros que deseja mesclar com o registro atual. ',

);?>
