<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_ADD_MODULE'                                   => 'Adicionar',
'LBL_ADDRCITY'                                     => 'Cidade',
'LBL_ADDRCOUNTRY'                                  => 'País',
'LBL_ADDRCOUNTRY_ID'                               => 'id País',
'LBL_ADDRSTATEPROV'                                => 'Estado',
'LBL_ADMINISTRATION'                               => 'Administração do Conector',
'LBL_ADMINISTRATION_MAIN'                          => 'Configurações do Conector',
'LBL_AVAILABLE'                                    => 'Disponível',
'LBL_BACK'                                         => '< Voltar',
'LBL_COMPANY_ID'                                   => 'Id da Empresa',
'LBL_CONFIRM_CONTINUE_SAVE'                        => 'Alguns campos obrigatórios foram deixados em branco. Prossiga para salvar alterações?',
'LBL_CONNECTOR'                                    => 'Conector',
'LBL_CONNECTOR_FIELDS'                             => 'Campos do Conector',
'LBL_DATA'                                         => 'Dados',
'LBL_DEFAULT'                                      => 'Padrão',
'LBL_DELETE_MAPPING_ENTRY'                         => 'Você está certo que deseja deletar está entrada?',
'LBL_DISABLED'                                     => 'Desabilitado',
'LBL_DUNS'                                         => 'DUNS',
'LBL_EMPTY_BEANS'                                  => 'Nenhum resultado foi encontrado para sua pesquisa.',
'LBL_ENABLED'                                      => 'Habilitado',
'LBL_FINSALES'                                     => 'Finsales',
'LBL_MARKET_CAP'                                   => 'Market Cap',
'LBL_MERGE'                                        => 'Mesclar',
'LBL_MODIFY_DISPLAY_TITLE'                         => 'Habilitar Conectores',
'LBL_MODIFY_DISPLAY_DESC'                          => 'Selecione os módulos que são ativados para cada conector.',
'LBL_MODIFY_DISPLAY_PAGE_TITLE'                    => 'Configurações do Conector: Habilitar Conexões',
'LBL_MODULE_FIELDS'                                => 'Campos dos Módulos',
'LBL_MODIFY_MAPPING_TITLE'                         => 'Mapa de Campos Conectados',
'LBL_MODIFY_MAPPING_DESC'                          => 'Mapa de campos Conectados aos campos do módulo a fim de determinar quais os dados conectados podem ser visualizados e mesclados dentro do registro do módulo',
'LBL_MODIFY_MAPPING_PAGE_TITLE'                    => 'Configurações do Conector: Mapa de Campos Conectados',
'LBL_MODIFY_PROPERTIES_TITLE'                      => 'Configurar Propriedades do Conector',
'LBL_MODIFY_PROPERTIES_DESC'                       => 'Configure as propriedades de cada conector, incluindo chaves URLs e API',
'LBL_MODIFY_PROPERTIES_PAGE_TITLE'                 => 'Configurações do Conector: Configurar Propriedades do Conector',
'LBL_MODIFY_SEARCH_TITLE'                          => 'Gerenciar Buscas de Conexões ',
'LBL_MODIFY_SEARCH'                                => 'Buscas',
'LBL_MODIFY_SEARCH_DESC'                           => 'Selecione os campos do conector para usar a busca para dados de cada módulo',
'LBL_MODIFY_SEARCH_PAGE_TITLE'                     => 'Configurações do Conector: Gerencia de busca do Conector',
'LBL_MODULE_NAME'                                  => 'Conectores',
'LBL_NO_PROPERTIES'                                => 'Não existem propriedades configuráveis para este conector',
'LBL_PARENT_DUNS'                                  => 'Relacionamento DUNS',
'LBL_PREVIOUS'                                     => '< Voltar',
'LBL_QUOTE'                                        => 'Corações',
'LBL_RECNAME'                                      => 'Nome Empresa',
'LBL_RESET_TO_DEFAULT'                             => 'Restauras Configurações Padrões',
'LBL_RESET_TO_DEFAULT_CONFIRM'                     => 'Você esta certo que deseja restaurar as configurações padrões?',
'LBL_RESET_BUTTON_TITLE'                           => 'Restaurar [Alt + R]',
'LBL_RESULT_LIST'                                  => 'Lista de Dados',
'LBL_RUN_WIZARD'                                   => 'Executar Assistente',
'LBL_SAVE'                                         => 'Salvar',
'LBL_SEARCHING_BUTTON_LABEL'                       => 'Procurando...',
'LBL_SHOW_IN_LISTVIEW'                             => 'Mostrar Lista de Mesclas',
'LBL_SMART_COPY'                                   => 'Cópia inteligente',
'LBL_SUMMARY'                                      => 'Sumário',
'LBL_STEP1'                                        => 'Busca e Visualização dos dados',
'LBL_STEP2'                                        => 'Mesclar registros com',
'LBL_TEST_SOURCE'                                  => 'Testar Conexões',
'LBL_TEST_SOURCE_FAILED'                           => 'Falha no Teste',
'LBL_TEST_SOURCE_RUNNING'                          => 'Teste de Performance...',
'LBL_TEST_SOURCE_SUCCESS'                          => 'Teste com sucesso',
'LBL_TITLE'                                        => 'Mesclar Dados',
'LBL_ULTIMATE_PARENT_DUNS'                         => 'Ultimate Parent DUNS',
'ERROR_RECORD_NOT_SELECTED'                        => 'Erro: Por favor selecione um registro na lista abaixo',
'ERROR_EMPTY_WRAPPER'                              => 'Erro: Não foi possível recuperar o exemplo wrapper para a fonte [{$source_id}] ',
'ERROR_EMPTY_SOURCE_ID'                            => 'Erro: Origem não especificado ou vazio',
'ERROR_EMPTY_RECORD_ID'                            => 'Erro: Registro não especificado ou vazio',
'ERROR_NO_ADDITIONAL_DETAIL'                       => 'Erro: Não foram encontrados detalhes adicionais para o registo.',
'ERROR_NO_SEARCHDEFS_DEFINED'                      => 'Nenhum módulo foi habilitado para este conector. Selecione um módulo para este conector na página Habilitar Conectores',
'ERROR_NO_SOURCEDEFS_FILE'                         => 'Erro: O Arquivo sourcedefs.php não pode ser encontrado',
'ERROR_NO_SOURCEDEFS_SPECIFIED'                    => 'Erro: Não foi especificada a fontes para recuperar os dados.',
'ERROR_NO_CONNECTOR_DISPLAY_CONFIG_FILE'           => 'Erro: Não existem conexões mapeadas para este módulo',
'ERROR_NO_SEARCHDEFS_MAPPING'                      => 'Erro: Não existem campos de buscas definidas para o módulo e conector. Por favor entre em contato com o Administrador',
'ERROR_NO_FIELDS_MAPPED'                           => 'Erro: Você deve mapear pelo menos um campo Conector para o campo do módulo para cada entrada no módulo',
'ERROR_NO_DISPLAYABLE_MAPPED_FIELDS'               => 'Erro: Não existem campos do módulo que foram mapeados para a exibição nos resultados. Entre em contato com o administrador do sistema.',
'ERROR_NO_SEARCHDEFS_MAPPED'                       => 'Erro: Não há conectores habilitados que tenham campos de pesquisa definidos.',

);?>
