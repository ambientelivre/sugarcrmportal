<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_ID'                                           => 'ID',
'LBL_MODULE_NAME'                                  => 'RSS',
'LBL_MODULE_ID'                                    => 'Feeds',
'LBL_MODULE_TITLE'                                 => 'RSS: Principal',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar RSS News Feed',
'LBL_LIST_FORM_TITLE'                              => 'Lista de RSS News Feed',
'LBL_MY_LIST_FORM_TITLE'                           => 'Meus RSS News Feeds',
'LBL_NEW_FORM_TITLE'                               => 'Novo RSS News Feed',
'NTC_DELETE_CONFIRMATION'                          => 'Tem certeza que deseja excluir este registro?',
'ERR_DELETE_RECORD'                                => 'Um número de registro deve ser especificado para excluir o contato.',
'LNK_NEW_FEED'                                     => 'Novo RSS News Feed',
'LNK_FEED_LIST'                                    => 'Todos RSS News Feeds',
'LNK_MY_FEED_LIST'                                 => 'Meus RSS News Feeds',
'LBL_TITLE'                                        => 'Título',
'LBL_RSS_URL'                                      => 'RSS URL',
'LBL_ONLY_MY'                                      => 'Somente meus favoritos',
'LBL_VISIT_WEBSITE'                                => 'visitar website',
'LBL_LAST_UPDATED'                                 => 'Última atualização',
'LBL_DELETE_FAVORITES'                             => 'Excluir dos Favoritos',
'LBL_DELETE_FAV_BUTTON_TITLE'                      => 'Excluir dos favoritos [Alt+D]',
'LBL_DELETE_FAV_BUTTON_KEY'                        => '[Alt+D]',
'LBL_DELETE_FAV_BUTTON_LABEL'                      => 'Excluir dos favoritos',
'LBL_ADD_FAV_BUTTON_TITLE'                         => 'Incluir nos favoritos [Alt+A]',
'LBL_ADD_FAV_BUTTON_KEY'                           => '[Alt+A]',
'LBL_ADD_FAV_BUTTON_LABEL'                         => 'Incluir nos favoritos',
'LBL_MOVE_UP'                                      => 'Mover para Cima',
'LBL_MOVE_DOWN'                                    => 'Mover para Baixo',
'LBL_FEED_NOT_AVAILABLE'                           => 'Feed não disponível',
'LBL_REFRESH_CACHE'                                => 'Clique aqui para atualizar o cache',
'LBL_TILE'                                         => 'Título',
'LBL_URL'                                          => 'URL',
'LBL_DESCRIPTION'                                  => 'Descrição',
'LBL_EMPLOYEE'                                     => 'Funcionários:',
'LBL_LOGIN'                                        => 'Login',
'LBL_RESET_PREFERENCES'                            => 'Restaurar Configurações Padrão',
'LBL_TIME_FORMAT'                                  => 'Formato da Hora:',
'LBL_DATE_FORMAT'                                  => 'Formato da Data:',
'LBL_TIMEZONE'                                     => 'Hora:',
'LBL_CURRENCY'                                     => 'Moeda:',
'LBL_LIST_NAME'                                    => 'Nome',
'LBL_LIST_LAST_NAME'                               => 'Último Nome',
'LBL_LIST_EMPLOYEE_NAME'                           => 'Nome do Funcionário',
'LBL_LIST_DEPARTMENT'                              => 'Departamento',
'LBL_LIST_REPORTS_TO_NAME'                         => 'Reporta-se a',
'LBL_LIST_EMAIL'                                   => 'Email',
'LBL_LIST_PRIMARY_PHONE'                           => 'Fone Primário',
'LBL_LIST_USER_NAME'                               => 'Nome de Usuário',
'LBL_LIST_ADMIN'                                   => 'Admin',
'LBL_NEW_EMPLOYEE_BUTTON_TITLE'                    => 'Novo Funcionário [Alt+N]',
'LBL_NEW_EMPLOYEE_BUTTON_LABEL'                    => 'Novo Funcionário',
'LBL_NEW_EMPLOYEE_BUTTON_KEY'                      => 'N',
'LBL_ERROR'                                        => 'Erro:',
'LBL_PASSWORD'                                     => 'Senha:',
'LBL_EMPLOYEE_NAME'                                => 'Nome do Funcionário:',
'LBL_USER_NAME'                                    => 'Nome do Usuário:',
'LBL_FIRST_NAME'                                   => 'Primeiro Nome:',
'LBL_LAST_NAME'                                    => 'Último Nome:',
'LBL_EMPLOYEE_SETTINGS'                            => 'Configuração do Funcionário',
'LBL_THEME'                                        => 'Tema:',
'LBL_LANGUAGE'                                     => 'Língua: ',
'LBL_ADMIN'                                        => 'Administrador:',
'LBL_EMPLOYEE_INFORMATION'                         => 'Informação do Funcionário',
'LBL_OFFICE_PHONE'                                 => 'Fone Comercial:',
'LBL_REPORTS_TO'                                   => 'Reporta-se a:',
'LBL_REPORTS_TO_NAME'                              => 'Reporta-se a',
'LBL_OTHER_PHONE'                                  => 'Outro Fone:',
'LBL_OTHER_EMAIL'                                  => 'Outro Email:',
'LBL_NOTES'                                        => 'Notas:',
'LBL_DEPARTMENT'                                   => 'Departamento:',
'LBL_ANY_ADDRESS'                                  => 'Qualquer Endereço:',
'LBL_ANY_PHONE'                                    => 'Qualquer Fone:',
'LBL_ANY_EMAIL'                                    => 'Qualquer Email:',
'LBL_ADDRESS'                                      => 'Endereço:',
'LBL_CITY'                                         => 'Cidade:',
'LBL_STATE'                                        => 'Estado:',
'LBL_POSTAL_CODE'                                  => 'CEP:',
'LBL_COUNTRY'                                      => 'País:',
'LBL_NAME'                                         => 'Nme:',
'LBL_MOBILE_PHONE'                                 => 'Celular:',
'LBL_OTHER'                                        => 'Outro:',
'LBL_FAX'                                          => 'Fax:',
'LBL_EMAIL'                                        => 'Email:',
'LBL_HOME_PHONE'                                   => 'Fone Residencial:',
'LBL_WORK_PHONE'                                   => 'Fone Comercial:',
'LBL_ADDRESS_INFORMATION'                          => 'Informação do Endereço',
'LBL_EMPLOYEE_STATUS'                              => 'Status:',
'LBL_PRIMARY_ADDRESS'                              => 'Endereço Primário:',
'LBL_SAVED_SEARCH'                                 => 'Opções Layout',
'LBL_CREATE_USER_BUTTON_TITLE'                     => 'Criar Usuário [Alt+N]',
'LBL_CREATE_USER_BUTTON_LABEL'                     => 'Criar Usuário',
'LBL_CREATE_USER_BUTTON_KEY'                     => 'N',
'LBL_FAVORITE_COLOR'                               => 'Cor Favorita:',
'LBL_MESSENGER_ID'                                 => 'Nome IM:',
'LBL_MESSENGER_TYPE'                               => 'Tipo IM:',
'ERR_EMPLOYEE_NAME_EXISTS_1'                       => 'Esse nome',
'ERR_EMPLOYEE_NAME_EXISTS_2'                       => 'já existe. Não é permitido duplicar nome dos funcionários. Troque o nome do funcionário para ser único.',
'ERR_LAST_ADMIN_1'                                 => 'O nome do funcionário',
'LNK_NEW_EMPLOYEE'                               => 'Criar Funcionário',
'LNK_EMPLOYEE_LIST'                                => 'Ver Funcionários',
'LBL_LIST_EMPLOYEE_STATUS'                         => 'Status Funcionário',
'LBL_SUGAR_LOGIN'                                  => 'É Usuário do Sugar',
'LBL_RECEIVE_NOTIFICATIONS'                        => 'Informe de Cessão',
'LBL_IS_ADMIN'                                     => 'É Administrador',
'LBL_GROUP'                                        => 'Grupo Usuário',
'LBL_PORTAL_ONLY'                                  => 'Apenas Usuário do Portal',
'LBL_PHOTO'                                        => 'Foto ',
'LBL_LIST_TYPE' 								   =>'Tipo:',
'LBL_LIST_EVAL'									   =>'Eval:',
'LBL_LIST_FIELD' 								   =>'Campos:',
'LBL_FIELD' 									   =>'campo:',
'LBL_TYPE' 										   =>'Tipo:',
'LBL_EVAL'										   =>'Avaliação:',
'LBL_SHOW_PAST'									   =>'Modificar Valor Antigo:',
'LNK_NEW_TRIGGER'								   =>'Criar Trigger',
'LNK_TRIGGER'									   =>'Fluxo de Trabalho Triggers',
'LBL_TIME_PAST' 								   =>'passado',
'LBL_TIME_FUTURE'								   =>'de agora em diante',
'LBL_ACTION_UPDATE'								   =>'Atualizar campos triggered',
'LBL_ACTION_UPDATE_REL'							   =>'Atualizar campos relacionados',
'LBL_ACTION_NEW'								   =>'Criar',
'LBL_RECORD'									   =>'Registro',
'LBL_NEXT_BUTTON'								   =>'Próximo',
'LBL_PREVIOUS_BUTTON'							   =>'Anterior',
'LBL_LIST_ACTION_DESCRIPTION'					   =>'Ações a serem realizadas:',
'LBL_PLEASE_SELECT'								   =>'Por Favor Selecione',
'LBL_TIME_INT'									   =>'ao menos',
'LBL_REL1'										   =>'Módulos Relacionados:',
'LBL_REL2'										   =>'Módulos Relacionados:',
'LBL_PLEASE_SEL_TARGET'							   =>'Pr favor selecione um módulo alvo',
'LBL_ASSOCIATED_WITH'							   =>'associado com um relacionado',

);?>
