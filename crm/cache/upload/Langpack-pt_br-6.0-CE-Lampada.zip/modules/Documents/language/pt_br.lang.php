<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Documentos',
'LBL_MODULE_TITLE'                                 => 'Documentos: Principal',
'LNK_NEW_DOCUMENT'                                 => 'Novo Documento',
'LNK_DOCUMENT_LIST'                                => 'Lista de Documentos',
'LBL_DOC_REV_HEADER'                               => 'Revisões do Documento',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar Documentos',
'LBL_DOCUMENT_ID'                                  => 'Id Documento',
'LBL_NAME'                                         => 'Nome do Documento',
'LBL_DESCRIPTION'                                  => 'Descrição',
'LBL_CATEGORY'                                     => 'Categoria',
'LBL_SUBCATEGORY'                                  => 'Sub Categoria',
'LBL_STATUS'                                       => 'Status',
'LBL_CREATED_BY'                                   => 'Criado por',
'LBL_DATE_ENTERED'                                 => 'Data Entrada',
'LBL_DATE_MODIFIED'                                => 'Data Alteração',
'LBL_DELETED'                                      => 'Excluído',
'LBL_MODIFIED'                                     => 'Alterado por',
'LBL_MODIFIED_USER'                                => 'Modificado por',
'LBL_CREATED'                                      => 'Criado por',
'LBL_REVISIONS'                                    => 'Revisões',
'LBL_RELATED_DOCUMENT_ID'                          => 'ID do Documento Relacionado',
'LBL_RELATED_DOCUMENT_REVISION_ID'                 => 'ID da Revisão do Documento Relacionado',
'LBL_IS_TEMPLATE'                                  => 'É um Template',
'LBL_TEMPLATE_TYPE'                                => 'Tipo de Documento',
'LBL_ASSIGNED_TO_NAME'                             => 'Atribuído a:',
'LBL_REVISION_NAME'                                => 'Número da Revisão',
'LBL_MIME'                                         => 'Tipo MIME',
'LBL_REVISION'                                     => 'Revisão',
'LBL_DOCUMENT'                                     => 'Documento Relacionado',
'LBL_LATEST_REVISION'                              => 'Última Revisão',
'LBL_CHANGE_LOG'                                   => 'Registro de Alterações:',
'LBL_ACTIVE_DATE'                                  => 'Data de Publicação',
'LBL_EXPIRATION_DATE'                              => 'Data de Expiração',
'LBL_FILE_EXTENSION'                               => 'Extensão do Arquivo',
'LBL_CAT_OR_SUBCAT_UNSPEC'                         => 'Não Especificado',
'LBL_NEW_FORM_TITLE'                               => 'Novo Documento',
'LBL_DOC_NAME'                                     => 'Nome Documento:',
'LBL_FILENAME'                                     => 'Nome Arquivo:',
'LBL_DOC_VERSION'                                  => 'Revisão:',
'LBL_CATEGORY_VALUE'                               => 'Categoria:',
'LBL_SUBCATEGORY_VALUE'                            => 'Sub Categoria:',
'LBL_DOC_STATUS'                                   => 'Status:',
'LBL_LAST_REV_CREATOR'                             => 'Revisão Criada por:',
'LBL_LAST_REV_DATE'                                => 'Data da Revisão:',
'LBL_DOWNNLOAD_FILE'                               => 'Transferir Arquivo:',
'LBL_DET_RELATED_DOCUMENT'                         => 'Documento Relacionado:',
'LBL_DET_RELATED_DOCUMENT_VERSION'                 => 'Revisão do Documento Relacionado:',
'LBL_DET_IS_TEMPLATE'                              => 'Template?:',
'LBL_DET_TEMPLATE_TYPE'                            => 'Tipo de Documento:',
'LBL_DOC_DESCRIPTION'                              => 'Descrição:',
'LBL_DOC_ACTIVE_DATE'                              => 'Data de Publicação:',
'LBL_DOC_EXP_DATE'                                 => 'Data de Expiração:',
'LBL_LIST_FORM_TITLE'                              => 'Lista de Documentos',
'LBL_LIST_DOCUMENT'                                => 'Documento',
'LBL_LIST_CATEGORY'                                => 'Categoria',
'LBL_LIST_SUBCATEGORY'                             => 'Sub Categoria',
'LBL_LIST_REVISION'                                => 'Revisão',
'LBL_LIST_LAST_REV_CREATOR'                        => 'Publicado por',
'LBL_LIST_LAST_REV_DATE'                           => 'Data Revisão',
'LBL_LIST_VIEW_DOCUMENT'                           => 'Visualizar',
'LBL_LIST_DOWNLOAD'                                => 'Download',
'LBL_LIST_ACTIVE_DATE'                             => 'Data Publicação',
'LBL_LIST_EXP_DATE'                                => 'Data Expiração',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_SF_DOCUMENT'                                  => 'Documento:',
'LBL_SF_CATEGORY'                                  => 'Categoria:',
'LBL_SF_SUBCATEGORY'                               => 'Sub Categoria:',
'LBL_SF_ACTIVE_DATE'                               => 'Data de Publicação:',
'LBL_SF_EXP_DATE'                                  => 'Data de Expiração:',
'DEF_CREATE_LOG'                                   => 'Documento Criado',
'ERR_DOC_NAME'                                     => 'Nome Documento',
'ERR_DOC_ACTIVE_DATE'                              => 'Data de Publicação',
'ERR_DOC_EXP_DATE'                                 => 'Data de Expiração',
'ERR_FILENAME'                                     => 'Nome do Arquivo',
'ERR_DOC_VERSION'                                  => 'Versão do Documento',
'ERR_DELETE_CONFIRM'                               => 'Tem certeza que deseja excluir essa revisão do documento?',
'ERR_DELETE_LATEST_VERSION'                        => 'Você não possui permissão para excluir a última revisão do documento.',
'LNK_NEW_MAIL_MERGE'                               => 'Mala Direta',
'LBL_MAIL_MERGE_DOCUMENT'                          => 'Modelo de Mala Direta:',
'LBL_TREE_TITLE'                                   => 'Documentos',
'LBL_LIST_DOCUMENT_NAME'                           => 'Nome do Documento',
'LBL_CONTRACT_NAME'                                => 'Nome do Contato',
'LBL_LIST_IS_TEMPLATE'                             => 'Template?',
'LBL_LIST_TEMPLATE_TYPE'                           => 'Tipo de Documento',
'LBL_LIST_SELECTED_REVISION'                       => 'Revisão Selecionada',
'LBL_LIST_LATEST_REVISION'                         => 'Última Revisão',
'LBL_CONTRACTS_SUBPANEL_TITLE'                     => 'Contratos Relacionados',
'LBL_LAST_REV_CREATE_DATE'                         => 'Criar Data da Última Revisão',
'LBL_CONTRACTS'                                    => 'Contratos',
'LBL_CREATED_USER'                                 => 'Criado por',
'LBL_THEREVISIONS_SUBPANEL_TITLE'                  => 'Reversões',
'LBL_LAST_REV_MIME_TYPE'                           => 'Última revisão tipo MIME',
'LBL_LASTEST_REVISION_NAME'                        => 'Última revisão nome:',
'LBL_SELECTED_REVISION_NAME'                       => 'Selecionado revisão nome:',
'LBL_CONTRACT_STATUS'                              => 'Status contrato:',
'LBL_LINKED_ID'                                    => 'Id vinculado',
'LBL_SELECTED_REVISION_ID'                         => 'Selecionado revisão Id',
'LBL_LATEST_REVISION_ID'                           => 'Última revisão Id',
'LBL_SELECTED_REVISION_FILENAME'                   => 'Selecionado revisão do nome do arquivo',
'LBL_FILE_URL'                                     => 'Arquivo URL',
'LBL_REVISIONS_PANEL'                              => 'Detalhes da Revisão',
'LBL_REVISIONS_SUBPANEL'                           => 'Revisões',
'LBL_DOCUMENT_INFORMATION'                         => 'Principal Documento ',

);?>
