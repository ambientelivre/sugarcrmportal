<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Portal',
'LBL_MODULE_ID'                                    => 'iFrames',
'LBL_MODULE_TITLE'                                 => 'Portal: Principal',
'LBL_LIST_STATUS'                                  => 'Visível',
'LBL_LIST_NAME'                                    => 'Nome',
'LBL_LIST_URL'                                     => 'Website',
'LBL_LIST_TYPE'                                    => 'Tipo',
'LBL_LIST_CREATED_BY'                              => 'Criado por',
'LBL_LIST_PLACEMENT'                               => 'Localização',
'LBL_LIST_FORM_TITLE'                              => 'Lista de Portais',
'LBL_ADD_SITE'                                     => 'Novo Site',
'LBL_LIST_SITES'                                   => 'Lista de Sites',
'LBL_ID'                                           => 'ID',
'LBL_CHECKED'                                      => 'marcado',
'DEFAULT_URL'                                      => 'http://www.sugarcrm.com',
'LBL_DASHLET_TITLE'                                => 'Meu Portal',
'LBL_DASHLET_OPT_TITLE'                            => 'Título',
'LBL_DASHLET_OPT_URL'                              => 'Localização do Website',
'LBL_DASHLET_OPT_HEIGHT'                           => 'Altura do Dashlet (em pixels)',
'LBL_DASHLET_SUGAR_NEWS'                           => 'Sugar News ',
'LBL_DASHLET_DISCOVER_SUGAR_PRO'                   => 'Descubra Sugar Professional',


'DROPDOWN_PLACEMENT' => array(
'all'                                              => 'Menu de Guias e Menu de Atalhos',
'tab'                                              => 'Menu de Guias',
'shortcut'                                         => 'Menu de Atalhos',
),


'DROPDOWN_TYPE' => array(
'personal'                                         => 'Pessoal',
'global'                                           => 'Global',
),
);?>
