<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_ADD_ANOTHER_FILE'                             => 'Adicionar Outro Arquivo',
'LBL_ADD_DOCUMENT'                                 => 'Adicionar um Documento Sugar',
'LBL_ADD_FILE'                                     => 'Adicionar Arquivo',
'LBL_ATTACHMENTS'                                  => 'Anexos',
'LBL_BODY'                                         => 'Corpo:',
'LBL_CLOSE'                                        => 'Concluir:',
'LBL_COLON'                                        => ':',
'LBL_CONTACT_AND_OTHERS'                           => 'Contato/Potencial/Possível Cliente',
'LBL_DESCRIPTION'                                  => 'Descrição:',
'LBL_EDIT_ALT_TEXT'                                => 'Editar Texto Alternativo',
'LBL_EMAIL_ATTACHMENT'                             => 'Anexo do E-mail',
'LBL_HTML_BODY'                                    => 'Corpo HTML',
'LBL_INSERT_VARIABLE'                              => 'Inserir Variável:',
'LBL_INSERT_URL_REF'                               => 'Inserir URL de Referência',
'LBL_INSERT_TRACKER_URL'                           => 'Inserir URL de Rastreador:',
'LBL_INSERT'                                       => 'Inserir',
'LBL_LIST_DATE_MODIFIED'                           => 'Última Alteração',
'LBL_LIST_DESCRIPTION'                             => 'Descrição',
'LBL_LIST_FORM_TITLE'                              => 'Lista de Modelos de Email',
'LBL_LIST_NAME'                                    => 'Nome',
'LBL_MODULE_NAME'                                  => 'Modelos de Email',
'LBL_MODULE_TITLE'                                 => 'Modelos de Email: Principal',
'LBL_NAME'                                         => 'Nome:',
'LBL_NEW_FORM_TITLE'                               => 'Novo Modelo de Email',
'LBL_PUBLISH'                                      => 'Publicar:',
'LBL_RELATED_TO'                                   => 'Relacionado a:',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar em Modelos de Email',
'LBL_SHOW_ALT_TEXT'                                => 'Exibir Texto Alternativo',
'LBL_SUBJECT'                                      => 'Assunto:',
'LBL_SUGAR_DOCUMENT'                               => 'Documento Sugar',
'LBL_TEAMS'                                        => 'Equipes:',
'LBL_TEAMS_LINK'                                   => 'Equipe',
'LBL_TEXT_BODY'                                    => 'Corpo de Texto',
'LBL_USERS'                                        => 'Usuários',
'LNK_ALL_EMAIL_LIST'                               => 'Todos Emails',
'LNK_ARCHIVED_EMAIL_LIST'                          => 'Emails Arquivados',
'LNK_CHECK_EMAIL'                                  => 'Verificar Email',
'LNK_DRAFTS_EMAIL_LIST'                            => 'Todos Rascunhos',
'LNK_EMAIL_TEMPLATE_LIST'                          => 'Modelos de Email',
'LNK_IMPORT_NOTES'                                 => 'Importar Anotações',
'LNK_NEW_ARCHIVE_EMAIL'                            => 'Novo Email Arquivado',
'LNK_NEW_EMAIL_TEMPLATE'                           => 'Novo Modelo de Email',
'LNK_NEW_EMAIL'                                    => 'Arquivar Email',
'LNK_NEW_SEND_EMAIL'                               => 'Compor Email',
'LNK_SENT_EMAIL_LIST'                              => 'Emails Enviados',
'LNK_VIEW_CALENDAR'                                => 'Hoje',
'LBL_NEW'                                          => 'Novo',
'LNK_CHECK_MY_INBOX'                               => 'Checar Meu E-mail',
'LNK_GROUP_INBOX'                                  => 'Caixa de Entrada do Grupo',
'LNK_MY_ARCHIVED_LIST'                             => 'Meus Arquivos',
'LNK_MY_DRAFTS'                                    => 'Meus Rascunhos',
'LNK_MY_INBOX'                                     => 'Minha Caixa de Entrada',
'LBL_LIST_BASE_MODULE'                             => 'Módulo Base:',
'LBL_TEXT_ONLY'                                    => 'Somente Texto',
'LBL_SEND_AS_TEXT'                                 => 'Enviar Somente Texto',
'LBL_ACCOUNT'                                      => 'Conta',
'LBL_BASE_MODULE'                                  => 'Módulo Base',
'LBL_FROM_NAME'                                    => 'Nome de',
'LBL_PLAIN_TEXT'                                   => 'Texto',
'LBL_CREATED_BY'                                   => 'Criado por',
'LBL_FROM_ADDRESS'                                 => 'Endereço de',
'LBL_PUBLISHED'                                    => 'Publicado',
'LBL_ACTIVITIES_REPORTS'                           => 'Relatório de Atividades',
'LNK_VIEW_MY_INBOX'                                => 'Ver Meu Email ',

);?>
