<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'ERR_DELETE_RECORD'                                => 'Um número de registro deve ser especificado para excluir a conta.',
'LBL_ACCOUNT_ID'                                   => 'ID da Conta:',
'LBL_CASE_ID'                                      => 'ID da Ocorrência:',
'LBL_CLOSE'                                        => 'Concluir:',
'LBL_COLON'                                        => ':',
'LBL_CONTACT_ID'                                   => 'ID do Contato:',
'LBL_CONTACT_NAME'                                 => 'Contato:',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Anotações',
'LBL_DESCRIPTION'                                  => 'Descrição',
'LBL_EMAIL_ADDRESS'                                => 'Email:',
'LBL_EMAIL_ATTACHMENT'                             => 'Anexo do E-mail',
'LBL_FILE_MIME_TYPE'                               => 'Tipo MIME',
'LBL_FILE_URL'                                     => 'URL do Arquivo',
'LBL_FILENAME'                                     => 'Anexo:',
'LBL_LEAD_ID'                                      => 'ID do Potencial:',
'LBL_LIST_CONTACT_NAME'                            => 'Contato',
'LBL_LIST_DATE_MODIFIED'                           => 'Última Modificação',
'LBL_LIST_FILENAME'                                => 'Anexo',
'LBL_LIST_FORM_TITLE'                              => 'Lista de Anotações',
'LBL_LIST_RELATED_TO'                              => 'Relacionada a',
'LBL_LIST_SUBJECT'                                 => 'Assunto',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_LIST_CONTACT'                                 => 'Contato',
'LBL_MODULE_NAME'                                  => 'Anotações',
'LBL_MODULE_TITLE'                                 => 'Anotações: Principal',
'LBL_NEW_FORM_TITLE'                               => 'Nova Anotação',
'LBL_NOTE_STATUS'                                  => 'Anotação',
'LBL_NOTE_SUBJECT'                                 => 'Assunto da Anotação:',
'LBL_NOTES_SUBPANEL_TITLE'                         => 'Anexos',
'LBL_NOTE'                                         => 'Anotação:',
'LBL_OPPORTUNITY_ID'                               => 'ID da Oportunidade:',
'LBL_PARENT_ID'                                    => 'ID de Referência:',
'LBL_PARENT_TYPE'                                  => 'Tipo de Referência',
'LBL_PHONE'                                        => 'Fone:',
'LBL_PORTAL_FLAG'                                  => 'Exibir no Portal?',
'LBL_EMBED_FLAG'                                   => 'Incluir no email?',
'LBL_PRODUCT_ID'                                   => 'ID do Produto:',
'LBL_QUOTE_ID'                                     => 'ID da Proposta:',
'LBL_RELATED_TO'                                   => 'Relacionada a:',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar Anotações',
'LBL_STATUS'                                       => 'Status',
'LBL_SUBJECT'                                      => 'Assunto:',
'LNK_CALL_LIST'                                    => 'Ligações',
'LNK_EMAIL_LIST'                                   => 'Emails',
'LNK_IMPORT_NOTES'                                 => 'Importar Anotações',
'LNK_MEETING_LIST'                                 => 'Reuniões',
'LNK_NEW_CALL'                                     => 'Nova Ligação',
'LNK_NEW_EMAIL'                                    => 'Novo Email',
'LNK_NEW_MEETING'                                  => 'Nova Reunião',
'LNK_NEW_NOTE'                                     => 'Nova Anotação',
'LNK_NEW_TASK'                                     => 'Nova Tarefa',
'LNK_NOTE_LIST'                                    => 'Anotações',
'LNK_TASK_LIST'                                    => 'Tarefas',
'LNK_VIEW_CALENDAR'                                => 'Hoje',
'LBL_MEMBER_OF'                                    => 'Membro de:',
'LBL_LIST_ASSIGNED_TO_NAME'                        => 'Usuário atribuído',
'LBL_REMOVING_ATTACHMENT'                          => 'Removendo anexo...',
'ERR_REMOVING_ATTACHMENT'                          => 'Falha ao remover anexo...',
'LBL_CREATED_BY'                                   => 'Criado por',
'LBL_MODIFIED_BY'                                  => 'Modificado Por',
'LBL_SEND_ANYWAYS'                                 => 'Este e-mail está sem assunto. Enviar / Salvar?',
'LBL_LIST_EDIT_BUTTON'                             => 'Editar',
'LBL_ACTIVITIES_REPORTS'                           => 'Relatório de Atividades',
'LBL_PANEL_DETAILS'                                => 'Detalhes',
'LBL_NOTE_INFORMATION'                             => 'Principal Nota ',

);?>
