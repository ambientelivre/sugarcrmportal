<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Projeto',
'LBL_MODULE_TITLE'                                 => 'Projetos: Principal',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar Projetos',
'LBL_LIST_FORM_TITLE'                              => 'Lista de Projetos',
'LBL_HISTORY_TITLE'                                => 'Histórico',
'LBL_ID'                                           => 'Id:',
'LBL_DATE_ENTERED'                                 => 'Data Entrada:',
'LBL_DATE_MODIFIED'                                => 'Data de Modificação:',
'LBL_ASSIGNED_USER_ID'                             => 'Atribuído a:',
'LBL_ASSIGNED_USER_NAME'                           => 'Atribuído a:',
'LBL_MODIFIED_USER_ID'                             => 'Modificado por (Id do Usuário):',
'LBL_CREATED_BY'                                   => 'Criado por:',
'LBL_TEAM_ID'                                      => 'Equipe:',
'LBL_NAME'                                         => 'Nome:',
'LBL_PDF_PROJECT_NAME'                             => 'Nome do Projeto:',
'LBL_DESCRIPTION'                                  => 'Descrição:',
'LBL_DELETED'                                      => 'Excluído:',
'LBL_DATE'                                         => 'Data:',
'LBL_DATE_START'                                   => 'Data de Início',
'LBL_DATE_END'                                     => 'Data de Término',
'LBL_PRIORITY'                                     => 'Prioridade:',
'LBL_STATUS'                                       => 'Status:',
'LBL_MY_PROJECTS'                                  => 'Meus Projetos',
'LBL_MY_PROJECT_TASKS'                             => 'Minhas Tarefas do Projeto',
'LBL_TOTAL_ESTIMATED_EFFORT'                       => 'Estimativa de Esforço Total (hrs):',
'LBL_TOTAL_ACTUAL_EFFORT'                          => 'Esforço Real Total (hrs):',
'LBL_LIST_NAME'                                    => 'Nome',
'LBL_LIST_DAYS'                                    => 'dias',
'LBL_LIST_ASSIGNED_USER_ID'                        => 'Atribuído a',
'LBL_LIST_TOTAL_ESTIMATED_EFFORT'                  => 'Estimativa de Esforço Total (hrs)',
'LBL_LIST_TOTAL_ACTUAL_EFFORT'                     => 'Esforço Real Total (hrs)',
'LBL_LIST_UPCOMING_TASKS'                          => 'Próximas Tarefas (1 Semana)',
'LBL_LIST_OVERDUE_TASKS'                           => 'Tarefas Atrasadas',
'LBL_LIST_OPEN_CASES'                              => 'Ocorrências em Aberto',
'LBL_LIST_END_DATE'                                => 'Data Final',
'LBL_LIST_TEAM_ID'                                 => 'Equipe',
'LBL_PROJECT_SUBPANEL_TITLE'                       => 'Projetos',
'LBL_PROJECT_TASK_SUBPANEL_TITLE'                  => 'Tarefas de Projeto',
'LBL_CONTACT_SUBPANEL_TITLE'                       => 'Contatos',
'LBL_ACCOUNT_SUBPANEL_TITLE'                       => 'Contas',
'LBL_OPPORTUNITY_SUBPANEL_TITLE'                   => 'Oportunidades',
'LBL_QUOTE_SUBPANEL_TITLE'                         => 'Cotações',
'LBL_NEW_FORM_TITLE'                               => 'Novo Projeto',
'CONTACT_REMOVE_PROJECT_CONFIRM'                   => 'Tem certeza que quer excluir este contato do projeto?',
'LNK_NEW_PROJECT'                                  => 'Novo Projeto',
'LNK_PROJECT_LIST'                                 => 'Lista de Projetos',
'LNK_NEW_PROJECT_TASK'                             => 'Nova Tarefa de Projeto',
'LNK_PROJECT_TASK_LIST'                            => 'Tarefas de Projeto',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Projetos',
'LBL_ACTIVITIES_TITLE'                             => 'Atividades',
'LBL_ACTIVITIES_SUBPANEL_TITLE'                    => 'Atividades',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Histórico',
'LBL_QUICK_NEW_PROJECT'                            => 'Novo Projeto',
'LBL_PROJECT_TASKS_SUBPANEL_TITLE'                 => 'Tarefas do Projeto',
'LBL_CONTACTS_SUBPANEL_TITLE'                      => 'Contatos',
'LBL_ACCOUNTS_SUBPANEL_TITLE'                      => 'Contas',
'LBL_OPPORTUNITIES_SUBPANEL_TITLE'                 => 'Oportunidades',
'LBL_CASES_SUBPANEL_TITLE'                         => 'Ocorrências',
'LBL_BUGS_SUBPANEL_TITLE'                          => 'Bugs',
'LBL_PRODUCTS_SUBPANEL_TITLE'                      => 'Produtos',
'LBL_TASK_ID'                                      => 'ID',
'LBL_TASK_NAME'                                    => 'Nome da Tarefa',
'LBL_DURATION'                                     => 'Duração',
'LBL_ACTUAL_DURATION'                              => 'Duração Real',
'LBL_START'                                        => 'Iniciar',
'LBL_FINISH'                                       => 'Terminar',
'LBL_PREDECESSORS'                                 => 'Antecessores',
'LBL_PERCENT_COMPLETE'                             => '% Completo',
'LBL_MORE'                                         => 'Mais...',
'LBL_PERCENT_BUSY'                                 => '% Ocupado',
'LBL_TASK_ID_WIDGET'                               => 'id',
'LBL_TASK_NAME_WIDGET'                             => 'descrição',
'LBL_DURATION_WIDGET'                              => 'duração',
'LBL_START_WIDGET'                                 => 'data inicio',
'LBL_FINISH_WIDGET'                                => 'data termino',
'LBL_PREDECESSORS_WIDGET'                          => 'antecessores_',
'LBL_PERCENT_COMPLETE_WIDGET'                      => 'percentual completo',
'LBL_EDIT_PROJECT_TASKS_TITLE'                     => 'Editar Tarefas do Projeto',
'LBL_OPPORTUNITIES'                                => 'Oportunidades',
'LBL_LAST_WEEK'                                    => 'Anterior',
'LBL_NEXT_WEEK'                                    => 'Próximo',
'LBL_PROJECTRESOURCES_SUBPANEL_TITLE'              => 'Recursos do Projeto',
'LBL_PROJECTTASK_SUBPANEL_TITLE'                   => 'Tarefas do Projeto',
'LBL_HOLIDAYS_SUBPANEL_TITLE'                      => 'Feriados',
'LBL_PROJECT_INFORMATION'                          => 'Principal Projetos',

);?>
