<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Oportunidades',
'LBL_MODULE_TITLE'                                 => 'Oportunidades: Principal',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar Oportunidades',
'LBL_VIEW_FORM_TITLE'                              => 'Visualização da Oportunidade',
'LBL_LIST_FORM_TITLE'                              => 'Lista de Oportunidades',
'LBL_OPPORTUNITY_NAME'                             => 'Nome da Oportunidade:',
'LBL_OPPORTUNITY'                                  => 'Oportunidade:',
'LBL_NAME'                                         => 'Nome da Oportunidade',
'LBL_INVITEE'                                      => 'Contatos',
'LBL_CURRENCIES'                                   => 'Moedas',
'LBL_LIST_OPPORTUNITY_NAME'                        => 'Oportunidade',
'LBL_LIST_ACCOUNT_NAME'                            => 'Nome da Conta',
'LBL_LIST_AMOUNT'                                  => 'Valor',
'LBL_LIST_DATE_CLOSED'                             => 'Data Prevista',
'LBL_LIST_SALES_STAGE'                             => 'Estágio Vendas',
'LBL_ACCOUNT_ID'                                   => 'ID da Conta',
'LBL_CURRENCY_ID'                                  => 'ID da Moeda',
'LBL_CURRENCY_NAME'                                => 'Nome da Moeda',
'LBL_CURRENCY_SYMBOL'                              => 'Símbolo da Moeda',
'db_sales_stage'                                   => 'Estágio de Vendas',
'db_name'                                          => 'Nome',
'db_amount'                                        => 'Valor',
'db_date_closed'                                   => 'Data Fechamento',
'UPDATE'                                           => 'Oportunidade - Atualizar Moeda',
'UPDATE_DOLLARAMOUNTS'                             => 'Atualizar Valores em U.S. Dollar',
'UPDATE_VERIFY'                                    => 'Verificar Valores',
'UPDATE_VERIFY_TXT'                                => 'Verifica se os valores nas oportunidades são válidos com somente dados numéricos (0-9) e ponto decimal (.)',
'UPDATE_FIX'                                       => 'Corrigir Valores',
'UPDATE_FIX_TXT'                                   => 'Tenta corrigir qualquer valor inválido criando um valor com casas decimais a partir do valor atual. Será feito o backup de qualquer valor alterado no banco de dados. Caso você execute este procedimento e receba uma mensagem de problemas, não execute novamente antes de restaurar o backup, pois de outra forma o backup pode ser sobrescrito com dados inválidos.',
'UPDATE_DOLLARAMOUNTS_TXT'                         => 'Atualiza os valores em U.S. Dollar nas oportunidades baseado na taxa da moeda atual. Este valor será utilizado para calcular os Gráficos e List View dos Valores das Moedas.',
'UPDATE_CREATE_CURRENCY'                           => 'Criando Nova Moeda:',
'UPDATE_VERIFY_FAIL'                               => 'Verificação de Registros Falhou:',
'UPDATE_VERIFY_CURAMOUNT'                          => 'Valor da Moeda:',
'UPDATE_VERIFY_FIX'                                => 'Executando Correções pode trazer',
'UPDATE_INCLUDE_CLOSE'                             => 'Incluir Registros Fechados',
'UPDATE_VERIFY_NEWAMOUNT'                          => 'Novo Valor:',
'UPDATE_VERIFY_NEWCURRENCY'                        => 'Nova Moeda:',
'UPDATE_DONE'                                      => 'Completo',
'UPDATE_BUG_COUNT'                                 => 'Bugs Encontrados e Tentativas de Resolver:',
'UPDATE_BUGFOUND_COUNT'                            => 'Bugs Encontrados:',
'UPDATE_COUNT'                                     => 'Registros Atualizados:',
'UPDATE_RESTORE_COUNT'                             => 'Valores de Registros Restaurados:',
'UPDATE_RESTORE'                                   => 'Restaurar Valores',
'UPDATE_RESTORE_TXT'                               => 'Restaurar valores a partir do backup criado durante a correção.',
'UPDATE_FAIL'                                      => 'Impossível atualizar - ',
'UPDATE_NULL_VALUE'                                => 'Valor é NULO definindo como 0 -',
'UPDATE_MERGE'                                     => 'Mesclar Moedas',
'UPDATE_MERGE_TXT'                                 => 'Mescla múltiplas moedas em uma moeda única. Caso você seja informado que existem múltiplos registros de moedas para a mesma moeda, você pode optar por mesclá-ros. Isto também ira mesclar moedas para todos os demais módulos.',
'LBL_ACCOUNT_NAME'                                 => 'Nome da Conta:',
'LBL_AMOUNT'                                       => 'Valor:',
'LBL_AMOUNT_USDOLLAR'                              => 'Valor USD:',
'LBL_CURRENCY'                                     => 'Moeda:',
'LBL_DATE_CLOSED'                                  => 'Data Prevista:',
'LBL_TYPE'                                         => 'Tipo:',
'LBL_CAMPAIGN'                                     => 'Campanha:',
'LBL_NEXT_STEP'                                    => 'Próximo Passo:',
'LBL_LEAD_SOURCE'                                  => 'Fonte de Potencial:',
'LBL_SALES_STAGE'                                  => 'Estágio de Venda:',
'LBL_PROBABILITY'                                  => 'Probabilidade (%):',
'LBL_DESCRIPTION'                                  => 'Descrição:',
'LBL_DUPLICATE'                                    => 'Possivel Oportunidade Duplicada',
'MSG_DUPLICATE'                                    => 'O registro da oportunidade que voce está criando pode ser um registro de uma oportunidade que já existe. Os registros das oportunidades contem os nomes similares encontrados abaixo.<br> Clique Salvar para continuar criando esta nova oportunidade, ou clique Cancelar para retornar ao modulo sem gravar este registro.',
'LBL_NEW_FORM_TITLE'                               => 'Criar Oportunidade',
'LNK_NEW_OPPORTUNITY'                              => 'Criar Oportunidade',
'LNK_OPPORTUNITY_LIST'                             => 'Oportunidades',
'ERR_DELETE_RECORD'                                => 'Um número de registro deve ser especificado para excluir a oportunidade.',
'LBL_TOP_OPPORTUNITIES'                            => 'Minhas Melhores Oportunidades Abertas.',
'NTC_REMOVE_OPP_CONFIRMATION'                      => 'Tem certeza que quer remover este contato desta oportunidade?',
'OPPORTUNITY_REMOVE_PROJECT_CONFIRM'               => 'Tem certeza que deseja remover essa oportunidade deste projeto?',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Oportunidades',
'LBL_ACTIVITIES_SUBPANEL_TITLE'                    => 'Atividades',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Histórico',
'LBL_RAW_AMOUNT'                                   => 'Valor Bruto',
'LBL_LEADS_SUBPANEL_TITLE'                         => 'Potenciais',
'LBL_CONTACTS_SUBPANEL_TITLE'                      => 'Contatos',
'LBL_PROJECTS_SUBPANEL_TITLE'                      => 'Projetos',
'LBL_ASSIGNED_TO_NAME'                             => 'Atribuído a:',
'LBL_LIST_ASSIGNED_TO_NAME'                        => 'Usuário Atribuído:',
'LBL_MY_CLOSED_OPPORTUNITIES'                      => 'Oportunidades Fechadas',
'LBL_TOTAL_OPPORTUNITIES'                          => 'Total de Oportunidades',
'LBL_CLOSED_WON_OPPORTUNITIES'                     => 'Oportunidades Ganhas',
'LBL_ASSIGNED_TO_ID'                               => 'Atribuído ao ID:',
'LBL_CREATED_ID'                                   => 'Criado pelo ID:',
'LBL_MODIFIED_ID'                                  => 'Modificado pelo ID:',
'LBL_MODIFIED_NAME'                                => 'Modificado pelo usuário',
'LBL_CREATED_USER'                                 => 'Criado por:',
'LBL_MODIFIED_USER'                                => 'Modificado por',
'LBL_CAMPAIGN_OPPORTUNITY'                         => 'Campanha',
'LBL_PROJECT_SUBPANEL_TITLE'                       => 'Projetos',
'LBL_LIST_AMOUNT_USDOLLAR'                         => 'Quantidade',
'LABEL_PANEL_ASSIGNMENT'                           => 'Atribuição',
'LNK_IMPORT_OPPORTUNITIES'                         => 'Importar Oportunidades ',

);?>
