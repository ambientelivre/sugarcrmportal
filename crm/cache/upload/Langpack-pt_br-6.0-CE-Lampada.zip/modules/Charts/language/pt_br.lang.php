<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'ERR_NO_OPPS'                                      => 'Por favor crie algumas oportunidades para ver Gráficos de Oportunidade.',
'LBL_ALL_OPPORTUNITIES'                            => 'Quantia total de todas oportunidades é ',
'LBL_CHART_TYPE'                                   => 'Tipo de Gráfico',
'LBL_CREATED_ON'                                   => 'Última execução em ',
'LBL_DATE_END'                                     => 'Data Final:',
'LBL_DATE_RANGE_TO'                                => 'até',
'LBL_DATE_RANGE'                                   => 'Intervalo de datas é',
'LBL_DATE_START'                                   => 'Data Inicial:',
'LBL_EDIT'                                         => 'Editar',
'LBL_LEAD_SOURCE_BY_OUTCOME_DESC'                  => 'Mostra oportunidades acumuladas por fonte de potencial selecionada por resultado de usuários selecionados. Resultado é baseado em se estágio de vendas é Fechamento Ganho, Fechamento Perdido ou qualquer outro valor.',
'LBL_LEAD_SOURCE_BY_OUTCOME'                       => 'Todas Oportunidades Por Fonte de Potencial Por Resultado',
'LBL_LEAD_SOURCE_FORM_DESC'                        => 'Mostra oportunidades acumuladas por fonte de potencial selecionada por usuários selecionados.',
'LBL_LEAD_SOURCE_FORM_TITLE'                       => 'Todas Oportunidades Por Fonte de Potencial',
'LBL_LEAD_SOURCE_OTHER'                            => 'Outros',
'LBL_LEAD_SOURCES'                                 => 'Fontes de Potenciais:',
'LBL_MODULE_NAME'                                  => 'Painel',
'LBL_MODULE_TITLE'                                 => 'Painel: Principal',
'LBL_MONTH_BY_OUTCOME_DESC'                        => 'Mostra oportunidades acumuladas por mês por resultado para usuários selecionados quando a data de fechamento esperada está dentro do intervalo de datas. Resultado é baseado em se estágio de vendas é Fechamento Ganho, Fechamento Perdido ou qualquer outro valor.',
'LBL_NUMBER_OF_OPPS'                               => 'Número de Oportunidades',
'LBL_OPP_SIZE'                                     => 'Tamanho da oportunidade',
'LBL_OPP_THOUSANDS'                                => 'K',
'LBL_OPPS_IN_LEAD_SOURCE'                          => 'oportunidades onde a fonte de potencial está',
'LBL_OPPS_IN_STAGE'                                => 'onde o estágio de vendas está',
'LBL_OPPS_OUTCOME'                                 => 'onde o resultado está',
'LBL_OPPS_WORTH'                                   => 'valor das oportunidades',
'LBL_PIPELINE_FORM_TITLE_DESC'                     => 'Mostra o valor acumulado por estágios de venda selecionados para suas oportunidades quando a data de fechamento esperada está dentro do intervalo de datas.',
'LBL_CAMPAIGN_ROI_TITLE_DESC'                      => 'Mostrar resposta da campanha por retorno de investimento.',
'LBL_REFRESH'                                      => 'Atualizar',
'LBL_ROLLOVER_DETAILS'                             => 'Role a barra para detalhes.',
'LBL_ROLLOVER_WEDGE_DETAILS'                       => 'Role a guia para detalhes.',
'LBL_SALES_STAGE_FORM_DESC'                        => 'Mostra oportunidades acumuladas por estágios de venda selecionados para usuários  selecionados quando a data de fechamento esperada está dentro do intervalo de datas.',
'LBL_SALES_STAGE_FORM_TITLE'                       => 'Funil por Estágio de Vendas',
'LBL_SALES_STAGES'                                 => 'Estágios de Vendas:',
'LBL_TOTAL_PIPELINE'                               => 'Total do Funil é ',
'LBL_USERS'                                        => 'Usuários:',
'LBL_YEAR_BY_OUTCOME'                              => 'Funil por Mês por Resultado',
'LBL_YEAR'                                         => 'Ano:',
'LNK_NEW_ACCOUNT'                                  => 'Nova Conta',
'LNK_NEW_CALL'                                     => 'Agendar Ligação',
'LNK_NEW_CASE'                                     => 'Nova Ocorrência',
'LNK_NEW_CONTACT'                                  => 'Novo Contato',
'LNK_NEW_ISSUE'                                    => 'Novo Bug',
'LNK_NEW_LEAD'                                     => 'Novo Potencial',
'LNK_NEW_MEETING'                                  => 'Agendar Reunião',
'LNK_NEW_NOTE'                                     => 'Nova Anotação',
'LNK_NEW_OPPORTUNITY'                              => 'Nova Oportunidade',
'LNK_NEW_QUOTE'                                    => 'Nova Cotação',
'LNK_NEW_TASK'                                     => 'Nova Tarefa',
'NTC_NO_LEGENDS'                                   => 'Nada',
'LBL_TITLE'                                        => 'Título:',
'LBL_MY_MODULES_USED_SIZE'                         => 'Contador de Acessos',
);?>
