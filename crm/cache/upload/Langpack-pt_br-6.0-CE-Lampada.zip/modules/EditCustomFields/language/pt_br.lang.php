<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Editar Campo Personalizado',
'LBL_ADD_FIELD'                                    => 'Incluir Campo:',
'LBL_MODULE_TITLE'                                 => 'Editar Campo Personalizado',
'LBL_MODULE_SELECT'                                => 'Módulo para Editar',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar Módulo',
'COLUMN_TITLE_NAME'                                => 'Nome do Campo',
'COLUMN_TITLE_DISPLAY_LABEL'                       => 'Rótulo',
'COLUMN_TITLE_LABEL_VALUE'                         => 'Valor Label',
'COLUMN_TITLE_LABEL'                               => 'Rótulo do Campo',
'COLUMN_TITLE_DATA_TYPE'                           => 'Tipo de Dado',
'COLUMN_TITLE_MAX_SIZE'                            => 'Tamanho Máximo',
'COLUMN_TITLE_HELP_TEXT'                           => 'Texto de Ajuda',
'COLUMN_TITLE_COMMENT_TEXT'                        => 'Comentário',
'COLUMN_TITLE_REQUIRED_OPTION'                     => 'Campo Obrigatório',
'COLUMN_TITLE_DEFAULT_VALUE'                       => 'Valor Padrão',
'COLUMN_TITLE_DEFAULT_EMAIL'                       => 'Valor Padrão',
'COLUMN_TITLE_EXT1'                                => 'Meta Campo Extra 1',
'COLUMN_TITLE_EXT2'                                => 'Meta Campo Extra 2',
'COLUMN_TITLE_EXT3'                                => 'Meta Campo Extra 3',
'COLUMN_TITLE_FRAME_HEIGHT'                        => 'Altura do iFrame',
'COLUMN_TITLE_HTML_CONTENT'                        => 'HTML',
'COLUMN_TITLE_URL'                                 => 'URL Padrão',
'COLUMN_TITLE_AUDIT'                               => 'Auditar',
'COLUMN_TITLE_REPORTABLE'                          => 'Reportavél',
'COLUMN_TITLE_MIN_VALUE'                           => 'Valor Mínimo',
'COLUMN_TITLE_MAX_VALUE'                           => 'Valor Máximo',
'COLUMN_TITLE_DISPLAYED_ITEM_COUNT'                => '# Itens mostrados',
'COLUMN_DISABLE_NUMBER_FORMAT'                     => 'Desabilitar Formato',
'LBL_DROP_DOWN_LIST'                               => 'Lista Drop Down',
'LBL_RADIO_FIELDS'                                 => 'Campos Radio',
'LBL_MULTI_SELECT_LIST'                            => 'Lista Multi Select',
'COLUMN_TITLE_PRECISION'                           => 'Precisão',
'MSG_DELETE_CONFIRM'                               => 'Tem certeza que deseja excluir esse item?',
'POPUP_INSERT_HEADER_TITLE'                        => 'Incluir Campo Personalizado',
'POPUP_EDIT_HEADER_TITLE'                          => 'Editar Campo Personalizado',
'LNK_SELECT_CUSTOM_FIELD'                          => 'Selecionar Campo Personalizado',
'LNK_REPAIR_CUSTOM_FIELD'                          => 'Reparar Campos Personalizados',
'LBL_MODULE'                                       => 'Módulo',
'COLUMN_TITLE_MASS_UPDATE'                         => 'Atualização em massa',
'COLUMN_TITLE_IMPORTABLE'                          => 'Importável',
'COLUMN_TITLE_DUPLICATE_MERGE'                     => 'Fusão duplicada',
'LBL_LABEL'                                        => 'Etiqueta',
'LBL_DATA_TYPE'                                    => 'Tipo de data',
'LBL_DEFAULT_VALUE'                                => 'Valor Padrão',
'LBL_AUDITED'                                      => 'Auditado',
'LBL_REPORTABLE'                                   => 'Reportável',
'ERR_RESERVED_FIELD_NAME'                          => 'Senha Reservada',
'ERR_SELECT_FIELD_TYPE'                            => 'Selecione um Tipo de Campo',
'LBL_BTN_ADD'                                      => 'Adicionar',
'LBL_BTN_EDIT'                                     => 'Editar',
'LBL_GENERATE_URL'                                 => 'Generate URL',
'LBL_DEPENDENT_CHECKBOX'                           => 'Dependente',
'LBL_DEPENDENT_TRIGGER'                            => 'Trigger ',
'LBL_BTN_EDIT_VISIBILITY'                          => 'Edição visível',
'COLUMN_TITLE_LABEL_ROWS'                          => 'Linhas',
'COLUMN_TITLE_LABEL_COLS'                          => 'Colunas',
'COLUMN_TITLE_AUTOINC_NEXT'                        => 'Próximo Valor Auto Incremento',
'LBL_LINK_TARGET'                                  => 'Abrir Link',
'LBL_IMAGE_WIDTH'                                  => 'Largura',
'LBL_IMAGE_HEIGHT'                                 => 'Altura',
'LBL_IMAGE_BORDER'                                 => 'Limite ',

);?>
