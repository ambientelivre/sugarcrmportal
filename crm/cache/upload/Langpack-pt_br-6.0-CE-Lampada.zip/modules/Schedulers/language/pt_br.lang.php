<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_OOTB_WORKFLOW'                                => 'Tarefas de Processo de Fluxo de Trabalho',
'LBL_OOTB_REPORTS'                                 => 'Executar tarefas agendadas de geração de relatório ',
'LBL_OOTB_IE'                                      => 'Verificar Caixa de Entrada de E-mails',
'LBL_OOTB_BOUNCE'                                  => 'Executar toda noite Process Bounced Campaign Emails',
'LBL_OOTB_CAMPAIGN'                                => 'Executar toda noite Mass Email Campaigns',
'LBL_OOTB_PRUNE'                                   => 'Prune (Podar) o Banco de Dados no primeiro dia do Mês',
'LBL_OOTB_TRACKER'                                 => 'Prune (Podar) a Tabela de Histórico do Usuário na primeira semana do Mês',
'LBL_UPDATE_TRACKER_SESSIONS'                      => 'Atualizar tabela tracker_sessions',
'LBL_LIST_JOB_INTERVAL'                            => 'Intervalo:',
'LBL_LIST_LIST_ORDER'                              => 'Agendadores:',
'LBL_LIST_NAME'                                    => 'Agendador:',
'LBL_LIST_RANGE'                                   => 'Faixa:',
'LBL_LIST_REMOVE'                                  => 'Remover:',
'LBL_LIST_STATUS'                                  => 'Status:',
'LBL_LIST_TITLE'                                   => 'Lista de Tarefas Agendadas:',
'LBL_LIST_EXECUTE_TIME'                            => 'Horário de Execução:',
'LBL_SUN'                                          => 'Domingo',
'LBL_MON'                                          => 'Segunda',
'LBL_TUE'                                          => 'Terça',
'LBL_WED'                                          => 'Quarta',
'LBL_THU'                                          => 'Quinta',
'LBL_FRI'                                          => 'Sexta',
'LBL_SAT'                                          => 'Sábado',
'LBL_ALL'                                          => 'Todos Dias',
'LBL_EVERY_DAY'                                    => 'Todos dias ',
'LBL_AT_THE'                                       => 'às ',
'LBL_EVERY'                                        => 'Todo(a) ',
'LBL_FROM'                                         => 'De ',
'LBL_ON_THE'                                       => 'No(a) ',
'LBL_RANGE'                                        => ' a ',
'LBL_AT'                                           => 'às ',
'LBL_IN'                                           => ' em ',
'LBL_AND'                                          => ' e ',
'LBL_MINUTES'                                      => 'minutos ',
'LBL_HOUR'                                         => 'horas',
'LBL_HOUR_SING'                                    => 'hora',
'LBL_MONTH'                                        => 'mês',
'LBL_OFTEN'                                        => 'Tão freqüente quanto possível.',
'LBL_MIN_MARK'                                     => 'marca de minuto',
'LBL_MINS'                                         => 'min',
'LBL_HOURS'                                        => 'hrs',
'LBL_DAY_OF_MONTH'                                 => 'data',
'LBL_MONTHS'                                       => 'meses',
'LBL_DAY_OF_WEEK'                                  => 'dia',
'LBL_CRONTAB_EXAMPLES'                             => 'A lista acima usa notação crontab padrão.',
'LBL_ALWAYS'                                       => 'Sempre',
'LBL_CATCH_UP'                                     => 'Executar Se Ultrapassado',
'LBL_CATCH_UP_WARNING'                             => 'Desmarque se esta Tarefa levar mais que um momento para executar.',
'LBL_DATE_TIME_END'                                => 'Data & Hora Final',
'LBL_DATE_TIME_START'                              => 'Data & Hora Inicial',
'LBL_INTERVAL'                                     => 'Intervalo',
'LBL_JOB'                                          => 'Tarefa',
'LBL_LAST_RUN'                                     => 'Última Execução',
'LBL_MODULE_NAME'                                  => 'Agendador Sugar',
'LBL_MODULE_TITLE'                                 => 'Agendador',
'LBL_NAME'                                         => 'Nome da Tarefa',
'LBL_NEVER'                                        => 'Nunca',
'LBL_NEW_FORM_TITLE'                               => 'Nova Tarefa Agendada',
'LBL_PERENNIAL'                                    => 'perpétua',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar Agendador',
'LBL_SCHEDULER'                                    => 'Agendador:',
'LBL_STATUS'                                       => 'Status',
'LBL_TIME_FROM'                                    => 'Ativo Desde',
'LBL_TIME_TO'                                      => 'Ativo Até',
'LBL_WARN_CURL_TITLE'                              => 'Aviso cURL:',
'LBL_WARN_CURL'                                    => 'Aviso:',
'LBL_WARN_NO_CURL'                                 => 'Este sistema não possui as bibliotecas cURL habilitadas/compiladas no módulo PHP (--with-curl=/path/to/curl_library).  Por favor contate seu administrador para resolver esta pendência.  Sem a funcionalidade cURL, o Agendador não pode executar suas tarefas.',
'LBL_BASIC_OPTIONS'                                => 'Configuração Básica',
'LBL_ADV_OPTIONS'                                  => 'Opções Avançadas',
'LBL_TOGGLE_ADV'                                   => 'Opções Avançadas',
'LBL_TOGGLE_BASIC'                                 => 'Opções Básicas',
'LNK_LIST_SCHEDULER'                               => 'Agendador',
'LNK_NEW_SCHEDULER'                                => 'Nova Tarefa Agendada',
'LNK_LIST_SCHEDULED'                               => 'Tarefas Agendadas',
'SOCK_GREETING'                                    => 'Esta é a interface para o Serviço de Agendamento SugarCRM. [ Comandos disponíveis para o daemon: start|restart|shutdown|status ]Para desistir, digite \'quit\'.  Para parar o serviço \'shutdown\'.',
'ERR_DELETE_RECORD'                                => 'Um número de registro deve ser especificado para excluir o agendamento.',
'ERR_CRON_SYNTAX'                                  => 'Sintaxe do cron inválida',
'NTC_DELETE_CONFIRMATION'                          => 'Tem certeza que quer excluir este registro?',
'NTC_STATUS'                                       => 'Configure o status como Inativo para excluir este Agendamento das listas suspensas do Agendador',
'NTC_LIST_ORDER'                                   => 'Configure a ordem que este Agendamento aparecerá nas listas suspensas do Agendador',
'LBL_CRON_INSTRUCTIONS_WINDOWS'                    => 'Para configurar o Agendador do Windows',
'LBL_CRON_INSTRUCTIONS_LINUX'                      => 'Para configurar o Crontab',
'LBL_CRON_LINUX_DESC'                              => 'Adicione esta linha ao crontab: ',
'LBL_CRON_WINDOWS_DESC'                            => 'Crie o arquivo em lote com os seguintes comandos: ',
'LBL_NO_PHP_CLI'                                   => 'Se seu host não tiver o binário PHP disponível, você poderá uar wget ou curl para lançar suas Tarefas.<br>for wget: <b>*    *    *    *    *    wget --quiet --non-verbose /cron.php > /dev/null 2>&1</b><br>for curl: <b>*    *    *    *    *    curl --silent /cron.php > /dev/null 2>&1',
'LBL_JOBS_SUBPANEL_TITLE'                          => 'Tarefas Ativas',
'LBL_EXECUTE_TIME'                                 => 'Tempo de Execução',
'LBL_REFRESHJOBS'                                  => 'Atualizar Tarefas',
'LBL_POLLMONITOREDINBOXES'                         => 'Checar Caixa de Entrada',
'LBL_RUNMASSEMAILCAMPAIGN'                         => 'Enviar Email Campanha Noturno',
'LBL_POLLMONITOREDINBOXESFORBOUNCEDCAMPAIGNEMAILS' => 'Enviar Email Campanha Noturno Pulados',
'LBL_PRUNEDATABASE'                                => 'Ajustar Banco de dados de um mês',
'LBL_TRIMTRACKER'                                  => 'Ajustar Tabelas Rastreadores',
);?>
