<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_BLANK'                                        => '',
'LBL_MODULE_NAME'                                  => 'Ligações',
'LBL_MODULE_TITLE'                                 => 'Ligações: Principal',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar Ligações',
'LBL_LIST_FORM_TITLE'                              => 'Listar Ligações',
'LBL_NEW_FORM_TITLE'                               => 'Agendar Ligações',
'LBL_LIST_CLOSE'                                   => 'Fechar',
'LBL_LIST_SUBJECT'                                 => 'Assunto',
'LBL_LIST_CONTACT'                                 => 'Contato',
'LBL_LIST_RELATED_TO'                              => 'Referente a',
'LBL_LIST_RELATED_TO_ID'                           => 'Relacionado ao ID',
'LBL_LIST_DATE'                                    => 'Data de início',
'LBL_LIST_TIME'                                    => 'Hora de início',
'LBL_LIST_DURATION'                                => 'Duração',
'LBL_LIST_DIRECTION'                               => 'Direção',
'LBL_SUBJECT'                                      => 'Assunto:',
'LBL_REMINDER'                                     => 'Lembrete:',
'LBL_CONTACT_NAME'                                 => 'Contato:',
'LBL_DESCRIPTION_INFORMATION'                      => 'Informações de Descrição',
'LBL_DESCRIPTION'                                  => 'Descrição:',
'LBL_STATUS'                                       => 'Status:',
'LBL_DIRECTION'                                    => 'Direção:',
'LBL_DATE'                                         => 'Data de início:',
'LBL_DURATION'                                     => 'Duração:',
'LBL_DURATION_HOURS'                               => 'Duração (horas):',
'LBL_DURATION_MINUTES'                             => 'Duração (minutos):',
'LBL_HOURS_MINUTES'                                => '(horas/minutos)',
'LBL_CALL'                                         => 'Ligação:',
'LBL_DATE_TIME'                                    => 'Data e hora de início:',
'LBL_TIME'                                         => 'Hora de início:',
'LBL_HOURS_ABBREV'                                 => 'h',
'LBL_MINSS_ABBREV'                                 => 'm',
'LBL_COLON'                                        => ':',
'LBL_DEFAULT_STATUS'                               => 'Planejado',
'LNK_NEW_CALL'                                     => 'Agendar Ligação',
'LNK_NEW_MEETING'                                  => 'Agendar Reunião',
'LNK_NEW_TASK'                                     => 'Nova Tarefa',
'LNK_NEW_NOTE'                                     => 'Nova Anotação ou Anexo',
'LNK_NEW_EMAIL'                                    => 'Arquivar E-mail',
'LNK_CALL_LIST'                                    => 'Ligações',
'LNK_MEETING_LIST'                                 => 'Reuniões',
'LNK_TASK_LIST'                                    => 'Tarefas',
'LNK_NOTE_LIST'                                    => 'Anotações',
'LNK_EMAIL_LIST'                                   => 'E-mails',
'LNK_VIEW_CALENDAR'                                => 'Hoje',
'ERR_DELETE_RECORD'                                => 'Um número do registro deve ser especificado para remover a conta.',
'NTC_REMOVE_INVITEE'                               => 'Tem certeza que deseja remover este convidado da Ligação?',
'LBL_INVITEE'                                      => 'Convidados',
'LBL_RELATED_TO'                                   => 'Referente a:',
'LNK_NEW_APPOINTMENT'                              => 'Criar Compromisso',
'LBL_SCHEDULING_FORM_TITLE'                        => 'Agendamento',
'LBL_ADD_INVITEE'                                  => 'Adicionar convidados',
'LBL_NAME'                                         => 'Nome completo',
'LBL_FIRST_NAME'                                   => 'Nome',
'LBL_LAST_NAME'                                    => 'Sobrenome',
'LBL_EMAIL'                                        => 'E-mail',
'LBL_PHONE'                                        => 'Telefone',
'LBL_SEND_BUTTON_TITLE'                            => 'Enviar convites [Alt+I]',
'LBL_SEND_BUTTON_KEY'                              => 'I',
'LBL_SEND_BUTTON_LABEL'                            => 'Enviar convites',
'LBL_DATE_END'                                     => 'Data de término',
'LBL_TIME_END'                                     => 'Hora de término',
'LBL_REMINDER_TIME'                                => 'Hora do lembrete',
'LBL_SEARCH_BUTTON'                                => 'Buscar',
'LBL_ACTIVITIES_REPORTS'                           => 'Relatório de Atividades',
'LBL_ADD_BUTTON'                                   => 'Adicionar',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Ligações',
'LBL_LOG_CALL'                                     => 'lista de ligações',
'LNK_SELECT_ACCOUNT'                               => 'Selecionar conta',
'LNK_NEW_ACCOUNT'                                  => 'Nova Conta',
'LNK_NEW_OPPORTUNITY'                              => 'Nova Oportunidade',
'LBL_DEL'                                          => 'Apagar',
'LBL_LEADS_SUBPANEL_TITLE'                         => 'Potencial',
'LBL_CONTACTS_SUBPANEL_TITLE'                      => 'Contatos',
'LBL_USERS_SUBPANEL_TITLE'                         => 'Usuários',
'LBL_OUTLOOK_ID'                                   => 'Outlook ID',
'LBL_MEMBER_OF'                                    => 'Membro de',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Notas',
'LBL_LIST_ASSIGNED_TO_NAME'                        => 'Usuário atribuído',
'LBL_LIST_MY_CALLS'                                => 'Minhas Ligações',
'LBL_SELECT_FROM_DROPDOWN'                         => 'Por favor faça uma seleção dos Relacionados ao dropdown primeiro.',
'LBL_ASSIGNED_TO_NAME'                             => 'Atribuído a:',
'LBL_ASSIGNED_TO_ID'                               => 'Atribuído a:',
'NOTICE_DURATION_TIME'                             => 'Tempo de duração deve ser maior que 0',
'LNK_IMPORT_CALLS'                                 => 'Importar Ligações',
'LBL_CALL_INFORMATION'                             => 'Principal Ligações',

);?>
