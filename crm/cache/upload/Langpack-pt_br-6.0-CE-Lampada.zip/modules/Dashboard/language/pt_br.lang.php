<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Painel',
'LBL_MODULE_TITLE'                                 => 'Painel: Principal',
'LNK_NEW_ACCOUNT'                                  => 'Nova Conta',
'LNK_NEW_CALL'                                     => 'Agendar Ligação',
'LNK_NEW_CASE'                                     => 'Nova Ocorrência',
'LNK_NEW_CONTACT'                                  => 'Novo Contato',
'LNK_NEW_ISSUE'                                    => 'Novo Bug',
'LNK_NEW_LEAD'                                     => 'Novo Potencial',
'LNK_NEW_MEETING'                                  => 'Agendar Reunião',
'LNK_NEW_NOTE'                                     => 'Nova Anotação',
'LNK_NEW_OPPORTUNITY'                              => 'Nova Oportunidade',
'LNK_NEW_QUOTE'                                    => 'Nova Cotação',
'LNK_NEW_TASK'                                     => 'Nova Tarefa',
'LBL_ADD_A_CHART'                                  => 'Adicionar um Gráfico',
'LBL_DELETE_FROM_DASHBOARD'                        => 'Excluir do Painel',
'LBL_MOVE_DOWN'                                    => 'Mover para Cima',
'LBL_MOVE_UP'                                      => 'Mover para Baixo',
'LBL_BASIC_CHARTS'                                 => '-- Gráfico Básico --',
'LBL_PUBLISHED_REPORTS'                            => '-- Relatórios Publicados --',
'LBL_MY_REPORTS'                                   => '-- Meus Relatórios Salvos --',
'LBL_TEAM_REPORTS'                                 => '-- Relatórios da Minha Equipe --',
'LBL_REPORT_NO_CHART'                              => 'Este relatório não possui um gráfico',
'LBL_MOVE_CHARTS'                                  => '(Clique no nome do gráfico para transferir para um outro lugar)',
'LBL_DASHBOARD_PAGE_1'                             => 'Painel Principal',
'LBL_DASHBOARD_PAGE_2'                             => 'Painelde Vendas',
'LBL_LIST_FORM_TITLE'                              => 'Moedas',
'LBL_CURRENCY'                                   => 'Moeda',
'LBL_ADD'                                          => 'Adcionar',
'LBL_MERGE'                                        => 'Fundir',
'LBL_MERGE_TXT'                                    => 'Por favor selecione as moedas que serão traçadas. Isto irá apagar todas as moedas com uma marca e transferir qualquer valor a eles associados à moeda selecionada.',
'LBL_US_DOLLAR'                                    => 'U.S. Dollar',
'LBL_DELETE'                                       => 'Apagar',
'LBL_LIST_SYMBOL'                                  => 'Símbolo da Moeda',
'LBL_LIST_NAME'                                    => 'Nome da Moeda',
'LBL_LIST_ISO4217'                                 => 'ISO 4217 Code',
'LBL_LIST_ISO4217_HELP'                            => 'Entre com o código de formatação ISO 4217 que define o nome e símbolo da moeda.',
'LBL_UPDATE'                                       => 'Update',
'LBL_LIST_RATE'                                    => 'Taxa de Conversão',
'LBL_LIST_RATE_HELP'                               => 'Uma Taxa de Conversão de 0.5 para Euro significa que 10 USD = 5 Euro.',
'LBL_LIST_STATUS'                                  => 'Status',
'LNK_NEW_EMAIL'                                    => 'Novo Email',
'NTC_DELETE_CONFIRMATION'                          => 'Tem certeza de que deseja apagar esse registro? Qualquer registro usando essa moeda será convertido para o sistema padrão quando for acessado. É melhor trocar o status para inativo.',
'LBL_BELOW_MIN'                                    => 'Taxa de Conversão deve ser acima de 0',
'currency_status_dom'                              => 'Ordem',
'LBL_CURRENCY' 									   =>'Moeda',

);?>
