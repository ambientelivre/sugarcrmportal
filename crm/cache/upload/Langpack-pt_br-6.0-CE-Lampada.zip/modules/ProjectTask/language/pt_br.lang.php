<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Tarefas de Projeto',
'LBL_MODULE_TITLE'                                 => 'Tarefas de Projeto: Principal',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar Tarefas de Projeto',
'LBL_LIST_FORM_TITLE'                              => 'Lista de Tarefas de Projeto',
'LBL_EDIT_TASK_IN_GRID_TITLE'                      => 'Editar Tarefa na Grid',
'LBL_ID'                                           => 'Id:',
'LBL_PROJECT_TASK_ID'                              => 'Tarefa do Projeto Id:',
'LBL_PROJECT_ID'                                   => 'Projeto Id:',
'LBL_DATE_ENTERED'                                 => 'Data Entrada:',
'LBL_DATE_MODIFIED'                                => 'Data de Modificação:',
'LBL_ASSIGNED_USER_ID'                             => 'Atribuído a:',
'LBL_MODIFIED_USER_ID'                             => 'Modificado por (Id do Usuário):',
'LBL_CREATED_BY'                                   => 'Criado por:',
'LBL_TEAM_ID'                                      => 'Equipe:',
'LBL_NAME'                                         => 'Nome:',
'LBL_STATUS'                                       => 'Status:',
'LBL_DATE_DUE'                                     => 'Data Limite:',
'LBL_TIME_DUE'                                     => 'Hora Limite:',
'LBL_RESOURCE'                                     => 'Recurso:',
'LBL_PREDECESSORS'                                 => 'Antecessores:',
'LBL_DATE_START'                                   => 'Data Inicial:',
'LBL_DATE_FINISH'                                  => 'Data Término:',
'LBL_TIME_START'                                   => 'Hora Inicial:',
'LBL_TIME_FINISH'                                  => 'Hora Término:',
'LBL_DURATION'                                     => 'Duração:',
'LBL_DURATION_UNIT'                                => 'Unidade de Duração:',
'LBL_ACTUAL_DURATION'                              => 'Duração Real:',
'LBL_PARENT_ID'                                    => 'Projeto:',
'LBL_PARENT_TASK_ID'                               => 'Id da Tarefa Principal:',
'LBL_PERCENT_COMPLETE'                             => 'Progresso (%):',
'LBL_PRIORITY'                                     => 'Prioridade:',
'LBL_DESCRIPTION'                                  => 'Descrição:',
'LBL_ORDER_NUMBER'                                 => 'Ordem:',
'LBL_TASK_NUMBER'                                  => 'Número da Tarefa:',
'LBL_TASK_ID'                                      => 'Tarefa ID:',
'LBL_DEPENDS_ON_ID'                                => 'Depende de:',
'LBL_MILESTONE_FLAG'                               => 'Marco:',
'LBL_ESTIMATED_EFFORT'                             => 'Esforço Estimado (hrs):',
'LBL_ACTUAL_EFFORT'                                => 'Esforço Real (hrs):',
'LBL_UTILIZATION'                                  => 'Utilização (%):',
'LBL_DELETED'                                      => 'Excluído:',
'LBL_LIST_ORDER_NUMBER'                            => 'Ordem',
'LBL_LIST_NAME'                                    => 'Nome',
'LBL_LIST_DAYS'                                    => 'dias',
'LBL_LIST_PARENT_NAME'                             => 'Projeto',
'LBL_LIST_PERCENT_COMPLETE'                        => 'Progresso (%)',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_LIST_DURATION'                                => 'Duração',
'LBL_LIST_ACTUAL_DURATION'                         => 'Duração Real',
'LBL_LIST_ASSIGNED_USER_ID'                        => 'Atribuído a',
'LBL_LIST_DATE_DUE'                                => 'Data Limite',
'LBL_LIST_DATE_START'                              => 'Data Inicial',
'LBL_LIST_DATE_FINISH'                             => 'Data Término',
'LBL_LIST_PRIORITY'                                => 'Prioridade',
'LBL_LIST_CLOSE'                                   => 'Concluir',
'LBL_PROJECT_NAME'                                 => 'Nome do Projeto',
'LNK_NEW_PROJECT'                                  => 'Criar Projeto',
'LNK_PROJECT_LIST'                                 => 'Lista de Projetos',
'LNK_NEW_PROJECT_TASK'                             => 'Nova Tarefa de Projeto',
'LNK_PROJECT_TASK_LIST'                            => 'Tarefas de Projetos',
'LBL_LIST_MY_PROJECT_TASKS'                        => 'Minhas Tarefas de Projeto Abertas',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Tarefas de Projeto',
'LBL_NEW_FORM_TITLE'                               => 'Nova Tarefa de Projeto',
'LBL_ACTIVITIES_TITLE'                             => 'Atividades',
'LBL_HISTORY_TITLE'                                => 'Histórico',
'LBL_ACTIVITIES_SUBPANEL_TITLE'                    => 'Atividades',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Histórico',
'DATE_JS_ERROR'                                    => 'Por favor forneça uma data correspondente à hora fornecida',
'LBL_ASSIGNED_USER_NAME'                           => 'Atribuído a:',
'LBL_PARENT_NAME'                                  => 'Nome do Projeto',
'LBL_LIST_PROJECT_NAME'                            => 'Projetos',
);?>
