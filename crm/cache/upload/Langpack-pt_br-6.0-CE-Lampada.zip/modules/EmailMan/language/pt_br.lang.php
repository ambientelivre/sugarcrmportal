<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_SEND_DATE_TIME'                               => 'Enviar Data',
'LBL_IN_QUEUE'                                     => 'Na Fila?',
'LBL_IN_QUEUE_DATE'                                => 'Data da Fila',
'ERR_INT_ONLY_EMAIL_PER_RUN'                       => 'Somente valores inteiros são aceitos para Número de emails enviados por lote',
'LBL_ATTACHMENT_AUDIT'                             => 'foi enviado. Não foi duplicado localmente para conservar o uso do disco ',
'LBL_CONFIGURE_SETTINGS'                           => 'Configurar',
'LBL_CUSTOM_LOCATION'                              => 'Definido pelo Usuário',
'LBL_DEFAULT_LOCATION'                             => 'Padrão',
'LBL_DISCLOSURE_TITLE'                             => 'Acrescente uma mensagem de divulgação para todos os e-mails',
'LBL_DISCLOSURE_TEXT_TITLE'                        => 'Divulgação de Sumário',
'LBL_DISCLOSURE_TEXT_SAMPLE'                       => 'AVISO: Este e-mail é uma mensagem para o uso exclusivo do destinatário (s) e podem conter informações confidenciais e privilegiadas. Qualquer revisão não autorizado, utilização, divulgação ou distribuição é proibida. Se você não for o destinatário pretendido, por favor, destruir todas as cópias da mensagem original e notifica o remetente para que nosso endereço registro pode ser corrigido. Obrigado.',
'LBL_EMAIL_DEFAULT_CHARSET'                        => 'Criar mensagem de e-mail com este character set',
'LBL_EMAIL_DEFAULT_EDITOR'                         => 'Criar e-mail utilizando este cliente',
'LBL_EMAIL_DEFAULT_DELETE_ATTACHMENTS'             => 'Deletar Anotações e Arquivos Anexos relacionados com Emails deletados',
'LBL_EMAIL_GMAIL_DEFAULTS'                         => 'Perfil Padrão Gmail',
'LBL_EMAIL_PER_RUN_REQ'                            => 'Número de emails enviados por lote:',
'LBL_EMAIL_SMTP_SSL'                               => 'Habilitar SMTP sobre SSL',
'LBL_EMAIL_USER_TITLE'                             => 'Padrões de Email do Usuário',
'LBL_EMAIL_OUTBOUND_CONFIGURATION'                 => 'Configuração Envio de Email',
'LBL_EMAILS_PER_RUN'                               => 'Número de emails enviados por lote:',
'LBL_ID'                                           => 'Id',
'LBL_LIST_CAMPAIGN'                                => 'Campanha',
'LBL_LIST_FORM_PROCESSED_TITLE'                    => 'Processado',
'LBL_LIST_FORM_TITLE'                              => 'Fila',
'LBL_LIST_FROM_EMAIL'                              => 'Email de',
'LBL_LIST_FROM_NAME'                               => 'Nome de',
'LBL_LIST_IN_QUEUE'                                => 'Em Processamento',
'LBL_LIST_MESSAGE_NAME'                            => 'Mensagem de Marketing',
'LBL_LIST_RECIPIENT_EMAIL'                         => 'Email do Destinatário',
'LBL_LIST_RECIPIENT_NAME'                          => 'Nome do Destinatário',
'LBL_LIST_SEND_ATTEMPTS'                           => 'Tentativas de Envio',
'LBL_LIST_SEND_DATE_TIME'                          => 'Enviar em',
'LBL_LIST_USER_NAME'                               => 'Nome do Usuário',
'LBL_LOCATION_ONLY'                                => 'Localização',
'LBL_LOCATION_TRACK'                               => 'Localização dos arquivos de acompanhamento de campanha (como campaign_tracker.php)',
'LBL_CAMP_MESSAGE_COPY'                            => 'Manter cópias das mensagens de campanha:',
'LBL_CAMP_MESSAGE_COPY_DESC'                       => 'Você gostaria de armazenar cópias completas de <bold>CADA</ Bold> e-mail mensagem enviada durante todas as campanhas? <Bold>Recomendamos e padronizamos para não</ bold>. Escolhendo não irá armazenar apenas o modelo que é enviada e as variáveis necessárias para recriar a mensagem individual.',
'LBL_MAIL_SENDTYPE'                                => 'Agente Transferidos de Emails',
'LBL_MAIL_SMTPAUTH_REQ'                            => 'Utilizar Autenticação SMTP?',
'LBL_MAIL_SMTPPASS'                                => 'Senha SMTP:',
'LBL_MAIL_SMTPPORT'                                => 'Porta SMTP:',
'LBL_MAIL_SMTPSERVER'                              => 'Servidor SMTP:',
'LBL_MAIL_SMTPUSER'                                => 'Usuário SMTP:',
'LBL_MARKETING_ID'                                 => 'Id de Marketing',
'LBL_MODULE_ID'                                    => 'EmailMan',
'LBL_MODULE_NAME'                                  => 'Envio de Email em Massa',
'LBL_CAMP_MODULE_NAME'                             => 'Configurações de Email de Campanha',
'LBL_MODULE_TITLE'                                 => 'Gerência da Fila de Email em Massa',
'LBL_NOTIFICATION_ON_DESC'                         => 'Enviar notificações via e-mail quando registros forem atribuídos.',
'LBL_NOTIFY_FROMADDRESS'                           => 'Endereço "De":',
'LBL_NOTIFY_FROMNAME'                              => 'Nome "De":',
'LBL_NOTIFY_ON'                                    => 'Notificações ligadas?',
'LBL_NOTIFY_SEND_BY_DEFAULT'                       => 'Enviar notificações por padrão?',
'LBL_NOTIFY_TITLE'                                 => 'Opções de Notificações via E-mail',
'LBL_OLD_ID'                                       => 'Id Anterior',
'LBL_OUTBOUND_EMAIL_TITLE'                         => 'Opções de E-mail Enviado',
'LBL_RELATED_ID'                                   => 'Id Relacionado',
'LBL_RELATED_TYPE'                                 => 'Tipo Relacionado',
'LBL_SAVE_OUTBOUND_RAW'                            => 'Salvar Emails Enviados',
'LBL_SEARCH_FORM_PROCESSED_TITLE'                  => 'Pesquisar Processados',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar Filas',
'LBL_VIEW_PROCESSED_EMAILS'                        => 'Exibir Emails Processados',
'LBL_VIEW_QUEUED_EMAILS'                           => 'Exibir Emails Enfileirados',
'TRACKING_ENTRIES_LOCATION_DEFAULT_VALUE'          => 'Valor definido para site_url em Config.php',
'TXT_REMOVE_ME_ALT'                                => 'Para remover você mesmo desta lista de emails vá para ',
'TXT_REMOVE_ME_CLICK'                              => 'clique aqui',
'TXT_REMOVE_ME'                                    => 'Para remover você mesmo desta lista de emails ',
'LBL_NOTIFY_SEND_FROM_ASSIGNING_USER'              => 'Enviar notificação do endereço de e-mail do usuário atribuído? ',
'LBL_SECURITY_TITLE'                               => 'Configurações de Segurança de Email',
'LBL_SECURITY_DESC'                                => 'Cheque os que NÃO devem ser permitidos via Emails Recebidos ou mostrados no Módulo de Email',
'LBL_SECURITY_APPLET'                              => 'Applet tag',
'LBL_SECURITY_BASE'                                => 'Base tag',
'LBL_SECURITY_EMBED'                               => 'Embed tag',
'LBL_SECURITY_FORM'                                => 'Formulário tag',
'LBL_SECURITY_FRAME'                               => 'Frame tag',
'LBL_SECURITY_FRAMESET'                            => 'Frameset tag',
'LBL_SECURITY_IFRAME'                              => 'iFrame tag',
'LBL_SECURITY_IMPORT'                              => 'Importar tag',
'LBL_SECURITY_LAYER'                               => 'Layer tag',
'LBL_SECURITY_LINK'                                => 'Link tag ',
'LBL_SECURITY_OBJECT'                              => 'Objeto tag',
'LBL_SECURITY_OUTLOOK_DEFAULTS'                    => 'Selecione precauções de segurança mínimas para Outlook (Erros no lado de disposição correta).',
'LBL_SECURITY_SCRIPT'                              => 'Tag de Script',
'LBL_SECURITY_STYLE'                               => 'Tag de Estilo',
'LBL_SECURITY_TOGGLE_ALL'                          => 'Habilitar Todas Opções',
'LBL_SECURITY_XMP'                                 => 'Tag Xmp',
'LBL_YES'                                          => 'Sim',
'LBL_NO'                                           => 'Não',
'LBL_PREPEND_TEST'                                 => '[Teste]:',
'LBL_SEND_ATTEMPTS'                                => 'Envie Tentativas',
'LBL_OUTGOING_SECTION_HELP'                        => 'Configure o padrão do servidor de email para enviar emails de notificação, incluindo fluxo de alertas.',
'LBL_ALLOW_DEFAULT_SELECTION'                      => 'Permitir que os usuários para utilizem esta conta para enviar email:',
'LBL_ALLOW_DEFAULT_SELECTION_HELP'                 => 'Quando esta opção for selecionada, todos os usuários serão capazes de enviar emails usando a mesma conta de saída <br> usado para enviar as notificações do sistema e alertas. Se a opção não for selecionada, <br> os usuários podem ainda utilizar o servidor de email de saída após fornecer suas informações por conta própria.',
'LBL_CHOOSE_EMAIL_PROVIDER'                        => 'Escolha seu provedor de Email',
'LBL_YAHOOMAIL_SMTPPASS'                           => 'Yahoo! Senha',
'LBL_YAHOOMAIL_SMTPUSER'                           => 'Yahoo! Nome de Usuário',
'LBL_GMAIL_SMTPPASS'                               => 'Gmail Senha',
'LBL_GMAIL_SMTPUSER'                               => 'Gmail Endereço de Email',
'LBL_EXCHANGE_SMTPPASS'                            => 'Mudar Senha',
'LBL_EXCHANGE_SMTPUSER'                            => 'Mudar Nome de Usuário',
'LBL_EXCHANGE_SMTPPORT'                            => 'Mudar Porta Servidor',
'LBL_EXCHANGE_SMTPSERVER'                          => 'Mudar Servidor',
'LBL_EMAIL_LINK_TYPE'                              => 'Cliente Email ',
'LBL_EMAIL_LINK_TYPE_HELP'                         => '<b>Cliente Email Sugar:</b>Enviar emails usando o cliente email nas aplicações de email.<br><b>Cliente Email Externo:</b>Enviar email usando um cliente email fora das aplicações do Sugar, assim como Microsoft Outlook.',
'LBL_CONFIGURE_CAMPAIGN_EMAIL_SETTINGS'            => 'Altere as Configurações de Email da Campanha',

);?>
