<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Histórico',
'LBL_MODULE_TITLE'                                 => 'Histórico: Principal',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar Histórico',
'LBL_LIST_FORM_TITLE'                              => 'Histórico',
'LBL_LIST_SUBJECT'                                 => 'Assunto',
'LBL_LIST_CONTACT'                                 => 'Contato',
'LBL_LIST_RELATED_TO'                              => 'Relacionado a ',
'LBL_LIST_DATE'                                    => 'Data',
'LBL_LIST_TIME'                                    => 'Hora Inicial',
'LBL_LIST_CLOSE'                                   => 'Concluir',
'LBL_SUBJECT'                                      => 'Assunto:',
'LBL_STATUS'                                       => 'Status:',
'LBL_LOCATION'                                     => 'Localização:',
'LBL_DATE_TIME'                                    => 'Data & Hora Inicial:',
'LBL_DATE'                                         => 'Data Inicial:',
'LBL_TIME'                                         => 'Hora Inicial:',
'LBL_DURATION'                                     => 'Duração:',
'LBL_HOURS_MINS'                                   => '(horas/minutos)',
'LBL_CONTACT_NAME'                                 => 'Nome do Contato: ',
'LBL_MEETING'                                      => 'Reunião:',
'LBL_DESCRIPTION_INFORMATION'                      => 'Informação da Descrição',
'LBL_DESCRIPTION'                                  => 'Descrição:',
'LBL_COLON'                                        => ':',
'LBL_DEFAULT_STATUS'                               => 'Planejado',
'LNK_NEW_CALL'                                     => 'Agendar Ligação',
'LNK_NEW_MEETING'                                  => 'Agendar Reunião',
'LNK_NEW_TASK'                                     => 'Nova Tarefa',
'LNK_NEW_NOTE'                                     => 'Nova Anotação',
'LNK_NEW_EMAIL'                                    => 'Novo Email',
'LNK_CALL_LIST'                                    => 'Ligações',
'LNK_MEETING_LIST'                                 => 'Reuniões',
'LNK_TASK_LIST'                                    => 'Tarefas',
'LNK_NOTE_LIST'                                    => 'Anotações',
'LNK_EMAIL_LIST'                                   => 'Emails',
'ERR_DELETE_RECORD'                                => 'Um número de registro deve ser especificado para excluir a conta.',
'NTC_REMOVE_INVITEE'                               => 'Tem certeza que quer remover este convidado da reunião',
'LBL_INVITEE'                                      => 'Convidados',
'LBL_LIST_DIRECTION'                               => 'Direção',
'LBL_DIRECTION'                                    => 'Direção',
'LNK_NEW_APPOINTMENT'                              => 'Novo Compromisso',
'LNK_VIEW_CALENDAR'                                => 'Hoje',
'LBL_OPEN_ACTIVITIES'                              => 'Abrir Atividades',
'LBL_HISTORY'                                      => 'Histórico',
'LBL_UPCOMING'                                     => 'Meus Próximos Compromissos',
'LBL_TODAY'                                        => 'até ',
'LBL_NEW_TASK_BUTTON_TITLE'                        => 'Nova Tarefa [Alt+N]',
'LBL_NEW_TASK_BUTTON_KEY'                          => 'N',
'LBL_NEW_TASK_BUTTON_LABEL'                        => 'Nova Tarefa',
'LBL_SCHEDULE_MEETING_BUTTON_TITLE'                => 'Agendar Reunião [Alt+M]',
'LBL_SCHEDULE_MEETING_BUTTON_KEY'                  => 'M',
'LBL_SCHEDULE_MEETING_BUTTON_LABEL'                => 'Agendar Reunião',
'LBL_SCHEDULE_CALL_BUTTON_TITLE'                   => 'Agendar Ligação [Alt+C]',
'LBL_SCHEDULE_CALL_BUTTON_KEY'                     => 'C',
'LBL_SCHEDULE_CALL_BUTTON_LABEL'                   => 'Agendar Ligação',
'LBL_NEW_NOTE_BUTTON_TITLE'                        => 'Nova Anotação [Alt+T]',
'LBL_NEW_NOTE_BUTTON_KEY'                          => 'T',
'LBL_NEW_NOTE_BUTTON_LABEL'                        => 'Nova Anotação',
'LBL_TRACK_EMAIL_BUTTON_TITLE'                     => 'Novo Email [Alt+K]',
'LBL_TRACK_EMAIL_BUTTON_KEY'                       => 'K',
'LBL_TRACK_EMAIL_BUTTON_LABEL'                     => 'Novo Email',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_LIST_DUE_DATE'                                => 'Data Limite',
'LBL_LIST_LAST_MODIFIED'                           => 'Última Alteração',
'NTC_NONE_SCHEDULED'                               => 'Nenhum agandamento.',
'LNK_IMPORT_NOTES'                                 => 'Anotações Importantes',
'NTC_NONE'                                         => 'Nenhum',
'LBL_ACCEPT_THIS'                                  => 'Aceitar?',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Histórico',


'appointment_filter_dom' => array(
'today'                                            => 'hoje',
'tomorrow'                                         => 'amanhã',
'this Saturday'                                    => 'esta semana',
'next Saturday'                                    => 'próxima semana',
'last this_month'                                  => 'este mês',
'last next_month'                                  => 'próximo mês',
),
);?>
