<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_TEAM'                                         => 'Equipe',
'LBL_TEAM_ID'                                      => 'Equipe ID',
'LBL_ASSIGNED_TO_ID'                               => 'Atribuído para ID',
'LBL_ASSIGNED_TO_NAME'                             => 'Atribuído para',
'LBL_ID'                                           => 'ID',
'LBL_DATE_ENTERED'                                 => 'Data da Criação',
'LBL_DATE_MODIFIED'                                => 'Data da Modificação',
'LBL_MODIFIED'                                     => 'Modificado Por',
'LBL_MODIFIED_ID'                                  => 'Modificado por',
'LBL_MODIFIED_NAME'                                => 'Modificado por',
'LBL_CREATED'                                      => 'Criado por',
'LBL_CREATED_ID'                                   => 'Criado pelo ID',
'LBL_DESCRIPTION'                                  => 'Descrição',
'LBL_DELETED'                                      => 'Deletado',
'LBL_NAME'                                         => 'Nome',
'LBL_SAVING'                                       => 'Salvando...',
'LBL_SAVED'                                        => 'Salvo',
'LBL_CREATED_USER'                                 => 'Criado pelo usuário',
'LBL_MODIFIED_USER'                                => 'Modificado pelo usuário',
'LBL_LIST_FORM_TITLE'                              => 'Lista do Sugar Feed',
'LBL_MODULE_NAME'                                  => 'Sugar Feed',
'LBL_MODULE_TITLE'                                 => 'Sugar Feed',
'LBL_DASHLET_DISABLED'                             => 'Atenção: O sistema Sugar Feed está desabilitado, nenhuma nova entrada de feed será postada até que ele seja ativado.',
'LBL_ADMIN_SETTINGS'                               => 'Configurações Sugar Feed',
'LBL_RECORDS_DELETED'                              => 'Todas as entradas de Sugar Feeds anteriores foram removidas, caso o sistema Sugar Feed esteja ativado, novas entradas serão gerados automaticamente.',
'LBL_CONFIRM_DELETE_RECORDS'                       => 'Você esta certo que deseja deletar todas as entradas do Sugar Feed?',
'LBL_FLUSH_RECORDS'                                => 'Feeds deletados',
'LBL_ENABLE_FEED'                                  => 'Habilitar Sugar Feed',
'LBL_ENABLE_MODULE_LIST'                           => 'Ativados Feeds para',
'LBL_HOMEPAGE_TITLE'                               => 'Meus Sugar Feed',
'LNK_NEW_RECORD'                                   => 'Criar Sugar Feed',
'LNK_LIST'                                         => 'Sugar Feed',
'LBL_SEARCH_FORM_TITLE'                            => 'Procurar Sugar Feed',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Ver Histórico',
'LBL_ACTIVITIES_SUBPANEL_TITLE'                    => 'Atividades',
'LBL_SUGAR_FEED_SUBPANEL_TITLE'                    => 'Sugar Feed',
'LBL_NEW_FORM_TITLE'                               => 'Novo Sugar Feed',
'LBL_ALL'                                          => 'Todos',
'LBL_USER_FEED'                                    => 'Usuário Feed',
'LBL_ENABLE_USER_FEED'                             => 'Ativar usuário Feed',
'LBL_TO'                                           => 'Enviar para',
'LBL_IS'                                           => 'é',
'LBL_DONE'                                         => 'Feito',
'LBL_TITLE'                                        => 'Título',
'LBL_ROWS'                                         => 'Linhas',
'LBL_CATEGORIES'                                   => 'Módulos',
'LBL_TIME_LAST_WEEK'                               => 'Semana passada',
'LBL_TIME_WEEKS'                                   => 'Semanas',
'LBL_TIME_DAYS'                                    => 'Dias',
'LBL_TIME_YESTERDAY'                               => 'Ontem',
'LBL_TIME_HOURS'                                   => 'Horas',
'LBL_TIME_HOUR'                                    => 'Horas',
'LBL_TIME_MINUTES'                                 => 'Minutos',
'LBL_TIME_MINUTE'                                  => 'Minutos',
'LBL_TIME_SECONDS'                                 => 'Segundos',
'LBL_TIME_SECOND'                                  => 'Segundos',
'LBL_TIME_AGO'                                     => 'atrás',
'CREATED_CONTACT'                                  => 'criado um <B>NOVO</B> contato',
'CREATED_OPPORTUNITY'                              => 'criada uma <B>NOVA</B> oportunidade',
'CREATED_CASE'                                     => 'criado uma <B>NOVA</B> ocorrência',
'CREATED_LEAD'                                     => 'criado um <B>NOVO</B> potencial',
'FOR'                                              => 'para',
'CLOSED_CASE'                                      => 'Uma ocorrência <b>FINALIZADA</b>',
'CONVERTED_LEAD'                                   => 'Um potencial <b>CONVERTIDO</b>',
'WON_OPPORTUNITY'                                  => 'tem uma oportunidade  <b>GANHA</b>',
'WITH'                                             => 'com',
'LBL_LINK_TYPE_Link'                               => 'Link',
'LBL_LINK_TYPE_Image'                              => 'Imagem',
'LBL_LINK_TYPE_YouTube'                            => 'YouTube™',
'LBL_SELECT'                                       => 'Selecionar',
'LBL_POST'                                         => 'Postar',
);?>
