<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Tarefas',
'LBL_TASK'                                         => 'Tarefas: ',
'LBL_MODULE_TITLE'                                 => 'Tarefas: Principal',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar Tarefas',
'LBL_LIST_FORM_TITLE'                              => 'Lista de Tarefas',
'LBL_NEW_FORM_TITLE'                               => 'Nova Tarefa',
'LBL_NEW_FORM_SUBJECT'                             => 'Assunto:',
'LBL_NEW_FORM_DUE_DATE'                            => 'Data Limite:',
'LBL_NEW_FORM_DUE_TIME'                            => 'Hora Limite:',
'LBL_NEW_TIME_FORMAT'                              => '(24:00)',
'LBL_LIST_CLOSE'                                   => 'Concluir',
'LBL_LIST_SUBJECT'                                 => 'Assunto',
'LBL_LIST_CONTACT'                                 => 'Contato',
'LBL_LIST_PRIORITY'                                => 'Prioridade',
'LBL_LIST_RELATED_TO'                              => 'Relacionada a',
'LBL_LIST_DUE_DATE'                                => 'Data Limite',
'LBL_LIST_DUE_TIME'                                => 'Hora Limite',
'LBL_SUBJECT'                                      => 'Assunto:',
'LBL_STATUS'                                       => 'Status:',
'LBL_DUE_DATE'                                     => 'Data Limite:',
'LBL_DUE_TIME'                                     => 'Hora Limite:',
'LBL_PRIORITY'                                     => 'Prioridade:',
'LBL_COLON'                                        => ':',
'LBL_DUE_DATE_AND_TIME'                            => 'Data & Hora Limites:',
'LBL_START_DATE_AND_TIME'                          => 'Data & Hora Início:',
'LBL_START_DATE'                                   => 'Data Início:',
'LBL_LIST_START_DATE'                              => 'Data Início:',
'LBL_START_TIME'                                   => 'Hora Inicial:',
'LBL_LIST_START_TIME'                              => 'Hora Inicial:',
'DATE_FORMAT'                                      => '(aaaa-mm-dd 24:00)',
'LBL_NONE'                                         => 'Nada',
'LBL_CONTACT'                                      => 'Contato:',
'LBL_EMAIL_ADDRESS'                                => 'Email:',
'LBL_PHONE'                                        => 'Fone:',
'LBL_EMAIL'                                        => 'Email:',
'LBL_DESCRIPTION_INFORMATION'                      => 'Informação de Descrição',
'LBL_DESCRIPTION'                                  => 'Descrição:',
'LBL_NAME'                                         => 'Nome:',
'LBL_CONTACT_NAME'                                 => 'Nome do Contato: ',
'LBL_LIST_COMPLETE'                                => 'Completar:',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_DATE_DUE_FLAG'                                => 'Sem Data Limite',
'LBL_DATE_START_FLAG'                              => 'Sem Data Início',
'ERR_DELETE_RECORD'                                => 'Um número de registro deve ser especificado para excluir o contato.',
'ERR_INVALID_HOUR'                                 => 'Por favor informe uma hora entre 00:00 e 24:00',
'LBL_DEFAULT_STATUS'                               => 'Não Iniciada',
'LBL_DEFAULT_PRIORITY'                             => 'Médio',
'LBL_LIST_MY_TASKS'                                => 'Minhas Tarefas Abertas',
'LNK_NEW_CALL'                                     => 'Nova Ligação',
'LNK_NEW_MEETING'                                  => 'Nova Reunião',
'LNK_NEW_TASK'                                     => 'Nova Tarefa',
'LNK_NEW_NOTE'                                     => 'Nova Anotação',
'LNK_NEW_EMAIL'                                    => 'Novo Email',
'LNK_CALL_LIST'                                    => 'Ligações',
'LNK_MEETING_LIST'                                 => 'Reuniões',
'LNK_TASK_LIST'                                    => 'Tarefas',
'LNK_NOTE_LIST'                                    => 'Anotações',
'LNK_EMAIL_LIST'                                   => 'Emails',
'LNK_VIEW_CALENDAR'                                => 'Hoje',
'LBL_CONTACT_FIRST_NAME'                           => 'Nome do Contato',
'LBL_CONTACT_LAST_NAME'                            => 'Sobrenome do Contato',
'LBL_LIST_ASSIGNED_TO_NAME'                        => 'Atribuído a:',
'LBL_ASSIGNED_TO_NAME'                             => 'Atribuído a:',
'LBL_LIST_DATE_MODIFIED'                           => 'Data Modificado',
'LBL_CONTACT_ID'                                   => 'ID do contato:',
'LBL_PARENT_ID'                                    => 'ID Relacionado:',
'LBL_CONTACT_PHONE'                                => 'Fone do Contato:',
'LBL_PARENT_NAME'                                  => 'Relacionado ao Tipo:',
'LBL_ACTIVITIES_REPORTS'                           => 'Relatório de Atividades',
'LNK_IMPORT_TASKS'                                 => 'Importar Tarefas',
'LBL_TASK_INFORMATION'                             => 'Principal Tarefas',

);?>
