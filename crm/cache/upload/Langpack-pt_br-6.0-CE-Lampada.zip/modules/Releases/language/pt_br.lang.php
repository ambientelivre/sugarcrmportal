<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Versões',
'LBL_MODULE_TITLE'                                 => 'Versões: Principal',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar Versões',
'LBL_LIST_FORM_TITLE'                              => 'Lista de Versões',
'LBL_NEW_FORM_TITLE'                               => 'Nova Versão',
'LBL_RELEASE'                                      => 'Versão:',
'LBL_LIST_NAME'                                    => 'Versão',
'LBL_NAME'                                         => 'Liberação de versão:',
'LBL_LIST_LIST_ORDER'                              => 'Ordem',
'LBL_LIST_ORDER'                                   => 'Ordem:',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_STATUS'                                       => 'Status:',
'LNK_NEW_RELEASE'                                  => 'Lista de Versões',
'NTC_DELETE_CONFIRMATION'                          => 'Tem certeza que deseja excluir este registro?',
'ERR_DELETE_RECORD'                                => 'Um número de registro deve ser especificado para excluir a versão.',
'NTC_STATUS'                                       => 'Altere o status para Inativo para remover esta Versão das Listas Suspensas',
'NTC_LIST_ORDER'                                   => 'Configure a ordem que a versão irá aparecer nas listas suspensas',


'release_status_dom' => array(
'Active'                                           => 'Ativo',
'Inactive'                                         => 'Inativo',
),
);?>
