<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'ShowActiveUsers'                                  => 'Mostrar usuários Ativos',
'ShowLastModifiedRecords'                          => 'Últimos 10 registros modificados',
'ShowTopUser'                                      => 'Usuário Top',
'ShowMyModuleUsage'                                => 'Meus Módulos Usuais',
'ShowMyWeeklyActivities'                           => 'Minha Atividade Semanal',
'ShowTop3ModulesUsed'                              => 'Top 3 Meus Módulos Usados',
'ShowLoggedInUserCount'                            => 'Conta Ativa do Usuário',
'ShowMyCumulativeLoggedInTime'                     => 'Meu tempo de Login Cumulativo (Esta Semana)',
'ShowUsersCumulativeLoggedInTime'                  => 'Tempo de Login Cumulativo dos Usuários (Esta Semana)',
'action'                                           => 'Ação',
'active_users'                                     => 'Conta Ativa do Usuário',
'date_modified'                                    => 'Data da Última Ação',
'different_modules_accessed'                       => 'Número de Módulos Acessados',
'first_name'                                       => 'Primeiro Nome',
'item_id'                                          => 'ID',
'item_summary'                                     => 'Nome ',
'last_action'                                      => 'Última Ação Data/Hora',
'last_name'                                        => 'Sobrenome',
'module_name'                                      => 'Nome do Módulo',
'records_modified'                                 => 'Total de Registros Modificados',
'top_module'                                       => 'Top Módulos Acessados',
'total_count'                                      => 'Total Páginas Visitadas',
'total_login_time'                                 => 'Hora (hh:mm:ss)',
'user_name'                                        => 'Usuário',
'users'                                            => 'Usuários',
'LBL_ENABLE'                                       => 'Habilitado',
'LBL_MODULE_NAME_TITLE'                            => 'Rastreadores',
'LBL_TRACKER_SETTINGS'                             => 'Configurações de Rastreamento',
'LBL_TRACKER_QUERIES_DESC'                         => 'Rastreador de Queries',
'LBL_TRACKER_QUERIES_HELP'                         => 'Rastrear consultas SQL quando dump_slow_queries está habilitada e o tempo de execução da query é inferior ao valor de slow_query_time_msec em config.php',
'LBL_TRACKER_PERF_DESC'                            => 'Performance do Rastreador',
'LBL_TRACKER_PERF_HELP'                            => 'Rastrear roundtrips de Banco de Dados, arquivos e memória usada.',
'LBL_TRACKER_SESSIONS_DESC'                        => 'Rastrear Seções',
'LBL_TRACKER_SESSIONS_HELP'                        => 'Rastrear usuários ativos e informação de sessão',
'LBL_TRACKER_DESC'                                 => 'Rastrear Ações',
'LBL_TRACKER_HELP'                                 => 'Rastrear páginas visitadas por usuários (módulos e registros acessados) e registros salvos.',
'LBL_TRACKER_PRUNE_INTERVAL'                       => 'Número de dias Rastreados que serão mantidos quando o Agendador limpar os dados.',
'LBL_TRACKER_PRUNE_RANGE'                          => 'Número de Dias',
'LBL_MODULE_NAME'                                  => 'Rastreadores ',

);?>
