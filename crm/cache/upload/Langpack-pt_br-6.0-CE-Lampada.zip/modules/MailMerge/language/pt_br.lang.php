<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_STEP_1'                                       => 'Passo 1: Selecione o Módulo e Modelo',
'LBL_MAILMERGE_MODULE'                             => 'Selecione o Módulo: ',
'LBL_MAILMERGE_SELECTED_MODULE'                    => 'Módulo Selecionado: ',
'LBL_MAILMERGE_TEMPLATES'                          => 'Selecione o Modelo: ',
'LBL_STEP_2'                                       => 'Passo 2: Selecione Objetos para Incluir',
'LBL_MAILMERGE_OBJECTS'                            => 'Selecione Objetos: ',
'LBL_STEP_3'                                       => 'Defina a Associação com Contato',
'LBL_STEP_4'                                       => 'Revise e Complete',
'LBL_SELECTED_MODULE'                              => 'Módulo Selecionado: ',
'LBL_SELECTED_TEMPLATE'                            => 'Modelo Selecionado: ',
'LBL_SELECTED_ITEMS'                               => 'Itens Selecionados: ',
'LBL_STEP_5'                                       => 'Mala Direta Completa',
'LBL_MERGED_FILE'                                  => 'Arquivo Incluído: ',
'LNK_NEW_MAILMERGE'                                => 'Iniciar Mala Direta',
'LNK_UPLOAD_TEMPLATE'                              => 'Carregar Modelo',
'LBL_DOC_NAME'                                     => 'Nome do Documento:',
'LBL_FILENAME'                                     => 'Nome do Arquivo:',
'LBL_DOC_VERSION'                                  => 'Revisão:',
'LBL_DOC_DESCRIPTION'                              => 'Descrição:',
'LBL_LIST_NAME'                                    => 'Nome',
'LBL_LIST_RELATIONSHIP'                            => 'Defina o Relacionamento com Contato ',
'LBL_FINISH'                                       => 'Iniciar Inclusão',
'LBL_NEXT'                                         => 'Próximo >',
'LBL_BACK'                                         => '< Anterior',
'LBL_START'                                        => 'Iniciar Novamente',
'LBL_TEMPLATE_NOTICE'                              => 'Modelos são documentos do Microsoft Word contendo campos de inclusão que devem ser carregados e armazenados no módulo Documentos.',
'LBL_CONTAINS_CONTACT_INFO'                        => 'O modelo selecionado contém informações de Contato.',
'LBL_ADDIN_NOTICE'                                 => 'Isto requer a instalação do add-in Mala Direta Sugar para Microsoft Word.',
'LBL_BROWSER_NOTICE'                               => 'Você deve estar rodando IE 6.0 ou superior para realizar a inclusão.',
);?>
