<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_TITLE'                                 => 'Minhas Buscas Salvas',
'LBL_SEARCH_FORM_TITLE'                            => 'Minhas Buscas Salvas: Buscar',
'LBL_LIST_FORM_TITLE'                              => 'Minha Lista de  Buscas Salvas',
'LBL_DELETE_CONFIRM'                               => 'Você tem certeza que deseja apagar as buscas salvas selecionadas?',
'LBL_UPDATE_BUTTON_TITLE'                          => 'Atualizar esta Busca Salva',
'LBL_DELETE_BUTTON_TITLE'                          => 'Apagar esta Busca salva',
'LBL_SAVE_BUTTON_TITLE'                            => 'Salvar a busca atual',
'LBL_LIST_NAME'                                    => 'Nome',
'LBL_LIST_MODULE'                                  => 'Módulo',
'LBL_ORDER_BY_COLUMNS'                             => 'Ordenar pela coluna:',
'LBL_DIRECTION'                                    => 'Direção:',
'LBL_SAVE_SEARCH_AS'                               => 'Salvar esta busca como:',
'LBL_SAVE_SEARCH_AS_HELP'                          => 'Isto salva suas configurações de visualização e qualquer filtro na aba de Busca Avançada.',
'LBL_PREVIOUS_SAVED_SEARCH'                        => 'Buscas anteriores salvas:',
'LBL_PREVIOUS_SAVED_SEARCH_HELP'                   => 'Editar ou Apagar uma Busca salva existente. ',
'LBL_ASCENDING'                                    => 'Crescente',
'LBL_DESCENDING'                                   => 'Decrescente',
'LBL_MODIFY_CURRENT_SEARCH'                        => 'Alterar Busca',
);?>
