<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Atividades',
'LBL_MODULE_TITLE'                                 => 'Atividades: Principal',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar atividades',
'LBL_LIST_FORM_TITLE'                              => 'Listar atividades',
'LBL_LIST_SUBJECT'                                 => 'Assunto',
'LBL_LIST_CONTACT'                                 => 'Contato',
'LBL_LIST_RELATED_TO'                              => 'Relacionado a',
'LBL_LIST_DATE'                                    => 'Data',
'LBL_LIST_TIME'                                    => 'Hora de início',
'LBL_LIST_CLOSE'                                   => 'Fechar',
'LBL_SUBJECT'                                      => 'Assunto:',
'LBL_STATUS'                                       => 'Status:',
'LBL_LOCATION'                                     => 'Local:',
'LBL_DATE_TIME'                                    => 'Data e hora de início:',
'LBL_DATE'                                         => 'Data de início:',
'LBL_TIME'                                         => 'Hora de início:',
'LBL_DURATION'                                     => 'Duração:',
'LBL_DURATION_MINUTES'                             => 'Duração (minutos):',
'LBL_HOURS_MINS'                                   => '(horas/minutos)',
'LBL_CONTACT_NAME'                                 => 'Nome do Contato: ',
'LBL_MEETING'                                      => 'Reunião:',
'LBL_DESCRIPTION_INFORMATION'                      => 'Informações da Descrição',
'LBL_DESCRIPTION'                                  => 'Descrição:',
'LBL_COLON'                                        => ':',
'LBL_DEFAULT_STATUS'                               => 'Planejada',
'LNK_NEW_CALL'                                     => 'Agendar Ligação',
'LNK_NEW_MEETING'                                  => 'Agendar Reunião',
'LNK_NEW_TASK'                                     => 'Nova Tarefa',
'LNK_NEW_NOTE'                                     => 'Nova Anotação ou Anexo',
'LNK_NEW_EMAIL'                                    => 'Arquivar E-mail',
'LNK_CALL_LIST'                                    => 'Ligações',
'LNK_MEETING_LIST'                                 => 'Reuniões',
'LNK_TASK_LIST'                                    => 'Tarefas',
'LNK_NOTE_LIST'                                    => 'Anotações',
'LNK_EMAIL_LIST'                                   => 'E-mails',
'ERR_DELETE_RECORD'                                => 'Você deve especificar o número de registros para deletar a conta',
'NTC_REMOVE_INVITEE'                               => 'Você tem certeza que deseja remover este convidado da Reunião?',
'LBL_INVITEE'                                      => 'Convidados',
'LBL_LIST_DIRECTION'                               => 'Direção',
'LBL_DIRECTION'                                    => 'Direção',
'LNK_NEW_APPOINTMENT'                              => 'Novo compromisso',
'LNK_VIEW_CALENDAR'                                => 'Hoje',
'LBL_OPEN_ACTIVITIES'                              => 'Atividades em aberto',
'LBL_HISTORY'                                      => 'Histórico',
'LBL_UPCOMING'                                     => 'Minhas próximas Atividades',
'LBL_TODAY'                                        => 'até ',
'LBL_NEW_TASK_BUTTON_TITLE'                        => 'Nova Tarefa [Alt+T]',
'LBL_NEW_TASK_BUTTON_KEY'                          => 'T',
'LBL_NEW_TASK_BUTTON_LABEL'                        => 'Nova Tarefa',
'LBL_SCHEDULE_MEETING_BUTTON_TITLE'                => 'Agendar Reunião [Alt+R]',
'LBL_SCHEDULE_MEETING_BUTTON_KEY'                  => 'R',
'LBL_SCHEDULE_MEETING_BUTTON_LABEL'                => 'Agendar Reunião',
'LBL_SCHEDULE_CALL_BUTTON_TITLE'                   => 'Agendar Ligação [Alt+L]',
'LBL_SCHEDULE_CALL_BUTTON_KEY'                     => 'L',
'LBL_SCHEDULE_CALL_BUTTON_LABEL'                   => 'Agendar Ligação',
'LBL_NEW_NOTE_BUTTON_TITLE'                        => 'Nova Anotação ou Anexo [Alt+A]',
'LBL_NEW_NOTE_BUTTON_KEY'                          => 'A',
'LBL_NEW_NOTE_BUTTON_LABEL'                        => 'Nova Anotação ou Anexo',
'LBL_TRACK_EMAIL_BUTTON_TITLE'                     => 'Arquivar E-mail [Alt+E]',
'LBL_TRACK_EMAIL_BUTTON_KEY'                       => 'E',
'LBL_TRACK_EMAIL_BUTTON_LABEL'                     => 'Arquivar E-mail',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_LIST_DUE_DATE'                                => 'Prazo',
'LBL_LIST_LAST_MODIFIED'                           => 'Última alteração',
'NTC_NONE_SCHEDULED'                               => 'Nada agendado.',
'LNK_IMPORT_NOTES'                                 => 'Importar Anotações',
'NTC_NONE'                                         => 'Nenhum',
'LBL_ACCEPT_THIS'                                  => 'Aceitar?',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Atividade em aberto',
'LBL_LIST_ASSIGNED_TO_NAME'                        => 'Atribuído a:',
'LBL_END_DATE'                                     => 'Data Final',
'LBL_FILTER_DATE_RANGE_START'                      => 'De',
'LBL_FILTER_DATE_RANGE_FINISH'                     => 'Para',
'LBL_SELECT_RECORD'                                => 'Registro Selecionado',
'LBL_ACTIVITIES_REPORTS'                           => 'Relatório Atividades',
'LBL_TYPE'                                         => 'Tipo',
'LBL_RUN_REPORT_BUTTON_LABEL'                      => 'Gerar Relatório',
'LBL_CLEAR'                                        => 'Limpar',
'LBL_EXPORT'                                       => 'Exportar',
'LBL_SELECT_MODULE'                                => 'Selecione Módulo',
'LBL_NONE_STRING'                                  => 'Nenhum',
'LNK_IMPORT_CALLS'                                 => 'Importar Ligações',
'LNK_IMPORT_MEETINGS'                              => 'Importar Reuniões',
'LNK_IMPORT_TASKS'                                 => 'Importar Tarefas ',


'appointment_filter_dom' => array(
'today'                                            => 'hoje',
'tomorrow'                                         => 'amanhã',
'this Saturday'                                    => 'esta semana',
'next Saturday'                                    => 'próximo semana',
'last this_month'                                  => 'este mês',
'last next_month'                                  => 'próximo mês',
),
);?>
