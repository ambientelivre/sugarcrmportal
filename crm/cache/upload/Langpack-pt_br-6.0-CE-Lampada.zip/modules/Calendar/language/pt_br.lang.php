<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Agenda',
'LBL_MODULE_TITLE'                                 => 'Agenda',
'LNK_NEW_CALL'                                     => 'Agendar Ligação',
'LNK_NEW_MEETING'                                  => 'Agendar Reunião',
'LNK_NEW_APPOINTMENT'                              => 'Agendar Compromisso',
'LNK_NEW_TASK'                                     => 'Nova Tarefa',
'LNK_CALL_LIST'                                    => 'Ligações',
'LNK_MEETING_LIST'                                 => 'Reuniões',
'LNK_TASK_LIST'                                    => 'Tarefas',
'LNK_VIEW_CALENDAR'                                => 'Hoje',
'LNK_IMPORT_CALLS'                                 => 'Importar Ligações',
'LNK_IMPORT_MEETINGS'                              => 'Importar Reuniões',
'LNK_IMPORT_TASKS'                                 => 'Importar Tarefas',
'LBL_MONTH'                                        => 'Mês',
'LBL_DAY'                                          => 'Dia',
'LBL_YEAR'                                         => 'Ano',
'LBL_WEEK'                                         => 'Semana',
'LBL_PREVIOUS_MONTH'                               => 'Mês Anterior',
'LBL_PREVIOUS_DAY'                                 => 'Dia Anterior',
'LBL_PREVIOUS_YEAR'                                => 'Ano Anterior',
'LBL_PREVIOUS_WEEK'                                => 'Semana Anterior',
'LBL_NEXT_MONTH'                                   => 'Próximo Mês',
'LBL_NEXT_DAY'                                     => 'Próximo Dia',
'LBL_NEXT_YEAR'                                    => 'Próximo Ano',
'LBL_NEXT_WEEK'                                    => 'Próxima Semana',
'LBL_AM'                                           => 'AM',
'LBL_PM'                                           => 'PM',
'LBL_SCHEDULED'                                    => 'Agendado',
'LBL_BUSY'                                         => 'Ocupado',
'LBL_CONFLICT'                                     => 'Conflito',
'LBL_USER_CALENDARS'                               => 'Calendário de Usuários',
'LBL_SHARED'                                       => 'Compartilhada',
'LBL_PREVIOUS_SHARED'                              => 'Anterior',
'LBL_NEXT_SHARED'                                  => 'Próxima',
'LBL_SHARED_CAL_TITLE'                             => 'Agenda Compartilhada',
'LBL_USERS'                                        => 'Usuário',
'LBL_REFRESH'                                      => 'Atualizar',
'LBL_EDIT'                                         => 'Editar',
'LBL_SELECT_USERS'                                 => 'Selecione usuários para exibir a agenda',
'LBL_FILTER_BY_TEAM'                               => 'Filtrar lista de usuários por equipe:',
'LBL_ASSIGNED_TO_NAME'                             => 'Atribuído a',
'LBL_DATE'                                         => 'Data e Hora de inicio',
);?>
