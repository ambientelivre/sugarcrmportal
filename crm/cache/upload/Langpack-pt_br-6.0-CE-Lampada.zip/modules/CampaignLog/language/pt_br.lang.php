<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_LIST_ID'                                      => 'ID da Lista de Prospectos',
'LBL_ID'                                           => 'ID',
'LBL_TARGET_TRACKER_KEY'                           => 'Chave de Localização de Prospectos',
'LBL_TARGET_ID'                                    => 'ID do Prospecto',
'LBL_TARGET_TYPE'                                  => 'Tipo de Prospecto',
'LBL_ACTIVITY_TYPE'                                => 'Tipo de Atividade',
'LBL_ACTIVITY_DATE'                                => 'Data de Atividade',
'LBL_RELATED_ID'                                   => 'Id Relacionado',
'LBL_RELATED_TYPE'                                 => 'Tipo Relacionado',
'LBL_DELETED'                                      => 'Excluído',
'LBL_MODULE_NAME'                                  => 'Registro de Campanha',
'LBL_LIST_RECIPIENT_EMAIL'                         => 'Email do Destinatário',
'LBL_LIST_RECIPIENT_NAME'                          => 'Nome do Destinatário',
'LBL_ARCHIVED'                                     => 'Arquivado',
'LBL_HITS'                                         => 'Hits',
'LBL_CAMPAIGN_NAME'                                => 'Nome:',
'LBL_CAMPAIGN'                                     => 'Campanha:',
'LBL_NAME'                                         => 'Nome: ',
'LBL_INVITEE'                                      => 'Contatos',
'LBL_LIST_CAMPAIGN_NAME'                           => 'Campanha',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_LIST_TYPE'                                    => 'Tipo',
'LBL_LIST_END_DATE'                                => 'Data Final',
'LBL_DATE_ENTERED'                                 => 'Data Entrada',
'LBL_DATE_MODIFIED'                                => 'Data Alteração',
'LBL_MODIFIED'                                     => 'Alterado por: ',
'LBL_CREATED'                                      => 'Criado por: ',
'LBL_TEAM'                                         => 'Equipe: ',
'LBL_ASSIGNED_TO'                                  => 'Atribuído a: ',
'LBL_CAMPAIGN_START_DATE'                          => 'Data Inicial: ',
'LBL_CAMPAIGN_END_DATE'                            => 'Data Final: ',
'LBL_CAMPAIGN_STATUS'                              => 'Status: ',
'LBL_CAMPAIGN_BUDGET'                              => 'Orçamento: ',
'LBL_CAMPAIGN_EXPECTED_COST'                       => 'Custo Estimado: ',
'LBL_CAMPAIGN_ACTUAL_COST'                         => 'Custo Real: ',
'LBL_CAMPAIGN_EXPECTED_REVENUE'                    => 'Receita Estimada: ',
'LBL_CAMPAIGN_TYPE'                                => 'Tipo: ',
'LBL_CAMPAIGN_OBJECTIVE'                           => 'Objetivo: ',
'LBL_CAMPAIGN_CONTENT'                             => 'Descrição: ',
'LBL_CREATED_LEAD'                                 => 'potencial criado',
'LBL_CREATED_CONTACT'                              => 'contato criado',
'LBL_LIST_FORM_TITLE'                              => 'Campanhas ',
'LBL_LIST_ACTIVITY_DATE'                           => 'Data de Atividade',
'LBL_LIST_CAMPAIGN_OBJECTIVE'                      => 'Objetivo da Campanha',
'LBL_RELATED'                                      => 'Relacionado',
'LBL_CLICKED_URL_KEY'                              => 'Chave do URL Clicado',
'LBL_URL_CLICKED'                                  => 'URL Clicado',
'LBL_MORE_INFO'                                    => 'Mais Informações',
'LBL_CAMPAIGNS'                                    => 'Campanhas',
);?>
