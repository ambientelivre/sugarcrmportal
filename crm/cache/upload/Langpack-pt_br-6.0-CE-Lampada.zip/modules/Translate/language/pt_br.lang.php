<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_SETTINGS'                                     => 'Settings',
'LBL_CREATE_LANG_PACK'                             => 'Criar Language Pack',
'LBL_ARCHIVES'                                     => 'Arquivos',
'LBL_SETTTINGS_SHOW_HIDE'                          => 'Mostrar / Esconder Settings',
'LBL_CREATE_LANG_PACK_SHOW_HIDE'                   => 'Mostrar / Esconder Criar Language Packs',
'LBL_ARCHIVES_SHOW_HIDE'                           => 'Mostrar / Esconder Arquivos',
'LBL_PREFIX'                                       => 'Prefixo',
'LBL_PREFIX_COMMENT'                               => 'Prefixo do arquivo Language, pt_br',
'LBL_AUTO_UPDATE'                                  => 'Auto Atualizar',
'LBL_AUTO_UPDATE_COMMENT'                          => 'Sugestões automáticas de atualização, se disponível',
'LBL_FILE_SUFFIX'                                  => '.lang.php',
'LBL_NO_LANG_SELECTED'                             => 'Por favor, escolha uma língua para traduzir o SugarCrm',
'LBL_FILE_NAME'                                    => 'Nome do arquivo:',
'LBL_FILENAME_COMMENT'                             => 'Nome do arquivo para exportar o Language Pack',
'LBL_LANG_PACK_FILE_SUFFIX'                        => '.zip',
'LBL_BUTTON_CREATE_LANG_PACK'                      => 'Criar',
'LBL_LANG_PACK_VERSION'                            => 'Versão:',
'LBL_EXAMPLE_LANG_PACK_VERSION'                    => 'Exemplo: 1,0',
'LBL_LANG_PACK_DATE'                               => 'Data de Publicação:',
'LBL_EXAMPLE_LANG_PACK_DATE'                       => 'Exemplo: 2008-02-11',
'LBL_LANG_PACK_AUTHOR'                             => 'Autor:',
'LBL_EXAMPLE_LANG_PACK_AUTHOR'                     => 'Exemplo: John Doe',
'LBL_LANG_PACK_NAME'                               => 'Nome:',
'LBL_EXAMPLE_LANG_PACK_NAME'                       => 'Exemplo: Portuguese Language Pack',
'LBL_LANG_PACK_DESC'                               => 'Descrição:',
'LBL_EXAMPLE_LANG_PACK_DESC'                       => 'Exemplo: SugarCrm traduzido para português.',
'LBL_MODULE'                                       => 'Módulo:',
'LBL_LABEL'                                        => 'Rótulo',
'LBL_LABEL_HEADER'                                 => 'Rótulo:',
'LBL_DROPDOWN'                                     => 'Dropdown:',
'LBL_STD_VALUE'                                    => 'Valor Standard',
'LBL_TRANSLATED'                                   => 'Valor Traduzido',
'LBL_SEPARATOR'                                    => ':',
'LBL_BY_LABEL'                                     => 'Por Rótulo',
'LBL_BY_STRING'                                    => 'Por Linha',
'LBL_NONE_FOUND'                                   => 'Nenhuma sugestão foi encontrada',
'LBL_LOADING'                                      => 'Carregando...',
'LBL_BUTTON_SAVE'                                  => 'Salvar',
'LBL_BUTTON_SAVE_GO_NEXT'                          => 'Salvar e ir para o próximo módulo',
'LBL_BUTTON_MOVE_TO_NEXT_EMPTY'                    => 'Ir par próximo vazio',
'BG_HEADER'                                        => '#c7d4d2',
'BG_SUB_HEADER'                                    => '#dee7ed ',
'LBL_ARCHIVES_NAME'                                => 'Nome',
'LBL_ARCHIVES_VERSION'                             => 'Versão',
'LBL_ARCHIVES_AUTHOR'                              => 'Autor',
'LBL_ARCHIVES_PUBLISHED'                           => 'Publicado',
'LBL_ARCHIVES_DESCRIPTION'                         => 'Descrição',
'LBL_NO_ACCESS'                                    => 'Acesso a este módulo somente para administradores',
'ShowActiveUsers'                                  => 'Mostrar Usuários Ativos',
'ShowLastModifiedRecords'                          => 'Últimos 10 Registros Modificados',
'ShowTopUser'                                      => 'Usuário Top',
'ShowMyModuleUsage'                                => 'Meu Uso do Módulo',
'ShowMyWeeklyActivities'                           => 'Minha Atividade Semanal',
'ShowTop3ModulesUsed'                              => 'Meus 3 Módulos Mais Usados',
'ShowLoggedInUserCount'                            => 'Ativar Usuário',
'ShowMyCumulativeLoggedInTime'                     => 'Meu Tempo Login Acumulado (Essa Semana)',
'ShowUsersCumulativeLoggedInTime'                  => 'Tempo de Login Acumulado dos Usuários (Essa Semana)',
'action'                                         => 'Ação',
'active_users'                                     => 'Ativar Usuário',
'date_modified'                                    => 'Data da última Ação',
'different_modules_accessed'                       => 'Número de Módulos Acessados',
'first_name'                                       => 'Primeiro Nome',
'item_id'                                          => 'ID',
'item_summary'                                     => 'Nome',
'last_action'                                      => 'Última Ação Data/Tempo',
'last_name'                                        => 'Último Nome',
'module_name'                                      => 'Módulo Nome',
'records_modified'                                 => 'Total de Registros Modificados',
'top_module'                                       => 'Módulos Mais Acessados',
'total_count'                                      => 'Total de Páginas Vistas',
'total_login_time'                                 => 'Tempo (hh:mm:ss)',
'user_name'                                        => 'Nome de Usuário',
'users'                                          => 'Usuários',
'LBL_ENABLE'                                       => 'Habilitado',
'LBL_MODULE_NAME_TITLE'                            => 'Rastreadores',
'LBL_MODULE_NAME'                                  => 'Rastreadores',
'LBL_TRACKER_SETTINGS'                             => 'Configurações de Rastreador',
'LBL_TRACKER_QUERIES_DESC'                         => 'Rastreador de Queries',
'LBL_TRACKER_QUERIES_HELP'                         => 'Localize demonstrações de SQL quando "Query lenta do Log" é habilitado e o tempo de execução da query exceder o valor "Tempo Limite de Query baixo"',
'LBL_TRACKER_PERF_DESC'                            => 'Executar Rastreador',
'LBL_TRACKER_PERF_HELP'                            => 'Circuitos de dados Track, os arquivos acessados e uso de memória',
'LBL_TRACKER_SESSIONS_DESC'                        => 'Rastrear Sessões',
'LBL_TRACKER_SESSIONS_HELP'                        => 'Localizar usuários ativos e informação de sessão dos usuários',
'LBL_TRACKER_DESC'                                 => 'Rastrear Ações',
'LBL_TRACKER_HELP'                                 => 'Localizar páginas vistas pelos usuáriosTrack user’s page views (modules and records accessed) and record saves',
'LBL_TRACKER_PRUNE_INTERVAL'                       => 'Number of days of Tracker data to store when Scheduler prunes the tables',
'LBL_TRACKER_PRUNE_RANGE'                          => 'Número de dias',
'action'										   =>'Ação',
'users'											   =>'Usuários',
'LBL_TRACKER_PRUNE_RANGE'						   =>'Numero de dias',

);?>
