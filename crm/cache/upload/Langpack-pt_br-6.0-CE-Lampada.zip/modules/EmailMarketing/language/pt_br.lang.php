<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_REPLY_ADDR'                                   => '"Responder para" Endereço:',
'LBL_REPLY_NAME'                                   => '"Responder para" Nome:',
'LBL_MODULE_NAME'                                  => 'Marketing por Email',
'LBL_MODULE_TITLE'                                 => 'Marketing por Email: Principal',
'LBL_LIST_FORM_TITLE'                              => 'Campanhas de Marketing por Email',
'LBL_NAME'                                         => 'Nome: ',
'LBL_LIST_NAME'                                    => 'Nome',
'LBL_LIST_FROM_ADDR'                               => 'Email de',
'LBL_LIST_DATE_START'                              => 'Data de Início',
'LBL_LIST_TEMPLATE_NAME'                           => 'Modelo de Email',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_STATUS'                                       => 'Status',
'LBL_STATUS_TEXT'                                  => 'Status:',
'LBL_TEMPLATE_NAME'                                => 'Nome do Modelo',
'LBL_DATE_ENTERED'                                 => 'Data de Entrada',
'LBL_DATE_MODIFIED'                                => 'Data de Alteração',
'LBL_MODIFIED'                                     => 'Modificado por: ',
'LBL_CREATED'                                      => 'Criado por: ',
'LBL_MESSAGE_FOR'                                  => 'Enviar Esta Mensagem Para:',
'LBL_MESSAGE_FOR_ID'                               => 'Mensagem Para',
'LBL_FROM_NAME'                                    => 'Nome de: ',
'LBL_FROM_ADDR'                                    => 'Endereço de Email de: ',
'LBL_DATE_START'                                   => 'Data de Início',
'LBL_TIME_START'                                   => 'Hora de Início',
'LBL_START_DATE_TIME'                              => 'Data & Hora de Início: ',
'LBL_TEMPLATE'                                     => 'Modelo de Email: ',
'LBL_MODIFIED_BY'                                  => 'Modificado por: ',
'LBL_CREATED_BY'                                   => 'Criado por: ',
'LBL_DATE_CREATED'                                 => 'Data de Criação: ',
'LBL_DATE_LAST_MODIFIED'                           => 'Data de Alteração: ',
'LNK_NEW_CAMPAIGN'                                 => 'Nova Campanha',
'LNK_CAMPAIGN_LIST'                                => 'Campanhas',
'LNK_NEW_PROSPECT_LIST'                            => 'Nova Lista de Possíveis Clientes',
'LNK_PROSPECT_LIST_LIST'                           => 'Listas de Possíveis Clientes',
'LNK_NEW_PROSPECT'                                 => 'Novo Possível Cliente',
'LNK_PROSPECT_LIST'                                => 'Possíveis Cliente',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Marketing por Email',
'LBL_CREATE_EMAIL_TEMPLATE'                        => 'Criar',
'LBL_EDIT_EMAIL_TEMPLATE'                          => 'Editar',
'LBL_FROM_MAILBOX'                                 => 'Caixa Postal de',
'LBL_FROM_MAILBOX_NAME'                            => 'Usar Caixa Postal:',
'LBL_PROSPECT_LIST_SUBPANEL_TITLE'                 => 'Listas de Possíveis Clientes',
'LBL_ALL_PROSPECT_LISTS'                           => 'Todas Listas de Possíveis Clientes na Campanha.',
'LBL_RELATED_PROSPECT_LISTS'                       => 'Todas Listas de Possíveis Clientes relacionadas a esta mensagem.',
'LBL_PROSPECT_LIST_NAME'                           => 'Nome da Lista de Possíveis Clientes',
'LBL_LIST_PROSPECT_LIST_NAME'                      => 'Listas de Possíveis Clientes',
'LBL_MODULE_SEND_TEST'                             => 'Campanha: Enviar Teste',
'LBL_MODULE_SEND_EMAILS'                           => 'Campaign: Enviar Emails',
'LBL_SCHEDULE_MESSAGE_TEST'                        => 'Por favor, selecione as mensagens de campanha que você gostaria de enviar o teste:',
'LBL_SCHEDULE_MESSAGE_EMAILS'                      => 'Por favor, selecione as mensagens de campanha que você gostaria de agendar o envio em determinada data e hora:',
'LBL_SCHEDULE_BUTTON_TITLE'                        => 'Enviar',
'LBL_SCHEDULE_BUTTON_LABEL'                        => 'Enviar',
'LBL_SCHEDULE_BUTTON_KEY'                          => 'T',
);?>
