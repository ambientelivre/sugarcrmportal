<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_SETTINGS'                                     => 'Configurações',
'LBL_CREATE_LANG_PACK'                             => 'Criar Language Pack',
'LBL_ARCHIVES'                                     => 'Arquivos',
'LBL_SETTTINGS_SHOW_HIDE'                          => 'Exibir / Ocultar Configurações',
'LBL_CREATE_LANG_PACK_SHOW_HIDE'                   => 'Exibir / Ocultar Language Pack',
'LBL_ARCHIVES_SHOW_HIDE'                           => 'Exibir / Ocultar Arquivos',
'LBL_PREFIX'                                       => 'Prefixo:',
'LBL_PREFIX_COMMENT'                               => 'Prefixo do arquivo da linguagem Ex.: en_us, se, no',
'LBL_AUTO_UPDATE'                                  => 'Auto Atualizar',
'LBL_AUTO_UPDATE_COMMENT'                          => 'Atualizar sugestões automaticamente, se exibidas',
'LBL_FILE_SUFFIX'                                  => '.lang.php',
'LBL_NO_LANG_SELECTED'                             => 'Por favor entre com a linguagem',
'LBL_FILE_NAME'                                    => 'para traduzir para o Sugar CRM',
'LBL_FILENAME_COMMENT'                             => 'Nome do arquivo para exportar Language Pack',
'LBL_LANG_PACK_FILE_SUFFIX'                        => '.zip',
'LBL_BUTTON_CREATE_LANG_PACK'                      => 'Criar',
'LBL_LANG_PACK_VERSION'                            => 'Versão:',
'LBL_EXAMPLE_LANG_PACK_VERSION'                    => 'Exemplo: 1.0',
'LBL_LANG_PACK_DATE'                               => 'Data de Publicação',
'LBL_EXAMPLE_LANG_PACK_DATE'                       => 'Exemplo: 2008-02-11',
'LBL_LANG_PACK_AUTHOR'                             => 'Autor:',
'LBL_EXAMPLE_LANG_PACK_AUTHOR'                     => 'Exemplo: John Doe',
'LBL_LANG_PACK_NAME'                               => 'Nome:',
'LBL_EXAMPLE_LANG_PACK_NAME'                       => 'Exemplo: Language Pack Brasil',
'LBL_LANG_PACK_DESC'                               => 'Descrição',
'LBL_EXAMPLE_LANG_PACK_DESC'                       => 'Exemplo: SugarCRM traduzido para Português',
'LBL_MODULE'                                       => 'Módulo:',
'LBL_LABEL'                                        => 'Label:',
'LBL_LABEL_HEADER'                                 => 'Label:',
'LBL_DROPDOWN'                                     => 'Dropdown:',
'LBL_STD_VALUE'                                    => 'Valor Padrão',
'LBL_TRANSLATED'                                   => 'Valor Traduzido',
'LBL_SEPARATOR'                                    => ':',
'LBL_BY_LABEL'                                     => 'pelo Label',
'LBL_BY_STRING'                                    => 'pela String',
'LBL_NONE_FOUND'                                   => 'Sugestões não encontradas',
'LBL_LOADING'                                      => 'Carregando...',
'LBL_BUTTON_SAVE'                                  => 'Salvar',
'LBL_BUTTON_SAVE_GO_NEXT'                          => 'Salvar e ir para próximo módulo',
'LBL_BUTTON_MOVE_TO_NEXT_EMPTY'                    => 'Ir para próximo vazio',
'BG_HEADER'                                        => '#c7d4d2',
'BG_SUB_HEADER'                                    => '#dee7ed',
'LBL_ARCHIVES_NAME'                                => 'Nome',
'LBL_ARCHIVES_VERSION'                             => 'Versão',
'LBL_ARCHIVES_AUTHOR'                              => 'Autor',
'LBL_ARCHIVES_PUBLISHED'                           => 'publicado',
'LBL_ARCHIVES_DESCRIPTION'                         => 'Descrição',
'LBL_NO_ACCESS'                                    => 'Você deve ter direitos Administrativos para acessar este módulo.',
'LNK_IMPORT_USERS'                                 => 'Importar Usuários',
'LBL_PASSWORD_SENT'                                => 'Senha Alterada',
'LBL_CANNOT_SEND_PASSWORD'                         => 'Não pôde alterar Senha',
'LBL_ADVANCED'                                     => 'Avançado',
'LBL_ANY_ADDRESS'                                  => 'Endereço Qualquer:',
'LBL_DOWNLOADS'                                    => 'Downloads',
'LBL_EMAIL_PROVIDER'                               => 'Provedor do Email',
'LBL_EMPLOYEE_INFORMATION'                         => 'Informação do Funcionário',
'LBL_SIGNATURE_NAME'                               => 'Nome',
'LBL_RESET_PREFERENCES_WARNING_USER'               => 'Tem certeza que deseja restaurar todas as preferências para esse usuário?',
'LBL_RESET_HOMEPAGE_WARNING_USER'                  => 'Tem certeza que deseja restaurar a Homepage para esse usuário?',
'LBL_THEME_COLOR'                                  => 'Cor',
'LBL_THEME_FONT'                                   => 'Fonte',
'LBL_USER_ACCESS'                                  => 'Acesso',
'LBL_MAIL_SMTPTYPE'                                => 'Tipo de Servidor SMTP:',
'LBL_MAIL_SMTP_SETTINGS'                           => 'Especificação do Servidor SMTP',
'LBL_CHOOSE_EMAIL_PROVIDER'                        => 'Escolha seu provedor de Email:',
'LBL_YAHOOMAIL_SMTPPASS'                           => 'Yahoo! Senha:',
'LBL_YAHOOMAIL_SMTPUSER'                           => 'Yahoo! Usuário:',
'LBL_GMAIL_SMTPPASS'                               => 'Gmail Senha:',
'LBL_GMAIL_SMTPUSER'                               => 'Gmail Email:',
'LBL_EXCHANGE_SMTPPASS'                            => 'Mudar Senha:',
'LBL_EXCHANGE_SMTPUSER'                            => 'Mudar Usuário:',
'LBL_EXCHANGE_SMTPPORT'                            => 'Mudar Porta do Servidor:',
'LBL_EXCHANGE_SMTPSERVER'                          => 'Mudar Servidor:',
'LBL_WIZARD_TITLE'                                 => 'Assistente de Usuários',
'LBL_WIZARD_WELCOME_TAB'                           => 'Bem Vindo',
'LBL_WIZARD_WELCOME_TITLE'                         => 'Bem Vindo ao Sugar! ',
'LBL_WIZARD_WELCOME'                               => 'Clique em <b>Próximo</b> para alterar algumas configurações básicaspara usar o Sugar.',
'LBL_WIZARD_WELCOME_NOSMTP'                        => 'Clique em  <b>Próximo</b> para alterar algumas configurações básicas para usar o Sugar. ',
'LBL_WIZARD_FINISH'                                => 'Clique em <b>Fim</b> abaixo para salver suas configurações e para iniciar o uso no Sugar.<br /><br /><b>Para mais informações do uso do Sugar:</b><br /><br />&bull;&nbsp;Acesse <a href="http://www.sugarcrm.com/university/" target="_blank">Training Materials</a>, includindo tutoriais e vídeos<br />&bull;&nbsp;Leia <a href="http://www.sugarcrm.com/crm/support/documentation" target="_blank">Documentação do Sugar</a><br />&bull;&nbsp;Encontre respostas e soluções em <a href="http://kb.sugarcrm.com/" target="_blank">Base de Conhecimento</a><br />',
'LBL_WIZARD_PERSONALINFO'                          => 'Suas Informações',
'LBL_WIZARD_LOCALE'                                => 'Sua Localidade',
'LBL_WIZARD_SMTP'                                  => 'Sua Conta de Email',
'LBL_WIZARD_PERSONALINFO_DESC'                     => 'Inclua informações sobre você. As informações que você incluir estarão visíveis para outros usuários no Sugar.Campos marcados com * são obrigatórios',
'LBL_WIZARD_LOCALE_DESC'                           => 'Especifique a hora da sua localidade e como deseja que apareça as data, moeda e nomes no seu Sugar.',
'LBL_WIZARD_SMTP_DESC'                             => 'Inclua seu usuário e senha da conta de email para caixa de saída de email padrão do servidor. ',
'LBL_PICTURE_FILE'								   => 'Foto',
'LBL_TOO_MANY_CONCURRENT'						   => 'Essa sessão terminou porqueoutra sessão começou como mesmo usuário.',

);?>
