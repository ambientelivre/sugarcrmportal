<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_EDIT_LAYOUT'                                  => 'Editar Layout',
'LBL_EDIT_ROWS'                                    => 'Editar Linhas',
'LBL_EDIT_COLUMNS'                                 => 'Editar Colunas',
'LBL_EDIT_LABELS'                                  => 'Editar Rótulos',
'LBL_EDIT_FIELDS'                                  => 'Editar Campos Personalizados',
'LBL_ADD_FIELDS'                                   => 'Adicionar Campos Personalizados',
'LBL_DISPLAY_HTML'                                 => 'Mostrar Código HTML',
'LBL_SELECT_FILE'                                  => 'Selecionar Arquivo',
'LBL_SAVE_LAYOUT'                                  => 'Salvar Layout',
'LBL_SELECT_A_SUBPANEL'                            => 'Selecionar um Subpainel',
'LBL_SELECT_SUBPANEL'                              => 'Selecionar Subpainel',
'LBL_MODULE_TITLE'                                 => 'Studio ',
'LBL_TOOLBOX'                                      => 'Box de Ferramenta',
'LBL_STAGING_AREA'                                 => 'Área de Armazenamento (arraste e solte os itens aqui)',
'LBL_SUGAR_FIELDS_STAGE'                           => 'Campos Sugar (clique nos ítens para adicionar à área de armazenamento)',
'LBL_SUGAR_BIN_STAGE'                              => 'Sugar Bin (clique nos itens para adicionar para a área de armazenamento)',
'LBL_VIEW_SUGAR_FIELDS'                            => 'Campos de visualização do Sugar',
'LBL_VIEW_SUGAR_BIN'                               => 'Visualização Sugar Bin',
'LBL_FAILED_TO_SAVE'                               => 'Falha ao Salvar',
'LBL_CONFIRM_UNSAVE'                               => 'Quaisquer modificações não serão salvas.Você realmente deseja continuar?',
'LBL_PUBLISHING'                                   => 'Publicando...',
'LBL_PUBLISHED'                                    => 'Publicado',
'LBL_FAILED_PUBLISHED'                             => 'Falha ao publicar',
'LBL_DROP_HERE'                                    => '[Arraste Aqui]',
'LBL_NAME'                                         => 'Nome',
'LBL_LABEL'                                        => 'Rótulo',
'LBL_MASS_UPDATE'                                  => 'Atualização em Massa',
'LBL_AUDITED'                                      => 'Examinado',
'LBL_CUSTOM_MODULE'                                => 'Módulo',
'LBL_DEFAULT_VALUE'                                => 'Valor Padrão',
'LBL_REQUIRED'                                     => 'Requerido',
'LBL_DATA_TYPE'                                    => 'Tipo de data',
'LBL_HISTORY'                                      => 'Histórico',
'LBL_SW_WELCOME'                                   => '<b>Bem vindo ao Studio!</b><BR><BR> O que você gostaria de fazer hoje?<BR><b>Por favor selecione as opções abaixo.</b> ',
'LBL_SW_EDIT_MODULE'                               => 'Editar o Módulo',
'LBL_SW_EDIT_DROPDOWNS'                            => 'Editar Drop Downs',
'LBL_SW_EDIT_TABS'                                 => 'Configurar Guias',
'LBL_SW_RENAME_TABS'                               => 'Renomear Guias',
'LBL_SW_EDIT_GROUPTABS'                            => 'Configurar Grupo de Guias',
'LBL_SW_EDIT_PORTAL'                               => 'Editar Portal',
'LBL_SW_EDIT_WORKFLOW'                             => 'Editar Workflow',
'LBL_SW_REPAIR_CUSTOMFIELDS'                       => 'Reparar Campo Customizado',
'LBL_SW_MIGRATE_CUSTOMFIELDS'                      => 'Migrar Campo Customizado',
'LBL_SMW_WELCOME'                                  => '<b>Bem vindo ao Studio!<BR><BR> Por favor selecione um dos módulos abaixo.</b>',
'LBL_SMA_WELCOME'                                  => '<b>Editar um módulo</b><BR><BR> O que você deseja fazer com este módulo?</b><br>Por favor selecione qual ação você gostaria de fazer. ',
'LBL_SMA_EDIT_CUSTOMFIELDS'                        => 'Editar Campos Customizados',
'LBL_SMA_EDIT_LAYOUT'                              => 'Editar Layout',
'LBL_SMA_EDIT_LABELS'                              => 'Editar Legendas',
'LBL_MB_PREVIEW'                                   => 'Pre-Visualização',
'LBL_MB_RESTORE'                                   => 'Restaurar',
'LBL_MB_DELETE'                                    => 'Apagar',
'LBL_MB_COMPARE'                                   => 'Comparar',
'LBL_MB_WELCOME'                                   => '<b>Histórico</b><BR><BR>Histórico permite você visualizar edições previamente publicadas do arquivo que você está atualmente trabalhando. Você pode comparar e restaurar as versões anteriores. Se você não restaurar o arquivo ele se tornará seu arquivo de trabalho. Você deve publicar antes de ele tornar-se visível aos demais.<BR>',
'LBL_ED_CREATE_DROPDOWN'                           => 'Criar um Drop Down',
'LBL_ED_WELCOME'                                   => '<b>Editor de Dropdown<BR><BR>Você pode também editar um dropdown existente ou criar um próximo dropdown</b>',
'LBL_DROPDOWN_NAME'                                => 'Nome do Dropdown',
'LBL_DROPDOWN_LANGUAGE'                            => 'Idioma do Dropdown',
'LBL_TABGROUP_LANGUAGE'                            => 'Grupo de Idioma:',
'LBL_EC_WELCOME'                                   => '<b>Editor de Campo Customizado<BR><BR>Você pode também visualizar e editar um campo customizado existente, criar um novo campo customizado, ou limpar o cache do campo customizado.</b>',
'LBL_EC_VIEW_CUSTOMFIELDS'                         => 'Visualizar campos customizados',
'LBL_EC_CREATE_CUSTOMFIELD'                        => 'Criar campos customizados',
'LBL_EC_CLEAR_CACHE'                               => 'Limpar Cache',
'LBL_SM_WELCOME'                                   => '<b>Histórico<BR><BR>Por favor selecione o arquivo que você gostaria de visualizar</b>',
'LBL_DD_DISPALYVALUE'                              => 'Valor mostrado',
'LBL_DD_DATABASEVALUE'                             => 'Valor do Banco de Dados',
'LBL_DD_ALL'                                       => 'Todos',
'LBL_BTN_SAVE'                                     => 'Salvar',
'LBL_BTN_SAVEPUBLISH'                              => 'Salvar & Publicar',
'LBL_BTN_HISTORY'                                  => 'Histórico',
'LBL_BTN_NEXT'                                     => 'Próximo',
'LBL_BTN_BACK'                                     => 'Voltar',
'LBL_BTN_ADDCOLS'                                  => 'Adicionar Colunas',
'LBL_BTN_ADDROWS'                                  => 'Adicionar Linhas',
'LBL_BTN_UNDO'                                     => 'Desfazer',
'LBL_BTN_REDO'                                     => 'Refazer',
'LBL_BTN_ADDCUSTOMFIELD'                           => 'Adicionar Campo Customizado',
'LBL_BTN_TABINDEX'                                 => 'Editar Ordem de Tabulação',
'LBL_TAB_SUBTABS'                                  => 'Sub tabulação',
'LBL_MODULES'                                      => 'Módulos',
'LBL_MODULE_NAME'                                  => 'Administração',
'LBL_CONFIGURE_GROUP_TABS'                         => 'Configurar Guia de Grupos',
'LBL_GROUP_TAB_WELCOME'                            => 'O layout do Grup Tab a seguir será usado quando um usuário optar por utilizar agrupado em vez do habitual Módulo Tabs em Minha Conta> Opções de Layout',
'LBL_RENAME_TAB_WELCOME'                           => 'Clique em qualquer valor mostrado na tabela a seguir para mudar o nome da Tab.',
'LBL_DELETE_MODULE'                                => 'Deletar Módulo',
'LBL_DISPLAY_OTHER_TAB_HELP'                       => 'Selecione para exibir a guia "Outro" na barra de navegação. Por padrão, o guia "Outro" não apresenta todos os módulos já incluídos em outros grupos.',
'LBL_TAB_GROUP_LANGUAGE_HELP'                      => 'Para definir os rótulos guia do grupo para outros idiomas disponíveis, selecione um idioma, editar labels e clique em Salvar & Publicar para fazer as mudanças para esse idioma.',
'LBL_ADD_GROUP'                                    => 'Adicionar Grupo',
'LBL_NEW_GROUP'                                    => 'Novo Grupo',
'LBL_RENAME_TABS'                                  => 'Renomear Guias',
'LBL_DISPLAY_OTHER_TAB'                            => 'Exibir guia \'Outro\'',
'LBL_DEFAULT'                                      => 'Padrão',
'LBL_ADDITIONAL'                                   => 'Adicional',
'LBL_AVAILABLE'                                    => 'Disponível',
'LBL_LISTVIEW_DESCRIPTION'                         => 'Há três colunas abaixo. A coluna padrão tem os campos mostrados por padrão no ListView, a coluna adicional tem os campos que o usuário pode escolher para criar um view personalizado, e as outras colunas são as que podem ser adicionadas ao view.',
'LBL_LISTVIEW_EDIT'                                => 'Editor da Lista de Visualização',
'ERROR_ALREADY_EXISTS'                             => 'Erro: Campo Já Existe',
'ERROR_INVALID_KEY_VALUE'                          => 'Erro: Valor da Chave Invalida: [\']',
'LBL_SW_SUGARPORTAL'                               => 'Portal Sugar',
'LBL_SMP_WELCOME'                                  => 'Por favor selecione o módulo que você gostaria de editar na lista abaixo',
'LBL_SP_WELCOME'                                   => 'Bem vindo ao Studio para Portal Sugar. Você pode ou escolher editar módulos aqui ou sincronizar uma instancia do portal.<BR> Por favor escolha da lista abaixo.',
'LBL_SP_SYNC'                                      => 'Sincronizar Portal',
'LBL_SYNCP_WELCOME'                                => 'Por favor entre com a URL da instância do portal você deseja atualizar então pressiona o botão Ir.<BR>Isto trará uma tela para seus nome e senha do usuário.<BR>Por favor entre com seus nome e senha do usuário do Sugar e pressione o botão Iniciar Sincronização.',
'LBL_LISTVIEWP_DESCRIPTION'                        => 'Existem duas colunas abaixo:<BR>O Padrão que estão os campos que serão mostrados e Disponível que estão os campos que não são mostrados, mas são disponíveis para serem mostrados. Basta arrastar o campo entre as duas colunas. Você pode também reordenar os itens nas colunas arrastando e soltando os.',
'LBL_SP_STYLESHEET'                                => 'Atualizar modelo de planilha',
'LBL_SP_UPLOADSTYLE'                               => 'Clique no botão do browser e selecione um modelo de planilha para atualizar em seu computador.<BR>A próxima vez você sincroniza para o portal trará o modelo de planilha junto com ele.',
'LBL_SP_UPLOADED'                                  => 'Atualizado',
'ERROR_SP_UPLOADED'                                => 'Por favor assegure que você está unloading um css de modelo de planilha',
'LBL_SP_PREVIEW'                                   => 'Aqui é um preview de que seus modelos de planilha.',
);?>
