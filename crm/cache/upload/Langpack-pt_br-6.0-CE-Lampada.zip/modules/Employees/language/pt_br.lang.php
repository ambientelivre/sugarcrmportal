<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Funcionários',
'LBL_MODULE_TITLE'                                 => 'Funcionários: Principal',
'LBL_SEARCH_FORM_TITLE'                            => 'Pesquisar funcionários',
'LBL_LIST_FORM_TITLE'                              => 'Funcionários',
'LBL_NEW_FORM_TITLE'                               => 'Criar funcionário',
'LBL_EMPLOYEE'                                     => 'Funcionários:',
'LBL_LOGIN'                                        => 'Login',
'LBL_RESET_PREFERENCES'                            => 'Voltar à configuração padrão',
'LBL_TIME_FORMAT'                                  => 'Formato da hora:',
'LBL_DATE_FORMAT'                                  => 'Formato da data:',
'LBL_TIMEZONE'                                     => 'Hora local:',
'LBL_CURRENCY'                                     => 'Moeda:',
'LBL_LIST_NAME'                                    => 'Nome completo',
'LBL_LIST_LAST_NAME'                               => 'Sobrenome',
'LBL_LIST_EMPLOYEE_NAME'                           => 'Nome do funcionário',
'LBL_LIST_DEPARTMENT'                              => 'Departamento',
'LBL_LIST_REPORTS_TO_NAME'                         => 'Reporta-se a',
'LBL_LIST_EMAIL'                                   => 'E-mail',
'LBL_LIST_PRIMARY_PHONE'                           => 'Telefone (principal)',
'LBL_LIST_USER_NAME'                               => 'Nome do usuário',
'LBL_LIST_ADMIN'                                   => 'Admin',
'LBL_NEW_EMPLOYEE_BUTTON_TITLE'                    => 'Criar funcionário [Alt+N]',
'LBL_NEW_EMPLOYEE_BUTTON_LABEL'                    => 'Criar funcionário',
'LBL_NEW_EMPLOYEE_BUTTON_KEY'                      => 'N',
'LBL_ERROR'                                        => 'Erro:',
'LBL_PASSWORD'                                     => 'Senha:',
'LBL_EMPLOYEE_NAME'                                => 'Nome do funcionário:',
'LBL_USER_NAME'                                    => 'Nome do usuário:',
'LBL_FIRST_NAME'                                   => 'Nome:',
'LBL_LAST_NAME'                                    => 'Sobrenome:',
'LBL_EMPLOYEE_SETTINGS'                            => 'Configurações do funcionário',
'LBL_THEME'                                        => 'Tema:',
'LBL_LANGUAGE'                                     => 'Idioma:',
'LBL_ADMIN'                                        => 'Administrador:',
'LBL_EMPLOYEE_INFORMATION'                         => 'Dados do funcionário',
'LBL_OFFICE_PHONE'                                 => 'Telefone comercial:',
'LBL_REPORTS_TO'                                   => 'Reporta-se a:',
'LBL_REPORTS_TO_NAME'                              => 'Reporta-se para',
'LBL_OTHER_PHONE'                                  => 'Telefone (outro):',
'LBL_OTHER_EMAIL'                                  => 'E-mail (outro):',
'LBL_NOTES'                                        => 'Observações:',
'LBL_DEPARTMENT'                                   => 'Departamento:',
'LBL_TITLE'                                        => 'Título:',
'LBL_ANY_PHONE'                                    => 'Telefone alternativo:',
'LBL_ANY_EMAIL'                                    => 'E-mail alternativo:',
'LBL_ADDRESS'                                      => 'Endereço:',
'LBL_CITY'                                         => 'Cidade:',
'LBL_STATE'                                        => 'Estado:',
'LBL_POSTAL_CODE'                                  => 'CEP:',
'LBL_COUNTRY'                                      => 'País:',
'LBL_NAME'                                         => 'Nome Completo:',
'LBL_MOBILE_PHONE'                                 => 'Telefone celular:',
'LBL_OTHER'                                        => 'Outro:',
'LBL_FAX'                                          => 'Fax:',
'LBL_EMAIL'                                        => 'E-mail:',
'LBL_HOME_PHONE'                                   => 'Telefone residencial:',
'LBL_WORK_PHONE'                                   => 'Fone do Trabalho',
'LBL_ADDRESS_INFORMATION'                          => 'Dados de endereço',
'LBL_EMPLOYEE_STATUS'                              => 'Status do funcionário:',
'LBL_PRIMARY_ADDRESS'                              => 'Endereço (principal):',
'LBL_SAVED_SEARCH'                                 => 'Opções de Layout',
'LBL_CREATE_USER_BUTTON_TITLE'                     => 'Criar usuário [Alt+N]',
'LBL_CREATE_USER_BUTTON_LABEL'                     => 'Criar usuário',
'LBL_CREATE_USER_BUTTON_KEY'                       => 'N',
'LBL_FAVORITE_COLOR'                               => 'Cor preferida:',
'LBL_MESSENGER_ID'                                 => 'Nome IM:',
'LBL_MESSENGER_TYPE'                               => 'Tipo de IM:',
'ERR_EMPLOYEE_NAME_EXISTS_1'                       => 'Já existe um funcionário com esse nome ',
'ERR_EMPLOYEE_NAME_EXISTS_2'                       => '. Nomes de funcionários repetidos não são permitidos. Altere o nome do funcionário para que seja único.',
'ERR_LAST_ADMIN_1'                                 => 'O funcionário "',
'ERR_LAST_ADMIN_2'                                 => '" É o último a ter direitos de Administrador. Pelo menos um usuário deve ter direitos de Administrador.',
'LNK_NEW_EMPLOYEE'                                 => 'Criar funcionário',
'LNK_EMPLOYEE_LIST'                                => 'Funcionários',
'ERR_DELETE_RECORD'                                => 'Para excluir uma conta um número de registro deve ser especificado.',
'LBL_LIST_EMPLOYEE_STATUS'                         => 'Status',
'LBL_SUGAR_LOGIN'                                  => 'É usuário do Sugar',
'LBL_RECEIVE_NOTIFICATIONS'                        => 'Notificação de Atribuição',
'LBL_IS_ADMIN'                                     => 'É administrador',
'LBL_GROUP'                                        => 'Grupo de usuário',
'LBL_PORTAL_ONLY'                                  => 'Somente usuário do Portal',
'LBL_ANY_ADDRESS'                                  => 'Qualquer Endereço:',
'LBL_PHOTO'                                        => 'Foto ',

);?>
