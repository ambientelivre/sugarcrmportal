A Lampada Global Services foi pioneiro em comercializar no Brasil o sistema SugarCRM e os servi�os da nossa equipe t�cnica para assessorar na configura��o, modifica��o, implanta��o e utiliza��o do software. 

Desde 2005, mantemos a tradu��o brasileira do SugarCRM, implantamos o software em mais que 40 empresas brasileiras, de pequena a grande porte, e fizemos diversos projetos de integra��o de sistemas nos EUA, Canad� e Europa. Hoje a Lampada Global � o �nico SugarCRM Gold Partner no Brasil, oferecemos servi�os de instala��o, treinamento, suporte t�cnico e desenvolvimentos adicionais.


Para maiores informa��es:

Lampada Global Services
Rua Bela Cintra, 299 Cj.51
Consola��o
S�o Paulo, SP
tel1. 55 11 3237-3110 
tel2. 55 11 3257-0659 
e-mail: info@lampadaglobal.com

Conhe�a nosso site: www.lampadaglobal.com


