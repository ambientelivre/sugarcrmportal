<?php
// created: 2012-02-28 14:08:16
$layout_defs["CAD_S_Solucoes"]["subpanel_setup"]["itop__itenscad_s_solucoes"] = array (
  'order' => 100,
  'module' => 'ItOP__Itens_oportunidade',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ITOP__ITENS_OPORTUNIDADE_CAD_S_SOLUCOES_FROM_ITOP__ITENS_OPORTUNIDADE_TITLE',
  'get_subpanel_data' => 'itop__itenscad_s_solucoes',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
