<?php
// created: 2012-02-28 14:09:16
$dictionary["Opportunity"]["fields"]["itop__itens_opportunities"] = array (
  'name' => 'itop__itens_opportunities',
  'type' => 'link',
  'relationship' => 'itop__itens_oportunidade_opportunities',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ITOP__ITENS_OPORTUNIDADE_OPPORTUNITIES_FROM_ITOP__ITENS_OPORTUNIDADE_TITLE',
);
