<?php
// created: 2012-02-28 14:09:12
$dictionary["ItOP__Itens_oportunidade"]["fields"]["itop__itenscad_s_solucoes"] = array (
  'name' => 'itop__itenscad_s_solucoes',
  'type' => 'link',
  'relationship' => 'itop__itens_oportunidade_cad_s_solucoes',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ITOP__ITENS_OPORTUNIDADE_CAD_S_SOLUCOES_FROM_CAD_S_SOLUCOES_TITLE',
);
