<?php
$module_name = 'ant_inutilizado';
$viewdefs [$module_name] = 
array (
  'QuickCreate' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'ant_inutilicretarias_name',
            'label' => 'LBL_ANT_INUTILIZADO_ANT_SECRETARIAS_FROM_ANT_SECRETARIAS_TITLE',
          ),
          1 => 
          array (
            'name' => 'in_data',
            'label' => 'LBL_IN_DATA',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'in_qt',
            'label' => 'LBL_IN_QT',
          ),
          1 => 
          array (
            'name' => 'in_motivo',
            'label' => 'LBL_IN_MOTIVO',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'in_lote',
            'label' => 'LBL_IN_LOTE',
          ),
          1 => '',
        ),
      ),
    ),
  ),
);
?>
