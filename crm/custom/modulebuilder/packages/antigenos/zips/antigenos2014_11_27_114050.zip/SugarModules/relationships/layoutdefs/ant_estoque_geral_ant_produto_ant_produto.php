<?php
// created: 2014-08-26 13:58:04
$layout_defs["ant_produto"]["subpanel_setup"]["ant_estoqueal_ant_produto"] = array (
  'order' => 100,
  'module' => 'ant_estoque_geral',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ESTOQUE_GERAL_ANT_PRODUTO_FROM_ANT_ESTOQUE_GERAL_TITLE',
  'get_subpanel_data' => 'ant_estoqueal_ant_produto',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 16:07:02
$layout_defs["ant_produto"]["subpanel_setup"]["ant_estoqueal_ant_produto"] = array (
  'order' => 100,
  'module' => 'ant_estoque_geral',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ESTOQUE_GERAL_ANT_PRODUTO_FROM_ANT_ESTOQUE_GERAL_TITLE',
  'get_subpanel_data' => 'ant_estoqueal_ant_produto',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 16:07:10
$layout_defs["ant_produto"]["subpanel_setup"]["ant_estoqueal_ant_produto"] = array (
  'order' => 100,
  'module' => 'ant_estoque_geral',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ESTOQUE_GERAL_ANT_PRODUTO_FROM_ANT_ESTOQUE_GERAL_TITLE',
  'get_subpanel_data' => 'ant_estoqueal_ant_produto',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 16:07:12
$layout_defs["ant_produto"]["subpanel_setup"]["ant_estoqueal_ant_produto"] = array (
  'order' => 100,
  'module' => 'ant_estoque_geral',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ESTOQUE_GERAL_ANT_PRODUTO_FROM_ANT_ESTOQUE_GERAL_TITLE',
  'get_subpanel_data' => 'ant_estoqueal_ant_produto',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-27 13:29:26
$layout_defs["ant_produto"]["subpanel_setup"]["ant_estoqueal_ant_produto"] = array (
  'order' => 100,
  'module' => 'ant_estoque_geral',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ESTOQUE_GERAL_ANT_PRODUTO_FROM_ANT_ESTOQUE_GERAL_TITLE',
  'get_subpanel_data' => 'ant_estoqueal_ant_produto',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-27 15:38:27
$layout_defs["ant_produto"]["subpanel_setup"]["ant_estoqueal_ant_produto"] = array (
  'order' => 100,
  'module' => 'ant_estoque_geral',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ESTOQUE_GERAL_ANT_PRODUTO_FROM_ANT_ESTOQUE_GERAL_TITLE',
  'get_subpanel_data' => 'ant_estoqueal_ant_produto',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-12 16:13:33
$layout_defs["ant_produto"]["subpanel_setup"]["ant_estoqueal_ant_produto"] = array (
  'order' => 100,
  'module' => 'ant_estoque_geral',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ESTOQUE_GERAL_ANT_PRODUTO_FROM_ANT_ESTOQUE_GERAL_TITLE',
  'get_subpanel_data' => 'ant_estoqueal_ant_produto',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-24 14:10:54
$layout_defs["ant_produto"]["subpanel_setup"]["ant_estoqueal_ant_produto"] = array (
  'order' => 100,
  'module' => 'ant_estoque_geral',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ESTOQUE_GERAL_ANT_PRODUTO_FROM_ANT_ESTOQUE_GERAL_TITLE',
  'get_subpanel_data' => 'ant_estoqueal_ant_produto',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-10-21 10:38:20
$layout_defs["ant_produto"]["subpanel_setup"]["ant_estoqueal_ant_produto"] = array (
  'order' => 100,
  'module' => 'ant_estoque_geral',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ESTOQUE_GERAL_ANT_PRODUTO_FROM_ANT_ESTOQUE_GERAL_TITLE',
  'get_subpanel_data' => 'ant_estoqueal_ant_produto',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
