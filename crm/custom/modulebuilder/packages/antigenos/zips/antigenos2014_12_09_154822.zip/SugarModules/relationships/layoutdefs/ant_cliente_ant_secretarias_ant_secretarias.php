<?php
// created: 2014-11-07 16:55:17
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_clientent_secretarias"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_SECRETARIAS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_clientent_secretarias',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-26 15:24:56
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_clientent_secretarias"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_SECRETARIAS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_clientent_secretarias',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-26 16:02:46
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_clientent_secretarias"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_SECRETARIAS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_clientent_secretarias',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 09:01:49
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_clientent_secretarias"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_SECRETARIAS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_clientent_secretarias',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 09:33:51
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_clientent_secretarias"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_SECRETARIAS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_clientent_secretarias',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:26:41
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_clientent_secretarias"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_SECRETARIAS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_clientent_secretarias',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:40:38
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_clientent_secretarias"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_SECRETARIAS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_clientent_secretarias',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:40:46
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_clientent_secretarias"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_SECRETARIAS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_clientent_secretarias',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:40:53
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_clientent_secretarias"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_SECRETARIAS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_clientent_secretarias',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:41:09
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_clientent_secretarias"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_SECRETARIAS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_clientent_secretarias',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:41:21
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_clientent_secretarias"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_SECRETARIAS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_clientent_secretarias',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
