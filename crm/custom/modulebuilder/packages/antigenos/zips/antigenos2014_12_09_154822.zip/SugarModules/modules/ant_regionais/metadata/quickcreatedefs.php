<?php
$module_name = 'ant_regionais';
$viewdefs [$module_name] = 
array (
  'QuickCreate' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'ant_regionacretarias_name',
            'label' => 'LBL_ANT_REGIONAIS_ANT_SECRETARIAS_FROM_ANT_SECRETARIAS_TITLE',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'reg_razao_social',
            'label' => 'LBL_REG_RAZAO_SOCIAL ',
          ),
          1 => 
          array (
            'name' => 'reg_nm_fantasia',
            'label' => 'LBL_REG_NM_FANTASIA',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'reg_cep',
            'label' => 'LBL_REG_CEP',
          ),
          1 => 
          array (
            'name' => 'reg_bairro',
            'label' => 'LBL_REG_BAIRRO',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'reg_cidade',
            'label' => 'LBL_REG_CIDADE',
          ),
          1 => 
          array (
            'name' => 'reg_estado',
            'studio' => 'visible',
            'label' => 'LBL_REG_ESTADO ',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'reg_tp_logradouro',
            'studio' => 'visible',
            'label' => 'LBL_REG_TP_LOGRADOURO ',
          ),
          1 => 
          array (
            'name' => 'reg_logradouro',
            'label' => 'LBL_REG_LOGRADOURO',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'reg_numero',
            'label' => 'LBL_ REG_NUMERO',
          ),
          1 => 
          array (
            'name' => 'reg_complemento',
            'label' => 'LBL_REG_COMPLEMENTO',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'reg_cnpj',
            'label' => 'LBL_REG_CNPJ',
          ),
          1 => 
          array (
            'name' => 'reg_inscricao_estadual',
            'label' => 'LBL_REG_INSCRICAO_ESTADUAL',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'reg_cnae',
            'label' => 'LBL_REG_CNAE',
          ),
          1 => '',
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'ant_clienteregionais_name',
            'label' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_CLIENTE_TITLE',
          ),
          1 => '',
        ),
      ),
      'lbl_editview_panel3' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'reg_contato',
            'label' => 'LBL_REG_CONTATO',
          ),
          1 => 
          array (
            'name' => 'reg_telefone',
            'label' => 'LBL_REG_TELEFONE',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'reg_email',
            'label' => 'LBL_REG_EMAIL',
          ),
          1 => 
          array (
            'name' => 'reg_orgao_vinculado_pncebt',
            'label' => 'LBL_REG_ORGAO_VINCULADO_PNCEBT',
          ),
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'date_entered',
            'comment' => 'Date record created',
            'label' => 'LBL_DATE_ENTERED',
          ),
          1 => 
          array (
            'name' => 'created_by_name',
            'label' => 'LBL_CREATED',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'date_modified',
            'comment' => 'Date record last modified',
            'label' => 'LBL_DATE_MODIFIED',
          ),
          1 => 
          array (
            'name' => 'modified_by_name',
            'label' => 'LBL_MODIFIED_NAME',
          ),
        ),
      ),
    ),
  ),
);
?>
