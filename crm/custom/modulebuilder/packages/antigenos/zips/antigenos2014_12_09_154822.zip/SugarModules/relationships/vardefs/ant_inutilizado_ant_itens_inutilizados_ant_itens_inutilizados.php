<?php
// created: 2014-12-09 15:48:20
$dictionary["ant_itens_inutilizados"]["fields"]["ant_inutilis_inutilizados"] = array (
  'name' => 'ant_inutilis_inutilizados',
  'type' => 'link',
  'relationship' => 'ant_inutilizado_ant_itens_inutilizados',
  'source' => 'non-db',
  'vname' => 'LBL_ANT_INUTILIZADO_ANT_ITENS_INUTILIZADOS_FROM_ANT_INUTILIZADO_TITLE',
);
