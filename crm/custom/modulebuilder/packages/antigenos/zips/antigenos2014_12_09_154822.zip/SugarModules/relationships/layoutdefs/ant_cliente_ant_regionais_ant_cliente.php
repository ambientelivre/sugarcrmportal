<?php
// created: 2014-08-26 14:52:17
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 14:53:40
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 14:53:54
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 14:55:46
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 15:02:27
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 15:11:18
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 15:18:43
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 15:25:20
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 16:04:06
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 16:07:02
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 16:07:10
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 16:07:12
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 16:15:48
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 16:18:38
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-27 13:29:26
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-27 15:38:27
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-27 16:18:12
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-27 16:23:46
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-27 16:27:36
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-27 16:43:51
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-29 14:53:41
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-01 14:57:32
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-01 17:22:29
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-01 17:23:54
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-01 17:32:12
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-01 17:40:34
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-01 17:42:13
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-01 17:56:17
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-01 18:18:53
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-02 11:45:47
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-03 08:05:08
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-05 13:26:37
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-12 15:31:32
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-12 15:39:02
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-12 15:42:50
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-12 15:46:04
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-12 15:48:19
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-12 15:58:54
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-12 15:59:57
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-12 16:13:33
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-24 14:10:54
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-10-21 10:38:20
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-03 09:52:46
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-03 10:01:34
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-03 10:12:15
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-07 15:16:35
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-07 15:38:41
$layout_defs["ant_cliente"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
