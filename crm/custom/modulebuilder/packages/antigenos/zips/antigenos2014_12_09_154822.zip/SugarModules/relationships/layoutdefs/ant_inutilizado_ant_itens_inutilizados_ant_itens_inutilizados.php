<?php
// created: 2014-12-09 15:48:10
$layout_defs["ant_itens_inutilizados"]["subpanel_setup"]["ant_inutilis_inutilizados"] = array (
  'order' => 100,
  'module' => 'ant_inutilizado',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_INUTILIZADO_ANT_ITENS_INUTILIZADOS_FROM_ANT_INUTILIZADO_TITLE',
  'get_subpanel_data' => 'ant_inutilis_inutilizados',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-12-09 15:48:20
$layout_defs["ant_itens_inutilizados"]["subpanel_setup"]["ant_inutilis_inutilizados"] = array (
  'order' => 100,
  'module' => 'ant_inutilizado',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_INUTILIZADO_ANT_ITENS_INUTILIZADOS_FROM_ANT_INUTILIZADO_TITLE',
  'get_subpanel_data' => 'ant_inutilis_inutilizados',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
