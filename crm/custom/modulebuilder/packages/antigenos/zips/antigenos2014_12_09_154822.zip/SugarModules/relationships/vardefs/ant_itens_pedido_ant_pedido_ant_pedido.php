<?php
// created: 2014-09-12 15:48:21
$dictionary["ant_pedido"]["fields"]["ant_itens_pido_ant_pedido"] = array (
  'name' => 'ant_itens_pido_ant_pedido',
  'type' => 'link',
  'relationship' => 'ant_itens_pedido_ant_pedido',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ANT_ITENS_PEDIDO_ANT_PEDIDO_FROM_ANT_ITENS_PEDIDO_TITLE',
);
