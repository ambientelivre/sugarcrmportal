<?php
$popupMeta = array (
    'moduleMain' => 'ant_regionais',
    'varName' => 'ant_regionais',
    'orderBy' => 'ant_regionais.name',
    'whereClauses' => array (
  'name' => 'ant_regionais.name',
),
    'searchInputs' => array (
  0 => 'ant_regionais_number',
  1 => 'name',
  2 => 'priority',
  3 => 'status',
),
    'listviewdefs' => array (
  'REG_RAZAO_SOCIAL' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_REG_RAZAO_SOCIAL ',
    'width' => '10%',
    'default' => true,
    'name' => 'reg_razao_social',
  ),
),
);
