<?php
// created: 2014-11-27 11:41:12
$dictionary["ant_pedido"]["fields"]["ant_pedido__lista_pedidos"] = array (
  'name' => 'ant_pedido__lista_pedidos',
  'type' => 'link',
  'relationship' => 'ant_pedido_ant_lista_pedidos',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
);
