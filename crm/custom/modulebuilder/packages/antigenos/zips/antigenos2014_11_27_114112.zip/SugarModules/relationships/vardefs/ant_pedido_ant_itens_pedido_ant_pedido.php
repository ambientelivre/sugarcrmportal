<?php
// created: 2014-09-12 15:46:07
$dictionary["ant_pedido"]["fields"]["ant_pedido_t_itens_pedido"] = array (
  'name' => 'ant_pedido_t_itens_pedido',
  'type' => 'link',
  'relationship' => 'ant_pedido_ant_itens_pedido',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ANT_PEDIDO_ANT_ITENS_PEDIDO_FROM_ANT_ITENS_PEDIDO_TITLE',
);
