<?php
// created: 2014-08-26 14:52:17
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 14:53:40
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 14:53:54
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 14:55:46
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 15:02:27
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 15:11:18
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 15:18:43
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 15:25:20
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 16:04:06
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 16:07:02
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 16:07:10
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_cliente_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_cliente',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_CLIENTE_ANT_REGIONAIS_FROM_ANT_CLIENTE_TITLE',
  'get_subpanel_data' => 'ant_cliente_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
