    <?php
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/


    $manifest = array (
         'acceptable_sugar_versions' => 
          array (
            
          ),
          'acceptable_sugar_flavors' =>
          array(
            'CE', 'PRO','ENT'
          ),
          'readme'=>'',
          'key'=>'ant',
          'author' => 'Diego',
          'description' => '',
          'icon' => '',
          'is_uninstallable' => true,
          'name' => 'antigenos',
          'published_date' => '2014-08-26 19:07:09',
          'type' => 'module',
          'version' => '1409080029',
          'remove_tables' => 'prompt',
          );
$installdefs = array (
  'id' => 'antigenos',
  'beans' => 
  array (
    0 => 
    array (
      'module' => 'ant_secretarias',
      'class' => 'ant_secretarias',
      'path' => 'modules/ant_secretarias/ant_secretarias.php',
      'tab' => true,
    ),
    1 => 
    array (
      'module' => 'ant_producao',
      'class' => 'ant_producao',
      'path' => 'modules/ant_producao/ant_producao.php',
      'tab' => true,
    ),
    2 => 
    array (
      'module' => 'ant_cliente',
      'class' => 'ant_cliente',
      'path' => 'modules/ant_cliente/ant_cliente.php',
      'tab' => true,
    ),
    3 => 
    array (
      'module' => 'ant_produto',
      'class' => 'ant_produto',
      'path' => 'modules/ant_produto/ant_produto.php',
      'tab' => true,
    ),
    4 => 
    array (
      'module' => 'ant_estoque_geral',
      'class' => 'ant_estoque_geral',
      'path' => 'modules/ant_estoque_geral/ant_estoque_geral.php',
      'tab' => true,
    ),
    5 => 
    array (
      'module' => 'ant_regionais',
      'class' => 'ant_regionais',
      'path' => 'modules/ant_regionais/ant_regionais.php',
      'tab' => true,
    ),
    6 => 
    array (
      'module' => 'ant_log_estoque',
      'class' => 'ant_log_estoque',
      'path' => 'modules/ant_log_estoque/ant_log_estoque.php',
      'tab' => true,
    ),
    7 => 
    array (
      'module' => 'ant_pedido',
      'class' => 'ant_pedido',
      'path' => 'modules/ant_pedido/ant_pedido.php',
      'tab' => true,
    ),
  ),
  'layoutdefs' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/ant_cliente_ant_regionais_ant_regionais.php',
      'to_module' => 'ant_regionais',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/ant_cliente_ant_regionais_ant_cliente.php',
      'to_module' => 'ant_cliente',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/ant_estoque_geral_ant_produto_ant_produto.php',
      'to_module' => 'ant_produto',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/ant_estoque_geral_ant_produto_ant_estoque_geral.php',
      'to_module' => 'ant_estoque_geral',
    ),
  ),
  'relationships' => 
  array (
    0 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/ant_producao_ant_produtoMetaData.php',
    ),
    1 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/ant_cliente_ant_regionaisMetaData.php',
    ),
    2 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/ant_estoque_geral_ant_regionaisMetaData.php',
    ),
    3 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/ant_estoque_geral_ant_produtoMetaData.php',
    ),
    4 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/ant_log_estoque_ant_produtoMetaData.php',
    ),
  ),
  'image_dir' => '<basepath>/icons',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ant_secretarias',
      'to' => 'modules/ant_secretarias',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ant_producao',
      'to' => 'modules/ant_producao',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ant_cliente',
      'to' => 'modules/ant_cliente',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ant_produto',
      'to' => 'modules/ant_produto',
    ),
    4 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ant_estoque_geral',
      'to' => 'modules/ant_estoque_geral',
    ),
    5 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ant_regionais',
      'to' => 'modules/ant_regionais',
    ),
    6 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ant_log_estoque',
      'to' => 'modules/ant_log_estoque',
    ),
    7 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ant_pedido',
      'to' => 'modules/ant_pedido',
    ),
  ),
  'language' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_produto.php',
      'to_module' => 'ant_produto',
      'language' => 'en_us',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_produto.php',
      'to_module' => 'ant_produto',
      'language' => 'pt_BR',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_producao.php',
      'to_module' => 'ant_producao',
      'language' => 'en_us',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_producao.php',
      'to_module' => 'ant_producao',
      'language' => 'pt_BR',
    ),
    4 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_regionais.php',
      'to_module' => 'ant_regionais',
      'language' => 'en_us',
    ),
    5 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_regionais.php',
      'to_module' => 'ant_regionais',
      'language' => 'pt_BR',
    ),
    6 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_cliente.php',
      'to_module' => 'ant_cliente',
      'language' => 'en_us',
    ),
    7 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_cliente.php',
      'to_module' => 'ant_cliente',
      'language' => 'pt_BR',
    ),
    8 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_regionais.php',
      'to_module' => 'ant_regionais',
      'language' => 'en_us',
    ),
    9 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_regionais.php',
      'to_module' => 'ant_regionais',
      'language' => 'pt_BR',
    ),
    10 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_estoque_geral.php',
      'to_module' => 'ant_estoque_geral',
      'language' => 'en_us',
    ),
    11 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_estoque_geral.php',
      'to_module' => 'ant_estoque_geral',
      'language' => 'pt_BR',
    ),
    12 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_produto.php',
      'to_module' => 'ant_produto',
      'language' => 'en_us',
    ),
    13 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_produto.php',
      'to_module' => 'ant_produto',
      'language' => 'pt_BR',
    ),
    14 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_estoque_geral.php',
      'to_module' => 'ant_estoque_geral',
      'language' => 'en_us',
    ),
    15 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_estoque_geral.php',
      'to_module' => 'ant_estoque_geral',
      'language' => 'pt_BR',
    ),
    16 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_produto.php',
      'to_module' => 'ant_produto',
      'language' => 'en_us',
    ),
    17 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_produto.php',
      'to_module' => 'ant_produto',
      'language' => 'pt_BR',
    ),
    18 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_log_estoque.php',
      'to_module' => 'ant_log_estoque',
      'language' => 'en_us',
    ),
    19 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ant_log_estoque.php',
      'to_module' => 'ant_log_estoque',
      'language' => 'pt_BR',
    ),
    20 => 
    array (
      'from' => '<basepath>/SugarModules/language/application/en_us.lang.php',
      'to_module' => 'application',
      'language' => 'en_us',
    ),
    21 => 
    array (
      'from' => '<basepath>/SugarModules/language/application/pt_BR.lang.php',
      'to_module' => 'application',
      'language' => 'pt_BR',
    ),
  ),
  'vardefs' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/ant_producao_ant_produto_ant_produto.php',
      'to_module' => 'ant_produto',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/ant_producao_ant_produto_ant_producao.php',
      'to_module' => 'ant_producao',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/ant_cliente_ant_regionais_ant_regionais.php',
      'to_module' => 'ant_regionais',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/ant_cliente_ant_regionais_ant_cliente.php',
      'to_module' => 'ant_cliente',
    ),
    4 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/ant_estoque_geral_ant_regionais_ant_regionais.php',
      'to_module' => 'ant_regionais',
    ),
    5 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/ant_estoque_geral_ant_regionais_ant_estoque_geral.php',
      'to_module' => 'ant_estoque_geral',
    ),
    6 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/ant_estoque_geral_ant_produto_ant_produto.php',
      'to_module' => 'ant_produto',
    ),
    7 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/ant_estoque_geral_ant_produto_ant_estoque_geral.php',
      'to_module' => 'ant_estoque_geral',
    ),
    8 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/ant_log_estoque_ant_produto_ant_produto.php',
      'to_module' => 'ant_produto',
    ),
    9 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/ant_log_estoque_ant_produto_ant_log_estoque.php',
      'to_module' => 'ant_log_estoque',
    ),
  ),
  'layoutfields' => 
  array (
    0 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    1 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    2 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
  ),
);