<?php
// created: 2014-08-26 11:46:53
$layout_defs["ant_estoque_geral"]["subpanel_setup"]["ant_estoqueal_ant_produto"] = array (
  'order' => 100,
  'module' => 'ant_produto',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ESTOQUE_GERAL_ANT_PRODUTO_FROM_ANT_PRODUTO_TITLE',
  'get_subpanel_data' => 'ant_estoqueal_ant_produto',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 12:44:35
$layout_defs["ant_estoque_geral"]["subpanel_setup"]["ant_estoqueal_ant_produto"] = array (
  'order' => 100,
  'module' => 'ant_produto',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ESTOQUE_GERAL_ANT_PRODUTO_FROM_ANT_PRODUTO_TITLE',
  'get_subpanel_data' => 'ant_estoqueal_ant_produto',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 13:58:04
$layout_defs["ant_estoque_geral"]["subpanel_setup"]["ant_estoqueal_ant_produto"] = array (
  'order' => 100,
  'module' => 'ant_produto',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ESTOQUE_GERAL_ANT_PRODUTO_FROM_ANT_PRODUTO_TITLE',
  'get_subpanel_data' => 'ant_estoqueal_ant_produto',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 16:04:06
$layout_defs["ant_estoque_geral"]["subpanel_setup"]["ant_estoqueal_ant_produto"] = array (
  'order' => 100,
  'module' => 'ant_produto',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ESTOQUE_GERAL_ANT_PRODUTO_FROM_ANT_PRODUTO_TITLE',
  'get_subpanel_data' => 'ant_estoqueal_ant_produto',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-26 16:07:02
$layout_defs["ant_estoque_geral"]["subpanel_setup"]["ant_estoqueal_ant_produto"] = array (
  'order' => 100,
  'module' => 'ant_produto',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ESTOQUE_GERAL_ANT_PRODUTO_FROM_ANT_PRODUTO_TITLE',
  'get_subpanel_data' => 'ant_estoqueal_ant_produto',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
