<?php
// created: 2014-08-26 16:07:02
$dictionary["ant_estoque_geral"]["fields"]["ant_estoqueal_ant_produto"] = array (
  'name' => 'ant_estoqueal_ant_produto',
  'type' => 'link',
  'relationship' => 'ant_estoque_geral_ant_produto',
  'source' => 'non-db',
  'vname' => 'LBL_ANT_ESTOQUE_GERAL_ANT_PRODUTO_FROM_ANT_PRODUTO_TITLE',
);
