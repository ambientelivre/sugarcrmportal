<?php
// created: 2014-12-09 15:48:11
$layout_defs["ant_lista_pedidos"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_pedido',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_PEDIDO_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
