<?php
// created: 2014-11-07 16:55:19
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_regionais_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_REGIONAIS_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'ant_regionais_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-26 15:24:59
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_regionais_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_REGIONAIS_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'ant_regionais_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-26 16:02:49
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_regionais_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_REGIONAIS_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'ant_regionais_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 09:01:52
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_regionais_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_REGIONAIS_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'ant_regionais_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 09:33:53
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_regionais_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_REGIONAIS_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'ant_regionais_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:26:43
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_regionais_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_REGIONAIS_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'ant_regionais_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:40:40
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_regionais_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_REGIONAIS_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'ant_regionais_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:40:49
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_regionais_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_REGIONAIS_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'ant_regionais_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:40:56
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_regionais_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_REGIONAIS_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'ant_regionais_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:41:11
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_regionais_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_REGIONAIS_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'ant_regionais_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:41:23
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_regionais_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_REGIONAIS_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'ant_regionais_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-12-09 15:48:11
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_regionais_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_REGIONAIS_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'ant_regionais_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
