<?php
// created: 2014-12-09 15:48:08
$layout_defs["ant_regionais"]["subpanel_setup"]["ant_secreta_ant_regionais"] = array (
  'order' => 100,
  'module' => 'ant_secretarias',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_SECRETARIAS_ANT_REGIONAIS_FROM_ANT_SECRETARIAS_TITLE',
  'get_subpanel_data' => 'ant_secreta_ant_regionais',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
