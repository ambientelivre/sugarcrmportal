<?php
// created: 2014-12-09 15:48:12
$dictionary["ant_pedido"]["fields"]["ant_pedido_nt_regionais_1"] = array (
  'name' => 'ant_pedido_nt_regionais_1',
  'type' => 'link',
  'relationship' => 'ant_pedido_ant_regionais_1',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ANT_PEDIDO_ANT_REGIONAIS_1_FROM_ANT_REGIONAIS_TITLE',
);
