<?php
// created: 2014-12-09 15:48:11
$dictionary["ant_inutilizado"]["fields"]["ant_itens_int_inutilizado"] = array (
  'name' => 'ant_itens_int_inutilizado',
  'type' => 'link',
  'relationship' => 'ant_itens_inutilizados_ant_inutilizado',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ANT_ITENS_INUTILIZADOS_ANT_INUTILIZADO_FROM_ANT_ITENS_INUTILIZADOS_TITLE',
);
