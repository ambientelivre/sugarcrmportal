<?php
// created: 2014-12-09 15:48:11
$dictionary["Contact"]["fields"]["ant_regionais_contacts"] = array (
  'name' => 'ant_regionais_contacts',
  'type' => 'link',
  'relationship' => 'ant_regionais_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_ANT_REGIONAIS_CONTACTS_FROM_ANT_REGIONAIS_TITLE',
);
