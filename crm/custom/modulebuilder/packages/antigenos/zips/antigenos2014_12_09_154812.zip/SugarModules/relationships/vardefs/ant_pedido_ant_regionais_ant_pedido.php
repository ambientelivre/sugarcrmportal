<?php
// created: 2014-12-09 15:48:11
$dictionary["ant_pedido"]["fields"]["ant_pedido_ant_regionais"] = array (
  'name' => 'ant_pedido_ant_regionais',
  'type' => 'link',
  'relationship' => 'ant_pedido_ant_regionais',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ANT_PEDIDO_ANT_REGIONAIS_FROM_ANT_REGIONAIS_TITLE',
);
