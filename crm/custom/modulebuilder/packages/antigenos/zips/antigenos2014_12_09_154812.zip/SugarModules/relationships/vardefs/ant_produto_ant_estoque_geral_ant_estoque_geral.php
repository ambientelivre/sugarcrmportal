<?php
// created: 2014-09-01 17:23:54
$dictionary["ant_estoque_geral"]["fields"]["ant_produto_estoque_geral"] = array (
  'name' => 'ant_produto_estoque_geral',
  'type' => 'link',
  'relationship' => 'ant_produto_ant_estoque_geral',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ANT_PRODUTO_ANT_ESTOQUE_GERAL_FROM_ANT_PRODUTO_TITLE',
);
