<?php
// created: 2014-09-12 15:58:56
$dictionary["ant_pedido"]["fields"]["ant_lista_pdos_ant_pedido"] = array (
  'name' => 'ant_lista_pdos_ant_pedido',
  'type' => 'link',
  'relationship' => 'ant_lista_pedidos_ant_pedido',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ANT_LISTA_PEDIDOS_ANT_PEDIDO_FROM_ANT_LISTA_PEDIDOS_TITLE',
);
