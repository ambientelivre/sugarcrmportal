<?php
// created: 2014-09-05 13:26:39
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_itens_pido_ant_pedido"] = array (
  'order' => 100,
  'module' => 'ant_itens_pedido',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ITENS_PEDIDO_ANT_PEDIDO_FROM_ANT_ITENS_PEDIDO_TITLE',
  'get_subpanel_data' => 'ant_itens_pido_ant_pedido',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-12 15:31:34
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_itens_pido_ant_pedido"] = array (
  'order' => 100,
  'module' => 'ant_itens_pedido',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ITENS_PEDIDO_ANT_PEDIDO_FROM_ANT_ITENS_PEDIDO_TITLE',
  'get_subpanel_data' => 'ant_itens_pido_ant_pedido',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-12 15:39:03
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_itens_pido_ant_pedido"] = array (
  'order' => 100,
  'module' => 'ant_itens_pedido',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ITENS_PEDIDO_ANT_PEDIDO_FROM_ANT_ITENS_PEDIDO_TITLE',
  'get_subpanel_data' => 'ant_itens_pido_ant_pedido',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-12 15:42:52
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_itens_pido_ant_pedido"] = array (
  'order' => 100,
  'module' => 'ant_itens_pedido',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ITENS_PEDIDO_ANT_PEDIDO_FROM_ANT_ITENS_PEDIDO_TITLE',
  'get_subpanel_data' => 'ant_itens_pido_ant_pedido',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-12 15:46:06
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_itens_pido_ant_pedido"] = array (
  'order' => 100,
  'module' => 'ant_itens_pedido',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ITENS_PEDIDO_ANT_PEDIDO_FROM_ANT_ITENS_PEDIDO_TITLE',
  'get_subpanel_data' => 'ant_itens_pido_ant_pedido',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-12 15:48:21
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_itens_pido_ant_pedido"] = array (
  'order' => 100,
  'module' => 'ant_itens_pedido',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_ITENS_PEDIDO_ANT_PEDIDO_FROM_ANT_ITENS_PEDIDO_TITLE',
  'get_subpanel_data' => 'ant_itens_pido_ant_pedido',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
