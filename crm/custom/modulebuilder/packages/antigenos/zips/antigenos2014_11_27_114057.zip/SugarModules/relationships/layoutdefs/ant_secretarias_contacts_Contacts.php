<?php
// created: 2014-11-07 16:55:16
$layout_defs["Contacts"]["subpanel_setup"]["ant_secretarias_contacts"] = array (
  'order' => 100,
  'module' => 'ant_secretarias',
  'subpanel_name' => '',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_SECRETARIAS_CONTACTS_FROM_ANT_SECRETARIAS_TITLE',
  'get_subpanel_data' => 'ant_secretarias_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-26 15:24:55
$layout_defs["Contacts"]["subpanel_setup"]["ant_secretarias_contacts"] = array (
  'order' => 100,
  'module' => 'ant_secretarias',
  'subpanel_name' => '',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_SECRETARIAS_CONTACTS_FROM_ANT_SECRETARIAS_TITLE',
  'get_subpanel_data' => 'ant_secretarias_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-26 16:02:46
$layout_defs["Contacts"]["subpanel_setup"]["ant_secretarias_contacts"] = array (
  'order' => 100,
  'module' => 'ant_secretarias',
  'subpanel_name' => '',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_SECRETARIAS_CONTACTS_FROM_ANT_SECRETARIAS_TITLE',
  'get_subpanel_data' => 'ant_secretarias_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 09:01:49
$layout_defs["Contacts"]["subpanel_setup"]["ant_secretarias_contacts"] = array (
  'order' => 100,
  'module' => 'ant_secretarias',
  'subpanel_name' => '',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_SECRETARIAS_CONTACTS_FROM_ANT_SECRETARIAS_TITLE',
  'get_subpanel_data' => 'ant_secretarias_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 09:33:50
$layout_defs["Contacts"]["subpanel_setup"]["ant_secretarias_contacts"] = array (
  'order' => 100,
  'module' => 'ant_secretarias',
  'subpanel_name' => '',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_SECRETARIAS_CONTACTS_FROM_ANT_SECRETARIAS_TITLE',
  'get_subpanel_data' => 'ant_secretarias_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:26:41
$layout_defs["Contacts"]["subpanel_setup"]["ant_secretarias_contacts"] = array (
  'order' => 100,
  'module' => 'ant_secretarias',
  'subpanel_name' => '',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_SECRETARIAS_CONTACTS_FROM_ANT_SECRETARIAS_TITLE',
  'get_subpanel_data' => 'ant_secretarias_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:40:37
$layout_defs["Contacts"]["subpanel_setup"]["ant_secretarias_contacts"] = array (
  'order' => 100,
  'module' => 'ant_secretarias',
  'subpanel_name' => '',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_SECRETARIAS_CONTACTS_FROM_ANT_SECRETARIAS_TITLE',
  'get_subpanel_data' => 'ant_secretarias_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:40:46
$layout_defs["Contacts"]["subpanel_setup"]["ant_secretarias_contacts"] = array (
  'order' => 100,
  'module' => 'ant_secretarias',
  'subpanel_name' => '',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_SECRETARIAS_CONTACTS_FROM_ANT_SECRETARIAS_TITLE',
  'get_subpanel_data' => 'ant_secretarias_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:40:52
$layout_defs["Contacts"]["subpanel_setup"]["ant_secretarias_contacts"] = array (
  'order' => 100,
  'module' => 'ant_secretarias',
  'subpanel_name' => '',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_SECRETARIAS_CONTACTS_FROM_ANT_SECRETARIAS_TITLE',
  'get_subpanel_data' => 'ant_secretarias_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
