<?php
// created: 2014-11-27 11:40:37
$dictionary["Contact"]["fields"]["ant_secretarias_contacts"] = array (
  'name' => 'ant_secretarias_contacts',
  'type' => 'link',
  'relationship' => 'ant_secretarias_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_ANT_SECRETARIAS_CONTACTS_FROM_ANT_SECRETARIAS_TITLE',
);
