<?php
// created: 2014-09-12 15:48:22
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-12 15:58:56
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-12 16:00:00
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-12 16:13:36
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-24 14:10:57
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-10-21 10:38:24
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-03 09:52:49
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-03 10:01:37
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-03 10:12:18
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-07 15:16:38
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-07 15:38:43
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-07 16:55:20
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-26 15:25:00
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-26 16:02:50
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 09:01:52
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 09:33:54
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:26:44
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:40:41
$layout_defs["ant_pedido"]["subpanel_setup"]["ant_pedido__lista_pedidos"] = array (
  'order' => 100,
  'module' => 'ant_lista_pedidos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PEDIDO_ANT_LISTA_PEDIDOS_FROM_ANT_LISTA_PEDIDOS_TITLE',
  'get_subpanel_data' => 'ant_pedido__lista_pedidos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
