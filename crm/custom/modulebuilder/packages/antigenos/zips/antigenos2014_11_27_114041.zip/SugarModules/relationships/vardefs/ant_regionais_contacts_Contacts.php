<?php
// created: 2014-11-27 11:40:40
$dictionary["Contact"]["fields"]["ant_regionais_contacts"] = array (
  'name' => 'ant_regionais_contacts',
  'type' => 'link',
  'relationship' => 'ant_regionais_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_ANT_REGIONAIS_CONTACTS_FROM_ANT_REGIONAIS_TITLE',
);
