<?php
// created: 2014-08-27 16:43:51
$layout_defs["ant_estoque_geral"]["subpanel_setup"]["ant_produto_estoque_geral"] = array (
  'order' => 100,
  'module' => 'ant_produto',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PRODUTO_ANT_ESTOQUE_GERAL_FROM_ANT_PRODUTO_TITLE',
  'get_subpanel_data' => 'ant_produto_estoque_geral',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-08-29 14:53:41
$layout_defs["ant_estoque_geral"]["subpanel_setup"]["ant_produto_estoque_geral"] = array (
  'order' => 100,
  'module' => 'ant_produto',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PRODUTO_ANT_ESTOQUE_GERAL_FROM_ANT_PRODUTO_TITLE',
  'get_subpanel_data' => 'ant_produto_estoque_geral',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-01 14:57:32
$layout_defs["ant_estoque_geral"]["subpanel_setup"]["ant_produto_estoque_geral"] = array (
  'order' => 100,
  'module' => 'ant_produto',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PRODUTO_ANT_ESTOQUE_GERAL_FROM_ANT_PRODUTO_TITLE',
  'get_subpanel_data' => 'ant_produto_estoque_geral',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-01 17:22:30
$layout_defs["ant_estoque_geral"]["subpanel_setup"]["ant_produto_estoque_geral"] = array (
  'order' => 100,
  'module' => 'ant_produto',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PRODUTO_ANT_ESTOQUE_GERAL_FROM_ANT_PRODUTO_TITLE',
  'get_subpanel_data' => 'ant_produto_estoque_geral',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-09-01 17:23:54
$layout_defs["ant_estoque_geral"]["subpanel_setup"]["ant_produto_estoque_geral"] = array (
  'order' => 100,
  'module' => 'ant_produto',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_PRODUTO_ANT_ESTOQUE_GERAL_FROM_ANT_PRODUTO_TITLE',
  'get_subpanel_data' => 'ant_produto_estoque_geral',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
