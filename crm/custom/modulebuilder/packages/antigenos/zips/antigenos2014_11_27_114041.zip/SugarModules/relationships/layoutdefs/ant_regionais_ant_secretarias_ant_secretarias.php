<?php
// created: 2014-11-07 16:55:19
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_regionant_secretarias"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_REGIONAIS_ANT_SECRETARIAS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_regionant_secretarias',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-26 16:02:49
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_regionant_secretarias"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_REGIONAIS_ANT_SECRETARIAS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_regionant_secretarias',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 09:33:53
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_regionant_secretarias"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_REGIONAIS_ANT_SECRETARIAS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_regionant_secretarias',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-11-27 11:26:43
$layout_defs["ant_secretarias"]["subpanel_setup"]["ant_regionant_secretarias"] = array (
  'order' => 100,
  'module' => 'ant_regionais',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANT_REGIONAIS_ANT_SECRETARIAS_FROM_ANT_REGIONAIS_TITLE',
  'get_subpanel_data' => 'ant_regionant_secretarias',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
