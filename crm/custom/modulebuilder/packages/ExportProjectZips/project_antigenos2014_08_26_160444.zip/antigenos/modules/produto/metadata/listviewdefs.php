<?php
$module_name = 'ant_produto';
$listViewDefs [$module_name] = 
array (
  'PD_NOME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PD_NOME',
    'width' => '10%',
    'default' => true,
  ),
  'PD_DESCRICAO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PD_DESCRICAO',
    'width' => '10%',
    'default' => true,
  ),
);
?>
