<?php
$module_name = 'ant_pedido';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'type' => 'name',
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'PED_CODIGO_BOLETO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PED_CODIGO_BOLETO',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => true,
  ),
  'PED_STATUS' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_PED_STATUS ',
    'sortable' => false,
    'width' => '10%',
  ),
);
?>
